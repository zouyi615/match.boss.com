<?php

 	require("phpQuery.class.php");
	//var_dump(C('AUTOLOAD_NAMESPACE.Libs'));
    //$hobj = phpQuery::newDocumentHTML('http://news.sina.com.cn/china');	
    //var_dump($hobj);
    //echo pq(".blkTop h1:eq(0)")->html(); 



?>