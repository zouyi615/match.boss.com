<?php
namespace Think;
/**
 * ThinkPHP系统异常基类
 */
class Exception extends \Exception {
}