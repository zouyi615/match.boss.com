#coding=gbk
import logging
#import curl
import urllib,urllib2
import traceback
import datetime
import time
import random

import XmlConfig

def write_log(msg):
    #print msg
    logging.info(msg)
    
def getUrl(url):
    if url:
        num = random.randint(1, 2)
        conf = XmlConfig.get('/xml/config')
        return conf['daili'] % (num, url)
    return ''

def wopen(path,post={}):
    #����IP
    #path = "http://iframe.ip138.com/city.asp"
    #����headerͷ
    host = path.split("/")[2]
    heads = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Charset':'GB2312,utf-8;q=0.7,*;q=0.7',
    'Accept-Language':'zh-cn,zh;q=0.5',
    'Cache-Control':'max-age=0',
    'Connection':'keep-alive',
    'Host':host,
    'Keep-Alive':'115',
    'Referer':path,
    'User-Agent':'Mozilla/5.0 (X11; U; Linux x86_64; zh-CN; rv:1.9.2.14) Gecko/20110221 Ubuntu/10.10 (maverick) Firefox/3.6.14'}
    content = ""
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor())
    urllib2.install_opener(opener)
    data = urllib.urlencode(post)
    req = urllib2.Request(path,data,headers=heads)
    
    num = 0
    while num<10:
        try:
            content = opener.open(req, timeout=30).read()
            break
        except Exception,e:
            write_log('����ҳ��%s�����쳣:%s!'%(path,e))
        num += 1
        time.sleep(1)
    return content

def fopen(path,post={}):
    content=''
    try:
        if post:
            data = urllib.urlencode(post)
            headers = {}
            res  = urllib2.Request(path,data,headers)
        else:
            res = path
        resp = urllib2.urlopen(res,timeout=10)
        content = resp.read()
    except Exception,e:
        pass
        #print '����ҳ��{%s}�����쳣:{%s}!'%(path,e)
        #write_log('����ҳ��%s�����쳣:%s!'%(path,e))
        #write_log(traceback.format_exc())
    return content

def upload(url, path, body):    
    values = {'url'   :   path, 'content'   :   body}
    res = fopen(url, values)
    write_log("SETXML:%s:%s" % (path, str(res)))
    return res

def alert(x,t=0):
    print x
    if t:
        exit()

def UpLoadMonitor(pu, level, job, content, jgtime, phone):
        values = {'LEVEL':level, 'TIME':datetime.datetime.now(),'TYPE':'infolocalserver', 'JOB':job, 'SERVICE':'CheckData', 'CONTENT':content.encode("gb2312"), 'NEXTTIME':jgtime, 'PHONELIST':phone}
        str = urllib.urlencode(values)
        url = "%s?%s" % (pu, str)
        #������Ҫ���δ�����  DEBUG
        #return '<?xml version="1.0" encoding="utf-8" ?><result>OK</result>'
        res = fopen(url)
        return res