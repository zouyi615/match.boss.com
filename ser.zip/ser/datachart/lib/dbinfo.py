#coding=gbk
import Db.Oracle
import Db.Mysql

class dbinfo:
    def __init__(self, lot, type, no):
        self.lot = lot
        self.type = type
        self.no = no

    def getOraleOpenCodeList(self, table):
        #��ѯOracle�����п�������
        db = Db.Oracle.get(self.lot)
        if self.lot in ["xysc", "jssyxw", "klpk3"]:
            sql = "select f_abbdate as abbdate, f_expect as expect, f_opencode as opencode from %s where f_active = 0 and length(f_opencode) >= 3 order by f_expect" % (table)
        else:
            sql = "select se_abbdate as abbdate, se_expect as expect, se_opencode as opencode from %s where se_active = 0 and length(se_opencode) >= 10 order by se_expect" % (table)
        rows = db.query(sql)
        
        opencodeList = []
        for r in rows:
            opencodeList.append(r.data)
        return opencodeList

    def getLastOrder(self):
        table = "t_chart_%s_%s_%s" % (self.lot, self.type, self.no)
        sql = "select * from %s order by id desc limit 1" % (table)
        db = Db.Mysql.get('info_write')
        res = db.queryOne(sql)
        return res
    
    def getOrderList(self, where, limit):
        table = "t_chart_%s_%s_%s" % (self.lot, self.type, self.no)
        sql = "select * from %s where %s order by id desc %s" % (table, where, limit)
        db = Db.Mysql.get('info_write')
        res = db.query(sql)
        if res:
            res = sorted(res, key=lambda x : x['expect'])
        return res

    def getYilouList(self):
        row = {}
        table = "t_chart_%s_%s_%s" % (self.lot, self.type, self.no)
        sql = "select * from %s" % (table)
        db = Db.Mysql.get('info_write')
        res = db.query(sql)
        if res:
            for r in res:
                row[r['code']] = r
        return row
        
    def getYilouOrder(self):
        row = {}
        table = "t_chart_%s_%s_%s" % (self.lot, self.type, self.no)
        sql = "select * from %s" % (table)
        db = Db.Mysql.get('info_write')
        res = db.query(sql)
        return res
    
    def getYilouCode(self, where):
        table = "t_chart_%s_%s_%s" % (self.lot, self.type, self.no)
        sql = "select * from %s where %s limit 1" % (table, where)
        db = Db.Mysql.get('info_write')
        res = db.queryOne(sql)
        return res
    
    def getCodeList(self, num=0, where=""):
        if self.lot == 'klpk3':
            table = "t_chart_klpk3_zoushi_rxzs"
        elif self.lot == 'xysc':
            table = "t_chart_xysc_zoushi_zhsx"
        else:
            table = "t_chart_%s_zoushi_dwzs" % (self.lot)
        sql = "select abbdate,expect,opencode from %s" % (table)
        if where:
            sql += " where %s" % where
        sql += " order by id desc"
        if num:
            sql += " limit %s" % num
        db = Db.Mysql.get('info_write')
        res = db.query(sql)
        return res
    
    def getZdylqj(self, e, zdyl):
        if zdyl-1:
            if self.lot == 'xysc':
                table = "t_chart_xysc_zoushi_zhsx"
            else:
                table = "t_chart_%s_zoushi_dwzs" % (self.lot)
            sql = "select id-%d as id from %s where expect='%s'" % (zdyl-1, table, e)
            db = Db.Mysql.get('info_write')
            res = db.queryOne(sql)
            ex = ''
            if res:
                sql = "select expect from %s where id=%s" % (table, res['id'])
                arr = db.queryOne(sql)
                if arr:
                    ex = arr['expect']
        else:
            ex = e
        if ex:
            ex = '%s-%s' % (ex, e)
        return ex
    
    def truncate(self, table):
        db = Db.Mysql.get('info_write')
        sql = "TRUNCATE TABLE %s" % (table)
        return db.query(sql)
    
    def query(self, sql):
        db = Db.Mysql.get('info_write')
        ret = db.execute(sql)
        return ret
    
    def insert(self, table,  data):
        db = Db.Mysql.get('info_write')
        if table and data and db:
            keylist = []
            vallist = []
            for key in data:
                keylist.append(key)
                vallist.append(data[key])
            sql = "REPLACE INTO %s (%s) VALUES (%s)" % (table, ",".join(keylist), ",".join(['%s']*len(keylist)))
            ret = db.execute(sql, vallist)
            return ret
        return ''

    def update(self, table, data, where):
        db = Db.Mysql.get('info_write')
        if table and data and where and db:
            list = []
            vallist = []
            for key in data:
                list.append(key+"=%s")
                vallist.append(data[key])
        
            sql = "update %s set %s where %s" % (table, ",".join(list), where)
            ret = db.execute(sql, vallist)
            return ret
        return ''
    
    def commit(self):
        db = Db.Mysql.get('info_write')
        db.commit()
