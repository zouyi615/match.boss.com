#coding=gbk
import os
import XmlConfig
import urllib2
import random
import functions, dbinfo
import logging
import traceback
import time

expect = ""

class zoushi:
    def __init__(self):
        pass                
    
    def getIndata(self, no, o, df):
        indata = {}

        code= o[2].strip().split(",")
        v = map(int, code)
        
        if no == 'fbzs':
            gs = len(v)
            js = sum(map(lambda x:1 if x%2==1 else 0, v))
            os = gs-js
            ds = sum(map(lambda x:1 if x>5 else 0, v))
            xs = gs-ds
            zs = sum(map(lambda x:1 if x in [1, 2, 3, 5, 7, 11] else 0, v))
            hs = gs-zs
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'yilou':df.getYilou('yilou', map(lambda x:x-1, v), 11), 
            'jsyilou':df.getYilou('jsyilou', js, 6),  
            'osyilou':df.getYilou('osyilou', os, 6),  
            'dsyilou':df.getYilou('dsyilou', ds, 6),  
            'xsyilou':df.getYilou('xsyilou', xs, 6),  
            'zsyilou':df.getYilou('zsyilou', zs, 6),  
            'hsyilou':df.getYilou('hsyilou', hs, 6),  
            }
            
        if no == 'hzfb':
            hz = sum(v)
            wh = hz%10
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'hzyilou':df.getYilou('hzyilou', hz-15, 31), 
            'hwyilou':df.getYilou('hwyilou', wh, 10),
            }
            
        if no == 'qyfb':
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'yilou':df.getYilou('yilou', map(lambda x:x-1, v[:1]), 11), 
            }
            
        if no == 'qefb':
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'hhyilou':df.getYilou('hhyilou', map(lambda x:x-1, v[:2]), 11), 
            'fwyilou1':df.getYilou('fwyilou1', v[0]-1, 11),
            'fwyilou2':df.getYilou('fwyilou2', v[1]-1, 11),
            }
            
        if no == 'qehz':
            hz = sum(v[:2])
            hw = hz%10
            c3 = hz%3
            c4 = hz%4
            c5 = hz%5
            if hz > 11:
                dx = 0
            else:
                dx = 1
                
            if hz%2==1:
                jo = 0
            else:
                jo = 1
                
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'hezhi':hz, 
            'hzyilou':df.getYilou('hzyilou', hz-3, 19), 
            'hewei':hw, 
            'hwyilou':df.getYilou('hwyilou', hw, 10), 
            'c3yilou':df.getYilou('c3yilou', c3, 3),  
            'c4yilou':df.getYilou('c4yilou', c4, 4),  
            'c5yilou':df.getYilou('c5yilou', c5, 5), 
            'dxyilou':df.getYilou('dxyilou', dx, 2), 
            'joyilou':df.getYilou('joyilou', jo, 2), 
            }

        if no == 'qsfw':
            js = sum(map(lambda x:1 if x%2==1 else 0, v[:3]))
            ds = sum(map(lambda x:1 if x>5 else 0, v[:3]))
            
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'fwyilou1':df.getYilou('fwyilou1', v[0]-1, 11),
            'fwyilou2':df.getYilou('fwyilou2', v[1]-1, 11),
            'fwyilou3':df.getYilou('fwyilou3', v[2]-1, 11),
            'jioubi':"%d:%d" % (js, 3-js), 
            'jobyilou':df.getYilou('jobyilou', js, 4), 
            'daxiaobi':"%d:%d" % (ds, 3-ds), 
            'dxbyilou':df.getYilou('dxbyilou', ds, 4), 
            }

        if no == 'qsfb':
            zh = ['111', '110', '101', '011', '100', '010', '001', '000']
            jok = "".join(map(lambda x:'1' if x%2==1 else '0', v[:3]))
            dxk = "".join(map(lambda x:'0' if x>5 else '1', v[:3]))
            
            for i in range(len(zh)):
                if zh[i] == jok:
                    jozhyilou = i
                if zh[i] == dxk:
                    dxbyilou = i
            
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'hhyilou':df.getYilou('hhyilou', map(lambda x:x-1, v[:3]), 11),
            'jozhyilou':df.getYilou('jozhyilou', jozhyilou, 8),
            'dxbyilou':df.getYilou('dxbyilou', dxbyilou, 8),
            }
        
        if no == 'qshz':
            hz = sum(v[:3])
            hw = hz%10
            c3 = hz%3
            if hz > 11:
                dx = 0
            else:
                dx = 1
                
            if hz%2==1:
                jo = 0
            else:
                jo = 1
                
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'hezhi':hz, 
            'hzyilou':df.getYilou('hzyilou', hz-6, 25), 
            'hewei':hw, 
            'hwyilou':df.getYilou('hwyilou', hw, 10), 
            'c3yilou':df.getYilou('c3yilou', c3, 3), 
            }
        
        if no == 'dwzs':
            tz = ['111', '101', '100', '011', '010', '000']
            dx = lambda x:'1' if x < 6 else '0'
            jo = lambda x:'1' if x%2==1 else '0'
            zh = lambda x:'1' if x in [1, 2, 3, 5, 7, 11] else '0'
            
            for i in range(len(tz)):
                
                if tz[i] == '%s%s%s' % (dx(v[0]), jo(v[0]), zh(v[0])):
                    tzyilou1 = i
                if tz[i] == '%s%s%s' % (dx(v[1]), jo(v[1]), zh(v[1])):
                    tzyilou2 = i
                if tz[i] == '%s%s%s' % (dx(v[2]), jo(v[2]), zh(v[2])):
                    tzyilou3 = i
                if tz[i] == '%s%s%s' % (dx(v[3]), jo(v[3]), zh(v[3])):
                    tzyilou4 = i
                if tz[i] == '%s%s%s' % (dx(v[4]), jo(v[4]), zh(v[4])):
                    tzyilou5 = i
            
            #�������ڹ�
            cljg = df.getCljg(v)
            
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'yilou1':df.getYilou('yilou1', v[0]-1, 11), 
            'yilou2':df.getYilou('yilou2', v[1]-1, 11), 
            'yilou3':df.getYilou('yilou3', v[2]-1, 11), 
            'yilou4':df.getYilou('yilou4', v[3]-1, 11), 
            'yilou5':df.getYilou('yilou5', v[4]-1, 11), 
            'tzyilou1':df.getYilou('tzyilou1', tzyilou1, 6), 
            'tzyilou2':df.getYilou('tzyilou2', tzyilou2, 6), 
            'tzyilou3':df.getYilou('tzyilou3', tzyilou3, 6), 
            'tzyilou4':df.getYilou('tzyilou4', tzyilou4, 6), 
            'tzyilou5':df.getYilou('tzyilou5', tzyilou5, 6), 
            'c3yilou1':df.getYilou('c3yilou1', v[0]%3, 3),  
            'c3yilou2':df.getYilou('c3yilou2', v[1]%3, 3),  
            'c3yilou3':df.getYilou('c3yilou3', v[2]%3, 3),  
            'c3yilou4':df.getYilou('c3yilou4', v[3]%3, 3),  
            'c3yilou5':df.getYilou('c3yilou5', v[4]%3, 3), 
            'cljgyilou1':df.getYilou('cljgyilou1', cljg[0], 4), 
            'cljgyilou2':df.getYilou('cljgyilou2', cljg[1], 4), 
            'cljgyilou3':df.getYilou('cljgyilou3', cljg[2], 4), 
            'cljgyilou4':df.getYilou('cljgyilou4', cljg[3], 4), 
            'cljgyilou5':df.getYilou('cljgyilou5', cljg[4], 4), 
            }
            
        if no == 'qezxhz':
            hz = sum(v[:2])
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'hezhi':hz, 
            'hzyilou':df.getYilou('hzyilou', hz-3, 19), 
            }
        
        return indata

def treading(no):
    p = zoushi()
    lot = 'jssyxw'
    type = 'zoushi'
    try:
        df = functions.functions(lot, type, no)
        openList = df.getOpenList()
        if openList:
            atnum = 0
            for o in openList:
                indata = p.getIndata(no, o, df)
                atnum += df.intoDb(indata)
                
            if int(atnum) > 0:
                logging.info('%s %s %s �������� %d ��' % (lot, type, no, atnum))
        
        xlist = [0, 1, 2, 3, 5]
        for x in xlist:
            res = df.setXml(x)   
                      
    except Exception,e:
        logging.info('%s %s %s ִ�д���:%s' % (lot, type, no, e))
        logging.info(traceback.format_exc())
