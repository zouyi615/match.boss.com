#coding=gbk
import os
import XmlConfig
import urllib2
import random
import functions, dbinfo
import logging
import traceback
import time
import threading

_OTHERS_ = {"omit":{}, "xml":{}, "other":{}}

expect = ""

class zoushi:
    def __init__(self):
        pass                
    
    def getIndata(self, no, o, df):
        indata = {}
        
        lr = [8,9,2,6,4,12,7,5,3,1,11,10]
        
        code= o[2].strip().split(",")
        v = map(int, code)
        
        if no == 'zhsx':
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'yilou':df.getYilou('yilou', map(lambda x:x-1, v), 12), 
            }
        
        if no == 'zhlr':
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'yilou':df.getYilou('yilou', map(lambda x:lr.index(x), v), 12), 
            }
            
        if no == 'qysx':
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'yilou':df.getYilou('yilou', v[0]-1, 12), 
            }
        
        if no == 'qylr':
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'yilou':df.getYilou('yilou', lr.index(v[0]), 12), 
            }
            
        if no == 'qesx':
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'yilou1':df.getYilou('yilou1', v[0]-1, 12), 
            'yilou2':df.getYilou('yilou2', v[1]-1, 12), 
            }
        
        if no == 'qelr':
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'yilou1':df.getYilou('yilou1', lr.index(v[0]), 12),
            'yilou2':df.getYilou('yilou2', lr.index(v[1]), 12),
            }
            
        if no == 'qssx':
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'yilou1':df.getYilou('yilou1', v[0]-1, 12), 
            'yilou2':df.getYilou('yilou2', v[1]-1, 12), 
            'yilou3':df.getYilou('yilou3', v[2]-1, 12), 
            }
        
        if no == 'qslr':
            indata = {
            'abbdate':o[0], 
            'expect':o[1], 
            'opencode':o[2].strip(),
            'yilou1':df.getYilou('yilou1', lr.index(v[0]), 12),
            'yilou2':df.getYilou('yilou2', lr.index(v[1]), 12),
            'yilou3':df.getYilou('yilou3', lr.index(v[2]), 12),
            }
        
        return indata

def treading(no):
    p = zoushi()
    lot = 'xysc'
    type = 'zoushi'
    try:
        df = functions.functions(lot, type, no)
        openList = df.getOpenList()
        
        if openList:
            atnum = 0
            for o in openList:
                indata = p.getIndata(no, o, df)
                if indata:
                    atnum += df.intoDb(indata)
            if int(atnum) > 0:
                logging.info('%s %s %s �������� %d ��' % (lot, type, no, atnum))
        
        xlist = [0, 1, 2, 3, 5]
        for x in xlist:
            res = df.setXml(x)
        
        #zhsx�������ִ��omit, other
        if no == "zhsx":
            import omit, other
            
            #������©����
            nolist = ['qyyl', 'qezhixyl', 'qezuxyl', 'qszhixyl', 'qszuxyl']
            for on in nolist:
                #������©����
                if _OTHERS_["omit"].get(on)==None or _OTHERS_["omit"][on].isAlive() == False:                
                    _OTHERS_["omit"][on] = threading.Thread(target = omit.treading, args = (on, ))
                    _OTHERS_["omit"][on].start()
                    
                #����XML�߳�
                if _OTHERS_["xml"].get(on)==None or _OTHERS_["xml"][on].isAlive() == False:                
                    _OTHERS_["xml"][on] = threading.Thread(target = omit.setxml, args = (on, ))
                    _OTHERS_["xml"][on].start()
                
            for on in ['lrfx', 'lrtj']:
                if _OTHERS_.get("other") and _OTHERS_["other"].get(on) and _OTHERS_["other"][on].isAlive() == True:
                    continue
                _OTHERS_["other"][on] = threading.Thread(target = other.treading, args = (on, ))
                _OTHERS_["other"][on].start()
                      
    except Exception,e:
        logging.info('%s %s %s ִ�д���:%s' % (lot, type, no, e))
        logging.info(traceback.format_exc())
