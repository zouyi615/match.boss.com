#coding=gbk
import os
import urllib2
import random
import logging
import traceback
import datetime
import time

from BeautifulSoup import BeautifulSoup, Tag

import XmlConfig

from core import base
from dbinfo import dbinfo

expect = ""

class other():
    def __init__(self, lot, type, no):
        self.lot = lot
        self.type = type
        self.no = no       
        self.dbinfo = dbinfo(lot, type, no)         
    
    def run(self):
        
        conf = XmlConfig.get('/config/define')        
        
        nowDate = str(datetime.datetime.now())[0:10].replace("-", "")
        where = " abbdate = '%s'" % nowDate
        hmList = self.dbinfo.getCodeList(0, where)

        if not hmList or len(hmList) < 3:
            yesDate = str(datetime.datetime.now()+datetime.timedelta(days=-1))[0:10].replace("-", "")
            where = " abbdate = '%s'" % yesDate
            hmList += self.dbinfo.getCodeList(0, where)
        if not hmList:
            hmList = self.dbinfo.getCodeList(0)

        dateList = {}
        for hm in hmList:
            if dateList.get(hm["abbdate"]) == None:
                dateList[hm["abbdate"]] = []
                
            dateList[hm["abbdate"]].append(hm)
        
        for date in dateList:
            oxml = self.getSj(dateList[date])
            
            soup = BeautifulSoup('<?xml version="1.0" encoding="utf-8"?><xml></xml>')
            
            xml = soup.find("xml")
        
            gj = Tag(soup, "gj")
            for d in oxml[0]:
                r = Tag(soup, "row")
                r["code"] = d["code"] < 10 and "0%s" % d["code"] or d["code"]
                r["num"] = d["num"]
                gj.append(r)
            xml.append(gj)
        
            yj = Tag(soup, "yj")
            for d in oxml[1]:
                r = Tag(soup, "row")
                r["code"] = d["code"] < 10 and "0%s" % d["code"] or d["code"]
                r["num"] = d["num"]
                yj.append(r)
            xml.append(yj)
        
            jj = Tag(soup, "jj")
            for d in oxml[2]:
                r = Tag(soup, "row")
                r["code"] = d["code"] < 10 and "0%s" % d["code"] or d["code"]
                r["num"] = d["num"]
                jj.append(r)
            xml.append(jj)
        
            wz = Tag(soup, "wz")
            for i in xrange(len(oxml[0])):
                
                r = Tag(soup, "row")
                r["code"] = oxml[0][i]["code"] < 10 and "0%s" % oxml[0][i]["code"] or oxml[0][i]["code"]
                r["num"] = sum((oxml[0][i]["num"], oxml[1][i]["num"], oxml[2][i]["num"]))
                wz.append(r)
            xml.append(wz)
            
            path = conf["xml"] % (self.lot, self.type, self.no, date)
            
            atnum = base.upload(conf["FileServerURL"], path, soup)
            
        #�����ھ�ͳ�� ��6��7�տ�ʼͳ��
        head = {"date":"2013-06-06", "count":0}
        gjdata = {}
        for i in xrange(12):
            code = (i<9) and "0%d" % (i+1) or str(i+1)
            gjdata[code] = {"code":code, "average":0, "min":-1, "max":-1}

        path = "/static/info/xysc/other/gjtj.xml"
        
        res = base.fopen("http://zx.500boss.com%s" % path)
        today = datetime.date.today()
        if res:
            soap = BeautifulSoup(res)
            head = soap.find("head")
            if head:
                head["count"] = int(head["count"])
                if head["date"] == str(today):
                    return
                else:
                    for r in soap.find("gj").findAll("row"):
                        gjdata[r["code"]] = r
        
        Y, m, d = map(int, head["date"].split("-"))
        i = datetime.date(Y, m, d)
        
        while i < today :
            i += datetime.timedelta(days = 1)
            
            url = "http://resources.500wan.com" + conf["xml"] % (self.lot, self.type, self.no, i.strftime('%Y%m%d'))
            res = base.fopen(url)
            soap = BeautifulSoup(res)
            
            if soap and soap.find("gj"):
                for r in soap.find("gj").findAll("row"):
                    v = int(r["num"])
                    avg = float(gjdata[r["code"]]["average"])
                    ov = avg*head["count"]
                    gjdata[r["code"]]["average"] = "%.2f" % ((ov+v)/(head["count"]+1))
                    min = int(gjdata[r["code"]]["min"])
                    if min==-1 or v<min:
                        gjdata[r["code"]]["min"] = v
                    max = int(gjdata[r["code"]]["max"])
                    if min==-1 or v>max:
                        gjdata[r["code"]]["max"] = v
                head["count"] += 1
            else:
                base.write_log("�ھ�ͳ�� %s no found" % url)
        
        soup = BeautifulSoup('<?xml version="1.0" encoding="utf-8"?><xml></xml>')
        xml = soup.find("xml")
        h = Tag(soup, "head")
        h["date"] = i
        h["count"] = head["count"]
        
        gj = Tag(soup, "gj")
        for i in xrange(12):
            r = Tag(soup, "row")
            code = (i<9) and "0%d" % (i+1) or str(i+1)
            r["code"] = code
            r["average"] = gjdata[code]["average"]
            r["min"] = gjdata[code]["min"]
            r["max"] = gjdata[code]["max"]
            gj.append(r)
        xml.append(h)
        xml.append(gj)
        
        atnum = base.upload(conf["FileServerURL"], path, soup)
    
    def lrfx(self):
        explist = {}
        
        #���100������
        hmList = self.dbinfo.getCodeList(100)
        data = self.getSj(hmList)

        #���ȷ��� top2
        soup = BeautifulSoup('<?xml version="1.0" encoding="utf-8"?><xml>')
        
        xml = soup.find("xml")
        
        gjrh = Tag(soup, "gjrh")
        for d in sorted(data[0], key=lambda x:int(x["num"]), reverse=True)[0:2]:
            r = Tag(soup, "row")
            r["code"] = d["code"] < 10 and "0%s" % d["code"] or d["code"]
            r["num"] = d["num"]
            gjrh.append(r)
        xml.append(gjrh)
        
        gjlh = Tag(soup, "gjlh")
        for d in sorted(data[0], key=lambda x:int(x["num"]), reverse=False)[0:2]:
            r = Tag(soup, "row")
            r["code"] = d["code"] < 10 and "0%s" % d["code"] or d["code"]
            r["num"] = d["num"]
            gjlh.append(r)
        xml.append(gjlh)
        
        yjrh = Tag(soup, "yjrh")
        for d in sorted(data[1], key=lambda x:int(x["num"]), reverse=True)[0:2]:
            r = Tag(soup, "row")
            r["code"] = d["code"] < 10 and "0%s" % d["code"] or d["code"]
            r["num"] = d["num"]
            yjrh.append(r)
        xml.append(yjrh)
        
        yjlh = Tag(soup, "yjlh")
        for d in sorted(data[1], key=lambda x:int(x["num"]), reverse=False)[0:2]:
            r = Tag(soup, "row")
            r["code"] = d["code"] < 10 and "0%s" % d["code"] or d["code"]
            r["num"] = d["num"]
            yjlh.append(r)
        xml.append(yjlh)
        
        jjrh = Tag(soup, "jjrh")
        for d in sorted(data[2], key=lambda x:int(x["num"]), reverse=True)[0:2]:
            r = Tag(soup, "row")
            r["code"] = d["code"] < 10 and "0%s" % d["code"] or d["code"]
            r["num"] = d["num"]
            jjrh.append(r)
        xml.append(jjrh)
        
        jjlh = Tag(soup, "jjlh")
        for d in sorted(data[2], key=lambda x:int(x["num"]), reverse=False)[0:2]:
            r = Tag(soup, "row")
            r["code"] = d["code"] < 10 and "0%s" % d["code"] or d["code"]
            r["num"] = d["num"]
            jjlh.append(r)
        xml.append(jjlh)
        
        conf = XmlConfig.get('/config/define')
        path = conf["xml"] % (self.lot, self.type, self.no, 100)
        
        atnum = base.upload(conf["FileServerURL"], path, soup)
        
    def getSj(self, hmList):
        
        oxml = [[{"code":i+1, "num":0} for i in xrange(12)], [{"code":i+1, "num":0} for i in xrange(12)], [{"code":i+1, "num":0} for i in xrange(12)]]
        for hm in hmList:
            code = hm['opencode'].split(",")
            for i in xrange(len(code)):
                j = int(code[i])-1
                oxml[i][j]["num"] += 1
                
        return oxml

def treading(no):
    lot = 'xysc'
    type = 'other'
    p = other(lot, type, no)
    try:
        if no == 'lrfx':
            p.lrfx()
        else:
            p.run()
    except Exception,e:
        base.write_log('%s %s %s ִ�д���:%s' % (lot, type, no, e))
        base.write_log(traceback.format_exc())
