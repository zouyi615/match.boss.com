#coding=gbk
import os
import XmlConfig
import urllib2
import random
import functions, dbinfo
import logging
import traceback
import time
status = 0

class zoushi:
    def __init__(self):
        pass                
    
    def getIndata(self, no, o, df):
        indata = {}

        code= o[2].strip().split(",")
        v = map(int, code)
        
        if df.lcode:
            lcode = df.lcode.strip().split(",")
        else:
            lcode = []
        
        if no == 'fbzs':
            
            ncode = []
            ocode = []
            for c in code:
                if c in lcode:
                    ocode.append(c)
                else:
                    ncode.append(c)
                    
            gs = len(v)
            ds = sum(map(lambda x:1 if x>10 else 0, v))
            xs = gs-ds
            kd = max(v) - min(v)
            
            indata = {
            'expect':o[1], 
            'opencode':o[2].strip(),
            'abbdate':o[0], 
            'newcode':",".join(ncode),
            'oldcode':",".join(ocode), 
            'daxiaobi':"%s:%s" % (ds, xs), 
            'kuadu':kd, 
            'maxcode':max(v), 
            'yiloucode':df.getYilou('yiloucode', map(lambda x:x-1, v), 20), 
            }
            
        if no == 'dwzs':
            dxv = map(lambda x:0 if x>10 else 1, v)
            jov = map(lambda x:1 if x%2==0 else 0, v)
            zhv = map(lambda x:0 if int(x) in [1,2,3,5,7,11,13,17,19] else 1, v)
            
            indata = {
            'expect':o[1], 
            'opencode':o[2].strip(),
            'abbdate':o[0], 
            'yiloucode1':df.getYilou('yiloucode1', v[0]-1, 20),
            'yiloucode2':df.getYilou('yiloucode2', v[1]-1, 20),
            'yiloucode3':df.getYilou('yiloucode3', v[2]-1, 20),
            'yiloucode4':df.getYilou('yiloucode4', v[3]-1, 20),
            'yiloucode5':df.getYilou('yiloucode5', v[4]-1, 20),
            'yiloucode6':df.getYilou('yiloucode6', v[5]-1, 20),
            'yiloucode7':df.getYilou('yiloucode7', v[6]-1, 20),
            'yiloucode8':df.getYilou('yiloucode8', v[7]-1, 20),
            'daxiao1':df.getYilou('daxiao1', dxv[0], 2),
            'daxiao2':df.getYilou('daxiao2', dxv[1], 2),
            'daxiao3':df.getYilou('daxiao3', dxv[2], 2),
            'daxiao4':df.getYilou('daxiao4', dxv[3], 2),
            'daxiao5':df.getYilou('daxiao5', dxv[4], 2),
            'daxiao6':df.getYilou('daxiao6', dxv[5], 2),
            'daxiao7':df.getYilou('daxiao7', dxv[6], 2),
            'daxiao8':df.getYilou('daxiao8', dxv[7], 2),
            'jiou1':df.getYilou('jiou1', jov[0], 2),
            'jiou2':df.getYilou('jiou2', jov[1], 2),
            'jiou3':df.getYilou('jiou3', jov[2], 2),
            'jiou4':df.getYilou('jiou4', jov[3], 2),
            'jiou5':df.getYilou('jiou5', jov[4], 2),
            'jiou6':df.getYilou('jiou6', jov[5], 2),
            'jiou7':df.getYilou('jiou7', jov[6], 2),
            'jiou8':df.getYilou('jiou8', jov[7], 2),
            'zhihe1':df.getYilou('zhihe1', zhv[0], 2),
            'zhihe2':df.getYilou('zhihe2', zhv[1], 2),
            'zhihe3':df.getYilou('zhihe3', zhv[2], 2),
            'zhihe4':df.getYilou('zhihe4', zhv[3], 2),
            'zhihe5':df.getYilou('zhihe5', zhv[4], 2),
            'zhihe6':df.getYilou('zhihe6', zhv[5], 2),
            'zhihe7':df.getYilou('zhihe7', zhv[6], 2),
            'zhihe8':df.getYilou('zhihe8', zhv[7], 2),
            }
            
        if no == 'slz':
            pl = ['000', '001', '010', '100', '011', '101', '110', '111']
            jov = map(lambda x:'0' if x%2==1 else '1', v[:3])
            zhv = map(lambda x:'0' if x<11 else '1', v[:3])
            
            for i in range(len(pl)):
                if "".join(jov) == pl[i]:
                    jozuhe = i
                if "".join(zhv) == pl[i]:
                    zhzuhe = i

            indata = {
            'expect':o[1], 
            'opencode':o[2][0:8].strip(),
            'abbdate':o[0], 
            'yiloucode':df.getYilou('yiloucode', map(lambda x:x-1, v[:3]), 20), 
            'jiouzuhe':df.getYilou('jiouzuhe', jozuhe, len(pl)), 
            'daxiaozuhe':df.getYilou('daxiaozuhe', zhzuhe, len(pl)), 
            }
                
        return indata

def treading(seconds, no):
    p = zoushi()
    lot = 'klsf'
    type = 'zoushi'
    while int(status):
        try:
            df = functions.functions(lot, type, no)
            openList = df.getOpenList()
            if openList:
                atnum = 0
                for o in openList:
                    indata = p.getIndata(no, o, df)                
                    atnum += df.intoDb(indata)
                    df.lcode = o[2].strip()
                
                if int(atnum) > 0:
                    logging.info('%s %s %s �������� %d ��' % (lot, type, no, atnum))
            
            xlist = [0, 1, 2, 3, 5]
            for x in xlist:
                res = df.setXml(x)             
        except Exception,e:
            logging.info('%s %s %s ִ�д���:%s' % (lot, type, no, e))
            logging.info(traceback.format_exc())
        #logging.info('sleep %d seconds.' % (seconds))
        time.sleep(seconds)
