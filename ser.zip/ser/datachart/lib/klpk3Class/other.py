#coding=gbk
import os
import urllib2
import random
import logging
import traceback
import datetime
import time

from BeautifulSoup import BeautifulSoup, Tag

import XmlConfig

from core import base
from dbinfo import dbinfo

expect = ""

class other():
    def __init__(self, lot, type, no):
        self.lot = lot
        self.type = type
        self.no = no       
        self.dbinfo = dbinfo(lot, type, no)         
    
    def run(self):
        explist = {}
        
        #���100������
        hmList = self.dbinfo.getCodeList(100)
        data = self.getSj(hmList)

        #���ȷ��� top2
        soup = BeautifulSoup('<?xml version="1.0" encoding="utf-8"?><xml>')
        
        xml = soup.find("xml")
        
        gjrh = Tag(soup, "rh")
        for d in sorted(data, key=lambda x:int(x["num"]), reverse=True)[0:2]:
            r = Tag(soup, "row")
            r["code"] = d["code"] < 10 and "0%s" % d["code"] or d["code"]
            r["num"] = d["num"]
            gjrh.append(r)
        xml.append(gjrh)
        
        gjlh = Tag(soup, "lh")
        for d in sorted(data, key=lambda x:int(x["num"]), reverse=False)[0:2]:
            r = Tag(soup, "row")
            r["code"] = d["code"] < 10 and "0%s" % d["code"] or d["code"]
            r["num"] = d["num"]
            gjlh.append(r)
        xml.append(gjlh)
        
        conf = XmlConfig.get('/config/define')
        path = conf["xml"] % (self.lot, self.type, self.no, 100)
        
        atnum = base.upload(conf["FileServerURL"], path, soup)
        
    def getSj(self, hmList):
        
        oxml = [{"code":i+1, "num":0} for i in xrange(13)]
        for hm in hmList:

            code = hm['opencode'].split("|")[0].split(",")
            
            for i in xrange(len(code)):
                j = int(code[i])-1
                oxml[j]["num"] += 1
                
        return oxml

def treading(no):
    lot = 'klpk3'
    type = 'other'
    p = other(lot, type, no)
    try:
        p.run()
    except Exception,e:
        base.write_log('%s %s %s ִ�д���:%s' % (lot, type, no, e))
        base.write_log(traceback.format_exc())
