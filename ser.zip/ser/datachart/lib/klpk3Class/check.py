#coding=gbk
def addExt(m):
    return m>-1 and [0, m] or -1

class check:
    
    def __init__(self, scode):
        code = scode.strip().split("|")
        self.hs = ['S', 'H', 'C', 'D']
        self.v, self.h = sorted(map(int, code[0].split(","))), code[1].split(",")
        self.sv, self.sh = map(lambda x:sorted(list(set(x)), key=lambda y:x.index(y)), (self.v, self.h))
        
        #��������
        self.lx = []
        #����
        if len(self.sv)==2:
            self.lx.append(0)
            
        #����
        if len(self.sv)==1:
            self.lx.append(1)
        
        #ͬ��
        if len(self.sh)==1:
            self.lx.append(2)
            
        #����ͬ
        if len(self.sv)==3:
            self.lx.append(5)
            #˳��
            if (self.sv == [1,12,13] or (self.sv[2]-self.sv[1]==1 and self.sv[1]-self.sv[0]==1)):
                self.lx.append(3)
                
                #ͬ��˳
                if len(self.sh)==1:
                    self.lx.append(4)
    
    def dzst(self):
        dz = st = -1
        if 1 in self.lx:
            st = self.sv[0]
        elif 0 in self.lx:
            dz = self.v.count(self.sv[0])==2 and self.sv[0] or self.sv[1]
        return addExt(dz), addExt(st)
    
    def szth(self):
        sz = th = -1
        if 3 in self.lx:
            sz = self.sv == [1,12,13] and 12 or self.sv[0]
            if 4 in self.lx:
                th = self.hs.index(self.sh[0])+1
        return addExt(sz), addExt(th)
    
    def thhs(self):
        th = hs = -1
        if 2 in self.lx:
            th = self.hs.index(self.sh[0])+1
        else:
            if self.hs[1] not in self.sh and self.hs[3] not in self.sh:
                hs = 0
            elif self.hs[0] not in self.sh and self.hs[2] not in self.sh:
                hs = 1
        return addExt(th), hs

