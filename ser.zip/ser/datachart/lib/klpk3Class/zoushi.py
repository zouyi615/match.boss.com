#coding=gbk
import os
import XmlConfig
import urllib2
import random
import functions, dbinfo
import logging
import traceback
import time
import threading


import check

expect = ""
_OTHERS_ = {"omit":{}, "xml":{}, "other":{}}

class zoushi:
    def __init__(self):
        pass
    
    def getIndata(self, no, o, df):
        indata = {}
        
        #01,02,03|S,S,S �� ����1-13 �� S = ���� H = ���� D = ��Ƭ C = ÷��
        checkobj = check.check(o[2])
        
        if no == 'rxzs':
            v = checkobj.v
            lx = checkobj.lx
            indata = {
                'abbdate':o[0], 
                'expect':o[1], 
                'opencode':o[2].strip(),
                'yilou':df.getYilou('yilou', map(lambda x:x-1, v), 13), 
                'xt':df.getYilou('xt', lx, 6), 
            }
        
        if no == 'thzs':
            dz, st = checkobj.dzst()
            indata = {
                'abbdate':o[0], 
                'expect':o[1], 
                'opencode':o[2].strip(),
                'dz':df.getYilou('dz', dz, 14), 
                'st':df.getYilou('st', st, 14), 
            }
            
        if no == 'szzs':
            sz, th = checkobj.szth()
            indata = {
                'abbdate':o[0], 
                'expect':o[1], 
                'opencode':o[2].strip(),
                'sz':df.getYilou('sz', sz, 13), 
                'th':df.getYilou('th', th, 5), 
            }
            
        if no == 'hszs':
            th, hs = checkobj.thhs()
            indata = {
                'abbdate':o[0], 
                'expect':o[1], 
                'opencode':o[2].strip(),
                'th':df.getYilou('th', th, 5), 
                'hs':df.getYilou('hs', hs, 2), 
            }
        
        return indata

def treading(no):
    p = zoushi()
    lot = 'klpk3'
    type = 'zoushi'
    try:
        df = functions.functions(lot, type, no)
        openList = df.getOpenList()
        
        if openList:
            atnum = 0
            for o in openList:
                indata = p.getIndata(no, o, df)
                if indata:
                    atnum += df.intoDb(indata)
            if int(atnum) > 0:
                logging.info('%s %s %s �������� %d ��' % (lot, type, no, atnum))
        
        xlist = [0, 1, 2, 3, 5]
        for x in xlist:
            res = df.setXml(x)
            
        
        #rxzs�������ִ��omit, other
        if no == "rxzs":
            import other
            
            for on in ['lrfx']:
                if _OTHERS_.get("other") and _OTHERS_["other"].get(on) and _OTHERS_["other"][on].isAlive() == True:
                    continue
                _OTHERS_["other"][on] = threading.Thread(target = other.treading, args = (on, ))
                _OTHERS_["other"][on].start()
                      
    except Exception,e:
        logging.info('%s %s %s ִ�д���:%s' % (lot, type, no, e))
        logging.info(traceback.format_exc())
