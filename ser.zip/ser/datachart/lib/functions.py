#coding=gbk
import XmlConfig
import urllib, urllib2
import random
import dbinfo
import datetime
from BeautifulSoup import BeautifulSoup
from core import base

class functions:
    def __init__(self, lot, type, no):
            self.lcode = ""
            self.lot = lot
            self.type = type
            self.no = no
            self.dbinfo = dbinfo.dbinfo(lot, type, no)
            self.l = {}        
    
    def getOpenList(self):
        
        conf = XmlConfig.get('/config/%s' % (self.lot))
        newOrder = self.dbinfo.getLastOrder()

        openList = []
        if newOrder:
            url = conf['opencode']
            resp = urllib2.urlopen(url)
            if resp:
                soap = BeautifulSoup(resp)
                if soap.findAll("row"):
                    start = 0
                    #�����ں���������
                    explist = []
                    lastexpect = ''
                    for r in soap.findAll("row"):
                        if lastexpect and r['expect'] < lastexpect:
                            explist.insert(0, r)
                        else:
                            explist.append(r)
                        lastexpect = r['expect']
                        
                    for r in explist:
                        if start:
                            openList.append((int(r['abbdate']), r['expect'], r['opencode']))
                        if newOrder['expect'] == r['expect']:
                            start = 1
                            self.lcode = r['opencode']
                
            if not openList:
                if conf.get("table"):
                    oraleList = self.dbinfo.getOraleOpenCodeList(conf.get("table"))
                    start = 0
                    for r in oraleList:
                        if start:
                            openList.append(r)
                        if newOrder['expect'] == r[1]:
                            start = 1
                            self.lcode = r[2]
            
        else:
            #��oracle������������
            if conf.get("table"):
                openList = self.dbinfo.getOraleOpenCodeList(conf.get("table"))
            
        if openList:
            openList = sorted(openList, key=lambda openList : openList[1])
        
        return openList
    
    #��0��ʼ����
    def getYilou(self, key, code, num):
        if type(code) != list:
            code = [code]
        new = []
        if num and num > 0:
            newOrder = self.dbinfo.getLastOrder()
            old = []
            if newOrder:
                old = newOrder[key].split(",")
            else:
                for i in range(num):
                    old.append(0)
            
            new = map(lambda x:'0' if x in code else str(int(old[x])+1) , range(num))
        return ",".join(new)
    
    def getCljg(self, v):
        cljg = []
        if v:
            newOrder = self.dbinfo.getLastOrder()
            if newOrder:
                o = map(int, newOrder['opencode'].split(","))
                for i in range(len(v)):
                    if v[i] == o[i]:
                        cljg.append(0)
                    else:
                        if abs(v[i]-o[i])==1:
                            cljg.append(1)
                        else:
                            if abs(v[i]-o[i])==2:
                                cljg.append(2)
                            else:
                                cljg.append(3)
            else:
                for i in range(len(v)):
                    cljg.append(3)
        return cljg
        
    def setLfromdb(self):
        self.l = self.dbinfo.getYilouList()
        
    def setL(self):
        self.l = {}
    
    def g(self, k, x, y):
        if self.l.get(str(k)):
            return self.l[str(k)][x]
        else:
            return y
    
    def resetData(self, openList, gl, zpl):
        if self.l:
            for k in self.l:
                if type(gl) == dict:
                    cycle = float(gl[k])/zpl
                else:
                    cycle = float(gl)/zpl
                    
                zcs = int(self.l[k]['type'])
                pjyl = float(self.l[k]['zyl'])/zcs
                if cycle:
                    hbjl = float(int(self.l[k]['scyl'])-int(self.l[k]['bcyl']))/cycle
                else:
                    hbjl = cycle
                self.l[k]['type'] = zcs
                self.l[k]['llcxcs'] = '%.2f' % (zcs*cycle)
                self.l[k]['pjyl'] = '%.2f' % pjyl
                self.l[k]['cxpl'] = '%.3f%%' % (float(self.l[k]['cxcs'])/zcs*100)
                self.l[k]['ycjl'] = '%.2f' % (pjyl and float(self.l[k]['bcyl'])/pjyl)
                self.l[k]['hbjl'] = '%.2f' % hbjl
            
                self.l[k]['zdylqj'] = self.dbinfo.getZdylqj(self.l[k]['zdylqj'], self.l[k]['zdyl'])
        return self.l
    
    def getOmitData(self, kv, v, o):
        row = {}
        for k in kv:
            tmp = {}
            if v(k):
                cxcs = int(self.g(k, 'cxcs', 0))+1
                if int(self.g(k, 'bcyl', 0)) != 0:
                    scyl = int(self.g(k, 'bcyl', 0))
                else:
                    scyl = int(self.g(k, 'scyl', 0))
                bcyl = 0
            else:
                cxcs = int(self.g(k, 'cxcs', 0))
                scyl = int(self.g(k, 'scyl', 0))
                bcyl = int(self.g(k, 'bcyl', 0))+1
            
            zdyl = int(self.g(k, 'zdyl', 0))
            zdylqj = str(self.g(k, 'zdylqj', ''))

            if "-" in zdylqj:
                zdylqj = zdylqj.split("-")[1]
            
            if bcyl >= zdyl:
                zdyl = bcyl
                zdylqj = o[1]
                
            tmp['expect'] = o[1]
            tmp['type'] = int(self.g(k, 'type', 0))+1
            tmp['zyl'] = int(self.g(k, 'zyl', 0))+bcyl
            tmp['code'] = k
            tmp['cxcs'] = cxcs
            tmp['zdyl'] = zdyl
            tmp['scyl'] = scyl
            tmp['bcyl'] = bcyl
            tmp['zdylqj'] = zdylqj
            
            if not row.get(str(tmp['code'])):
                row[str(tmp['code'])] = {}
            row[str(tmp['code'])].update(tmp)
            
        self.l = row
        
    def intoDb(self, indata, kv = {}):
        table = "t_chart_%s_%s_%s" % (self.lot, self.type, self.no)
        if indata:
            if self.type == 'zoushi':
                return self.dbinfo.insert(table, indata)
            else:
                n = 0
                if self.type == 'omit':
                    if not kv:
                        kv = sorted(indata.keys())
                    keylist = []
                    vallist = []
                    for d in kv:
                        if not keylist:
                            keylist = indata[d].keys()
                        vallist.append(indata[d].values())
                    keystr = "(%s)" % (",".join(keylist))
                    valstr = "(%s)" % ("),(".join(map(lambda x:"'%s'" % ("','".join(map(str, x))) ,vallist)))
                    
                    sql = "REPLACE INTO %s %s VALUES %s" % (table, keystr, valstr)
                    #����ձ�
                    self.dbinfo.truncate(table)
                    #�ٲ����
                    n += int(self.dbinfo.query(sql))
                return n
        
    def setXml(self, t, list={}):
        oxml = []
        if self.type == 'zoushi':
            where = "1=1"
            limit = ""
            if t:
                last = str(datetime.datetime.today()-datetime.timedelta(days=(t-1)))[0:10].replace("-", "")
            if t == 0:
                limit = "limit 50"
            else:
                if t == 1 or t == 2:
                    where = "abbdate = '%s'" % last
                else:
                    where = "abbdate >= '%s'" % last
            list = self.dbinfo.getOrderList(where, limit)
        else:
            oxml = ["type","code","cxcs","llcxcs","cxpl","pjyl","zdyl","scyl","bcyl","ycjl","hbjl","zdylqj"]
            if t == 0:
                list = self.dbinfo.getYilouOrder()
        
        conf = XmlConfig.get('/config/define')
        FileServerURL = conf['FileServerURL']
        path = conf['xml'] % (self.lot, self.type, self.no, t)
        sxml = '<?xml version="1.0" encoding="utf-8"?><xml>'
        if list:
            for l in list:
                if l:
                    dstr = ''
                    if not oxml:
                        oxml = l.keys()
                    for k in oxml:
                        if k != 'id':
                            dstr += ' %s="%s"' % (k, l[k])
                    sxml += '<row%s/>' % (dstr)
        sxml += '</xml>'
        atnum = base.upload(FileServerURL, path, sxml.encode('utf-8'))
        return atnum
        
    def getLivedata(self, t):
        rows = self.dbinfo.getCodeList(t)
        openList = []
        if rows:
            for r in rows:
                openList.append((int(r['abbdate']), r['expect'], r['opencode']))
        if openList:
            openList = sorted(openList, key=lambda openList : openList[1])
        return openList
    
    def getUrl(self, url):
        if url:
            num = random.randint(1, 3)
            conf = XmlConfig.get('/config/define')
            return conf['daili'] % (num, url)
        return ''
