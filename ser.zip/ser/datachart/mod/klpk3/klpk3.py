# coding:gbk
import Eas.Function
import logging
import XmlConfig
import threading
import urllib2
import time
import traceback

from klpk3Class import zoushi
from BeautifulSoup import BeautifulSoup

def getNexpect():
    global nexpect
    conf = XmlConfig.get("/config/klpk3")
    expectUrl = conf["newopencode"]
    while True:
        try:
            res = urllib2.urlopen(expectUrl)
            if res:
                soup = BeautifulSoup(res)
                if soup:
                    if soup.find("row") and soup.find("row").get("expect"):
                        nexpect = soup.find("row").get("expect")
        except Exception,e:
            logging.info(traceback.format_exc())
            time.sleep(10)
        time.sleep(1)

def runData(obj, no):
    global nexpect
    while True:
        try:
            if obj.expect!=nexpect:
                obj.treading(no)
                obj.expect = nexpect
        except Exception,e:
            logging.info(traceback.format_exc())
            time.sleep(10)
        time.sleep(1)

def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''
    global nexpect
    nexpect = ""
    #�����ںż���߳�
    th = threading.Thread(target = getNexpect)
    th.start()
    
    #������������
    nolist = ['rxzs', 'thzs', 'szzs', 'hszs']
    for no in nolist:
        threading.Thread(target = runData, args = (zoushi, no)).start()
    
    return Eas.Function.get_method_dict(object, prefix+'/')