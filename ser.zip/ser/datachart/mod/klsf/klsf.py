# coding: gbk
import EasClient
import Eas.Extend
import Eas.Function
import logging
import traceback
import threading
import XmlConfig
from klsfClass import zoushi, omit

class Server(Eas.Extend.Common):
    def __init__(self):
        self.name = '����ʮ��'
        pass
        
    def zoushi(self, status):
        okey = '����ͼ��'
        if not int(zoushi.status) and int(status) == 1:
            zoushi.status = status
            nolist = ['fbzs', 'dwzs', 'slz']
            for no in nolist:
                th1 = threading.Thread(target = zoushi.treading, args = (60, no))
                th1.start()
            logging.info('%s %s�߳̿���' % (self.name, okey))
        else:
            if int(zoushi.status) and int(status) == 0:
                zoushi.status = status
                logging.info('%s %s�̹߳ر�' % (self.name, okey))
                
        return self._result({'status':str(zoushi.status)}, [])
        
    def omit(self, status):
        okey = '��©����'
        if not int(omit.status) and int(status) == 1:
            omit.status = status
            nolist = ['hmyl', 'slzyl', 'sqzyl', 'wmyl']
            for no in nolist:
                th1 = threading.Thread(target = omit.treading, args = (60, no))
                th1.start()
            logging.info('%s %s�߳̿���' % (self.name, okey))
        else:
            if int(omit.status) and int(status) == 0:
                omit.status = status
                logging.info('%s %s�̹߳ر�' % (self.name, okey))
                
        return self._result({'status':str(omit.status)}, [])
        
    
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''
    p =Server()
    p.zoushi(1)
    p.omit(1)
    return Eas.Function.get_method_dict(p, prefix+'/')    
