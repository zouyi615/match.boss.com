# coding: gbk
import EasClient
import Eas.Extend
import Eas.Function
import logging
import traceback
import threading

import JsonUtil
import XmlConfig

import Timer
_TH_ = {}
_OT_ = []

class Server(Eas.Extend.Common):
    def start(self, _lot, _types, debug=False):
        global _TH_
        if debug:
            sec = 0
        else:
            sec = 60
                            
        for t in _types.split(","):
            if _TH_.get(_lot) is None:
                _TH_[_lot] = {}

            for i in xrange(2):
                if _TH_[_lot].get(t) is None:
                    _TH_[_lot][t] = {}
                
                if _TH_[_lot][t].get(i)==None or _TH_[_lot][t][i].isAlive() == False:
                    lastExpect = (i>0) and True or False
                    th = Timer.Timer(_lot, t, sec, debug, lastExpect)
                    th._status = True
                    th.start()
                    if debug:
                        th.join()
                    _TH_[_lot][t][i] = th
                elif _TH_[_lot][t][i]._status == False:
                    _TH_[_lot][t][i]._status = True
                    
        return self.stat()
            
    def other(self, _lot, _types, expect, debug=False):
        global _OT_
        if expect:
            over = True
            if _OT_:
                for t in _OT_:
                    if t.isAlive():
                        over = False
            
            if over:
                _OT_ = []
                for t in _types.split(","):
                    th = Timer.Timer(_lot, t, 0, debug, expect)
                    th.start()
                    _OT_.append(th)
            
        return self.stat()
        
    def stop(self, _lot, _types):
        global _TH_
        for t in _types.split(","):
            if _TH_.get(_lot) and _TH_[_lot].get(t):
                for i in xrange(2):
                    _TH_[_lot][t][i]._status = False
        return self.stat()
                
    def stat(self):
        global _TH_
        res = {}
        for l in _TH_:
            res[l] = {}
            for t in _TH_[l]:
                res[l][t] = {"status":_TH_[l][t][0]._status, "alive":_TH_[l][t][0].isAlive()}
        return self._result({"DATA":JsonUtil.write(res)})
    
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''    
    p =Server()
    #����aiboץȡ
    p.start("ab", "spf,zjq,dcbf,sxds,bqc")
    
    #����bjdcsf
    p.start("bjdcsf", "sf")
    return Eas.Function.get_method_dict(p, prefix+'/')