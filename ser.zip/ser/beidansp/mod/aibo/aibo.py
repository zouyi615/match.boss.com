# coding: gbk
import EasClient
import Eas.Extend
import Eas.Function
import logging
import traceback
import threading
import XmlConfig
from aiboClass import spf, sxds, zjq, dcbf, bqc

class Server(Eas.Extend.Common):
    def __init__(self):
        self.name = '����'
        
    def spf(self, status, expect):
        okey = 'ʤƽ��'           
        if not int(spf.status) and int(status) == 1:
            spf.status = status
            th1 = threading.Thread(target = spf.checkall, args = (60, expect))
            th1.start()
            logging.info('%s����%s�߳̿���' % (self.name, okey))
        else:
            if int(spf.status) and int(status) == 0:
                spf.status = status
                logging.info('%s����%s�̹߳ر�' % (self.name, okey))
                
        return self._result({'status':str(spf.status)}, [])
        
    def sxds(self, status, expect):
        okey = '���µ�˫'
        if not int(sxds.status) and int(status) == 1:
            sxds.status = status
            th1 = threading.Thread(target = sxds.checkall, args = (60, expect))
            th1.start()
            logging.info('%s����%s�߳̿���' % (self.name, okey))
        else:
            if int(sxds.status) and int(status) == 0:
                sxds.status = status
                logging.info('%s����%s�̹߳ر�' % (self.name, okey))
        return self._result({'status':str(sxds.status)}, [])
        
    def zjq(self, status, expect):
        okey = '�ܽ���'
        if not int(zjq.status) and int(status) == 1:
            zjq.status = status
            th1 = threading.Thread(target = zjq.checkall, args = (60, expect))
            th1.start()
            logging.info('%s����%s�߳̿���' % (self.name, okey))
        else:
            if int(zjq.status) and int(status) == 0:
                zjq.status = status
                logging.info('%s����%s�̹߳ر�' % (self.name, okey))
        return self._result({'status':str(zjq.status)}, [])
        
    def dcbf(self, status, expect):
        okey = '�����ȷ�'
        if not int(dcbf.status) and int(status) == 1:
            dcbf.status = status
            th1 = threading.Thread(target = dcbf.checkall, args = (60, expect))
            th1.start()
            logging.info('%s����%s�߳̿���' % (self.name, okey))
        else:
            if int(dcbf.status) and int(status) == 0:
                dcbf.status = status
                logging.info('%s����%s�̹߳ر�' % (self.name, okey))
        return self._result({'status':str(dcbf.status)}, [])
        
    def bqc(self, status, expect):
        okey = '��ȫ��ʤƽ��'
        if not int(bqc.status) and int(status) == 1:
            bqc.status = status
            th1 = threading.Thread(target = bqc.checkall, args = (60, expect))
            th1.start()
            logging.info('%s����%s�߳̿���' % (self.name, okey))
        else:
            if int(bqc.status) and int(status) == 0:
                bqc.status = status
                logging.info('%s����%s�̹߳ر�' % (self.name, okey))
        return self._result({'status':str(bqc.status)}, [])
    
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''    
    p =Server()
    return Eas.Function.get_method_dict(p, prefix+'/')    
