#coding=gbk
import sys, os
reload(sys)
sys.setdefaultencoding('gbk')
#print sys.getdefaultencoding()

import time
#import json
import threading
import traceback
import signal

if not os.environ.has_key('_BASIC_PATH_'):
    _BASIC_PATH_ = os.path.abspath(__file__)
    _BASIC_PATH_ = _BASIC_PATH_[:_BASIC_PATH_.rfind('/test/')]
    os.environ['_BASIC_PATH_'] = _BASIC_PATH_
if sys.path.count(os.environ['_BASIC_PATH_'] + '/lib') == 0:
    sys.path.append(os.environ['_BASIC_PATH_'] + '/mod')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib/common')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs/pypi')


import re
import urllib
import urllib2
import datetime
import base64
import logging

import Db.Mysql
import XmlConfig
import functions
import JsonUtil

XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/config.xml')
XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/db.xml')

import bdsp

if __name__ == "__main__":
    
    _lot = "ab"
    _types = ["spf", "zjq", "sxds", "dcbf", "bqc"]
    #_types = ["bqc"]
    p = bdsp.Server()
    p.start(_lot, ",".join(_types), True)
    expect = '130512'
    #p.other(_lot, _types, expect, True)
    #print p.stat()
    #print p.stat()
