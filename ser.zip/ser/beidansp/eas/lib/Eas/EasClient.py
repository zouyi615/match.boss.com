#coding=gbk
import os
import sys
import traceback
import logging
import Ice
import XmlConfig

import socket
import fcntl
import struct

Ice.loadSlice(os.environ['_BASIC_PATH_']+'/etc/EAS.ice')
import ESUN

props = Ice.createProperties(sys.argv)
props.setProperty("Ice.MessageSizeMax", "20480")
id = Ice.InitializationData()
id.properties = props
ic = Ice.initialize(id)

_INSTANCE_ = {}

class EasClient:
    '''Eas �ͻ���'''
    def __init__(self, host, port, timeout):
        '''��ʼ������'''
        self._ip       = get_ip_address()
        self._proxy    = self._get_proxy(host, str(port), str(timeout))
    
    def _get_proxy(self, host, port, timeout):
        '''��ȡ������'''
        stringProxy = "ESunEAS:"
        
        conf1 = host.split(',')
        conf2 = port.split(',')
        conf3 = timeout.split(',')
        for i in range(len(conf1)):
            stringProxy += 'tcp -h '+conf1[i]+' -p '+conf2[i]+' -t '+conf3[i]+' : '
        
        stringProxy = stringProxy[:-2]
        return ESUN.EASPrx.checkedCast(ic.stringToProxy(stringProxy))
        
    
    @staticmethod
    def get_instance(serid):
        '''ͨ��XML���client����'''
        if not _INSTANCE_.has_key(serid):
            conf    = XmlConfig.get('/service/eas/'+serid)
            _INSTANCE_[serid] = EasClient(**conf)
        return _INSTANCE_[serid]
    
    @staticmethod
    def get_instance_conf(host, port, timeout=3000):
        '''ͨ�����û��client����'''
        serid = '%s_%s' % (host, port)
        if not _INSTANCE_.has_key(serid):
            _INSTANCE_[serid] = EasClient(host, port, timeout)
        return _INSTANCE_[serid]
    
    def invoke(self, id, param):
        '''���ô�����invoke����'''
        data ={'from':'python','resource':self._ip}
        ret = self._proxy.invoke(id, param, data)
        return ret
    

def get_ip_address(ifname = 'eth0'):
    '''��ȡ������ip'''
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915, # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])
