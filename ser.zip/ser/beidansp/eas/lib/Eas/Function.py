#coding=gbk
import hashlib
import inspect

def load_method(model, method):
    mod = __import__(model)
    components = model.split('.')
    for comp in components[1:]:
        mod = getattr(mod, comp)
    
    if not hasattr(mod, method):
        return None
    
    return getattr(mod, method)

def get_method_dict(obj, prefix='', filterPri=True):
    meths = {}
    for i in dir(obj):
        if filterPri and i[0]=='_':#����˽�з���
            continue
        
        m = getattr(obj, i)
        if not inspect.ismethod(m): 
            continue
        meths[prefix+i] = m #return meths
    return meths

def get_func_dict(localsfunc, prefix='', filterPri=True):
    funcs = {}
    if localsfunc.has_key('reg_interface'):
        localsfunc.pop('reg_interface')
    
    for i in localsfunc:
        if filterPri and i[0]=='_':#����˽�з���
            continue
        
        if not inspect.isfunction(localsfunc[i]): 
            continue
        funcs[prefix+i] = localsfunc[i] #return meths
    return funcs

def md5(data):
    m = hashlib.md5()
    m.update(data)
    return m.hexdigest()
