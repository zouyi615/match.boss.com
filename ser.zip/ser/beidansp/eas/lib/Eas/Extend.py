#coding=gbk
import logging
import traceback
import __main__

import JsonUtil

class Common:
    
    def _result(self, info={}, ilist=[]):
        '''��ʽ��������'''
        return {'CODE':1, 'MSG':'success!', 'info':info, 'list':ilist}
        
    
    def _iresult(self, info={}, datarows=[]):
        if type(info) != dict:
            info = {} 
        info['__type'] = 'json'
        info['__data'] = JsonUtil.write(datarows)
        return {'CODE':1, 'MSG':'success!', 'info':info}
        
    
    def _error(self, msg, issys = False, args={}):
        '''�����������'''
        if issys: #ϵͳ������Ҫ�澯
            __main__.alert(msg, 'some error args = (%s) : %s' % (args, msg)) 
        
        if args:
            logging.error('some error args = (%s) : %s', args, msg)
        else:
            logging.error('some error : %s', msg)
            
        msg = issys and 'ϵͳ��æ�����Ժ�����' or msg
        return {'CODE':-1, 'MSG':msg, 'info':{}, 'list':[]}
        
        
