#coding=gbk
"""MonitorService��Basicģ��
"""
import os
import time
import socket
import logging
import threading
import traceback

import MiniXml
import JsonUtil

############################################################


class Client:
    """��ط���Ŀͻ���
    """
    
    monitor_type = 'eas_basic'
    
    def __init__(self, app_id, svc_addr):
        """���캯��
        ������
            app_id: ����ص�Ӧ�õ�ID
            svc_addr: ��ط���˵ĵ�ַ
        """
        self.app_id = app_id
        self.svc_addr = svc_addr
        self._end_event = threading.Event()
        
    def _call(self, cmd_id, data):
        """��������
        ������
            cmd_id: ִ�е�����
            data: ��������ص�����
        û�з���
        """
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.sendto(JsonUtil.write({
                        'app_id': self.app_id,
                        'cmd_id': cmd_id,
                        'data': data,
                     }), self.svc_addr)
        finally:
            s.close()
        
    def _call2(self, cmd_id, data, timeout=2):
        """�������ݲ����ջظ�
        ������
            cmd_id: ִ�е�����
            data: ��������ص�����
            timeout: ��ʱ����
        ���ط���˵Ļظ�
        """
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(timeout)
        try:
            s.sendto(JsonUtil.write({
                        'app_id': self.app_id,
                        'cmd_id': cmd_id,
                        'data': data,
                     }), self.svc_addr)
            return JsonUtil.read(s.recv(60000)) # ����涨���ݰ����64K
        finally:
            s.close()

    def register(self, args):
        """register
            args:   ע�������dict��ʽ������mobiles��emails�����ṩһ����
                    mobiles���ֻ������list��emails���ʼ���ַ��list��
                    max_idle_time��������ʱ�䣬�������ʱ�䲻֪ͨ�ͻ�澯��
        """
        self._end_event.clear()
        data = {'max_idle_time': 120, 'monitor_type': self.monitor_type}
        data.update(args)
        try:
            ret = self._call2('register', data)
            if ret['code'] < 0:
                raise Exception(ret)
        except:
            logging.error('monitoring register failed: [%s] %s',
                            self.app_id, traceback.format_exc())
            raise
        logging.info('monitoring register: [%s] %s', self.app_id, ret)
        return ret
        
    def unregister(self):
        """unregister
        """
        self._end_event.set()
        try:
            ret = self._call2('unregister', None)
            if ret['code'] < 0:
                raise Exception(ret)
        except:
            logging.error('monitoring unregister failed: [%s] %s',
                            self.app_id, traceback.format_exc())
            return
        logging.info('monitoring unregister: [%s] %s', self.app_id, ret)
        return ret
        
    def alert(self, short_msg, long_msg, encoding='utf-8'):
        """���͸澯
        """
        self._call('alert', {
                      'short_msg': short_msg,
                      'long_msg': long_msg,
                      'encoding': encoding,
        })
        logging.info('send alert:%s, %s', short_msg, long_msg)
        
    def inform(self, data=None):
        """����֪ͨ
        """
        try:
            self._call('inform', data)
            logging.debug('monitor inform')
        except:
            pass
        
    def _loop_inform(self, data, interval):
        """�Զ�ѭ��֪ͨ
        """
        while True:
            self._end_event.wait(interval)
            if self._end_event.isSet():
                break
            try:
                self.inform(data)
            except:
                logging.error('monitoring inform failed: [%s] %s',
                                self.app_id, traceback.format_exc())
        
    def start_loop(self, data=None, interval=60):
        """�����Զ�ѭ��֪ͨ
        """
        self._end_event.clear()
        th = threading.Thread(target=self._loop_inform, args=(data, interval))
        th.setDaemon(True)
        th.start()
 
    def stop_loop(self):
        """�Զ�ѭ��ֹ֪ͨͣ
        """
        self._end_event.set()
    
    @staticmethod
    def get_stats(svc_addr, timeout=4):
        """��ȡ����app״̬��super���
        """
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(timeout)
        try:
            s.sendto(JsonUtil.write({
                        'cmd_id': Client.monitor_type + '_stats',
                        'data': None,
                     }), svc_addr)
            return JsonUtil.read(s.recv(60000)) # ����涨���ݰ����64K
        finally:
            s.close()

_MBC_ = None
_EAS_STATUS_KEY_ = 'eas_server/status_test'

def setup(appid, *args, **kwargs):
    '''alert��������ű�'''
    import Eas.Plugin
    
    def status_test(*args, **argv):
        _MBC_.inform()
        return {'CODE':1, 'MSG':'replay success!'}
    
    def _register(*args, **kwargs):
        main = args[0]
        this = args[1]
        app_id = main._APP_ID_
        mbc_mobiles = []
        mbc_emails = []
        this._methods[_EAS_STATUS_KEY_] = {}
        this._methods[_EAS_STATUS_KEY_]['function'] = status_test
        
        ins = MiniXml.parseFile(os.environ['_BASIC_PATH_'] + '/etc/eas.xml')
        conf = ins.get('/eas/applications/%s' % app_id)
        
        if conf.has_key('keepers'):
            for keeper in conf.get('keepers').split(','):
                keeper = ins.get('/eas/monitoring/keepers/' + keeper)
                if keeper['mobiles']:
                    mbc_mobiles.extend(keeper['mobiles'].split(','))
                if keeper['emails']:
                    mbc_emails.extend(keeper['emails'].split(','))
        
        mbc_addr = ins.get('/eas/monitoring/server')
        mbc_timing = conf.get('monitor_timing', '300,300,3').split(',', 1)
        mbc = Client('eas.' + app_id, (mbc_addr['host'], int(mbc_addr['port'])))
        
        import __main__
        __main__.alert = mbc.alert # �ѿյĸ澯������Ϊʹ�ü�ص�
        
        mbc.register({
            'mobiles': mbc_mobiles,
            'emails': mbc_emails,
            'max_idle_time': int(mbc_timing[0]),
            'alert_interval': mbc_timing[1],
            'eas_port': conf.get('listen', '').split(' ')[2],
        })
        
        global _MBC_
        _MBC_ = mbc
    
    def _unregister(*args, **kwargs):
        _MBC_.unregister()
    
    Eas.Plugin.add_action('ice_interface_init', _register)
    Eas.Plugin.add_action('run_stop', _unregister)
