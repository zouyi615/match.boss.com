# coding: gbk
import datetime
import time
import traceback
import random

import Db.Mysql
import XmlConfig

from BeautifulSoup import BeautifulSoup

from Core import Base

class Timer(Base.Base):
    
    def __init__(self, _lot, _type, _sec, debug=False, lastExpect=False):
        self.debug = debug
        super(Timer, self).__init__()
        self._lot = _lot
        self._type = _type
        self._sec = _sec
        self.lastExpect = lastExpect
        self._status = True
        self.n = 0
        
        self.t = time.time()
        
    def run(self, expect = ""):
        self.alert("%s %s is running with %s:%s" % (self._lot, self._type, self.lastExpect, self._sec))
        n = 0
        while self._sec == 0 or (self._status or self._type == "sf"):
            try:
                if self.lastExpect != False:
                    if self.lastExpect == True:
                        expect = self.setExpect()
                    else:
                        expect = self.lastExpect
                self.dataRun(expect)
            except Exception,e:
                self.alert(traceback.format_exc())
            if self._sec:
                n += 1
                time.sleep(self._sec)
            else:
                break
    
    def setExpect(self, t=0):
        _lastexp = ""
        try:
            if self._type == "sf":
                _cururl = "http://www.500.com/static/public/bjdcsf/xml/expect/activeexpectinfo.xml"
            else:
                _cururl = "http://www.500.com/static/public/bjdc/xml/expect/activeexpectinfo.xml"
                
            _res = self.fopen(_cururl)
            _soup = BeautifulSoup(_res) 
            if _soup:
                _curexp = _soup.find("row") and _soup.find("row")["expect"] or ""
                if _curexp:
                    if self._type == "sf":
                        _lasturl = "http://www.500.com/static/public/bjdcsf/xml/hcount/expect.xml"
                    else:
                        _lasturl = "http://www.500.com/static/public/bjdc/xml/hcount/expect.xml"
                    _res = self.fopen(_lasturl)
                    _soup = BeautifulSoup(_res)
                    if _soup and _soup.find("row", {"expect":_curexp}) and _soup.find("row", {"expect":_curexp}).nextSibling:
                        if _soup.find("row", {"expect":_curexp}):
                            _lastexp = _soup.find("row", {"expect":_curexp}).nextSibling["expect"]
        except:
            self.alert("ǰһ�ڵ��ں��޷���ȷȡ��")
            self.alert(traceback.format_exc())
        return t==0 and _lastexp or _curexp
    
    def gett(self, msg=""):
        return
        t = "%.2f" % (time.time() - self.t)
        self.alert("[dataRun][%s%s][%s%s](%s)" % (self._lot, self._type, self.lastExpect, msg, t))
        self.t = time.time()
    
    def dataRun(self, expect=""):
        if self.lastExpect == True and expect=="":
            self.alert("��ʷ�ں��޷���ȷ��ȡ����ʱ��������")
            return
        
        db = Db.Mysql.get("info_write")
        self.gett("start")
        
        _keys = {"spf":34, "zjq":40, "sxds":41, "dcbf":42, "bqc":51, "sf":407}

        _conf = XmlConfig.get("/config/define")
        _xmlconf = XmlConfig.get("/config/xml")
        _lotconf = XmlConfig.get("/config/%s/url" % self._lot)
        
        if self._type == "sf":
            table = "t_bjdcsf_%s_sp" % self._type
        else:
            table = "t_bjdc_%s_sp" % self._type
        
        if _keys.get(self._type) and _lotconf:
            _key = _keys[self._type]
            
            classname = "%sClass.%s" % (self._lot, self._type)
            mod = __import__(classname, globals(), locals(), [self._type])
            
            dList = []
            changeBifen = False
            
            if mod:
                nowData = []
                _res = ""
                dlnum = random.randint(1, 3)
                
                #��ʷ��                
                if expect:
                    zh_key = "%s_%s" % ('his', _key)
                    if _lotconf.get(zh_key):
                        _url = _lotconf[zh_key] % ((self._lot == "ab") and expect[1:] or expect)
                        if _conf.get("daili"):
                            _url = _conf['daili'] % (dlnum, _url)
                        
                        _res = self.wopen(_url)
                    elif _lotconf.get("beidan_his"):
                        _url = _lotconf["beidan_his"] % (len(expect)==5 and expect or expect[1:])
                        if _conf.get("daili"):
                            _url = _conf['daili'] % (dlnum, _url)
                        _res = self.fopen(_url)
                    
                    nowData = mod.getHisdata(_res)
                #��ǰ��
                else:
                    _data = ""
                    if _lotconf.get("expect"):

                        _url = _lotconf["expect"] % (int(time.time()*1000))
                        if _conf.get("daili"):
                            _url = _conf['daili'] % (dlnum, _url)
                        _data = self.fopen(_url)
                        if _data:
                            expect = mod.getExpect(_data)
                    
                    zh_key = "%s_%s" % ('beidan', _key)
                    
                    if _lotconf.get(zh_key):
                        _url = _lotconf[zh_key]
                        
                        if _conf.get("daili"):
                            _url = _conf['daili'] % (dlnum, _url)
                        _res = self.fopen(_url)
                        if _res:
                            if self._lot == 'aicai' and self._type == 'dcbf' and _data:
                                nowData = mod.getIndata(_res, _data)
                            else:
                                nowData = mod.getIndata(_res)
                            
                    if expect == "":
                        expect = mod.getExpect(_res)
                    
                if expect and nowData:
                    self.gett("geturl:%s" % _url)
                    #ȡ�ø�����������
                    sql = "select * from (select * from %s where expect='%s' order by id desc, matchid) as u group by matchid" % (table, expect)
                    oldd = {}
                    res = db.query(sql)
                    for r in res:
                        oldd[int(r["matchid"])] = r
                    
                    self.gett("getoldd:%s" % len(oldd.values()))
                    
                    i = 0
                    for d in nowData:
                        
                        #���˿ո�
                        for i in d:
                            d[i] = d[i].replace("&nbsp;", "")
                        
                        #�����ж��Ƿ�ȡ������
                        if self._type == "sf":
                            d["c1"] = d["c1"]!="" and ("%.2f" % float(d["c1"])) or ""
                            d["c3"] = d["c3"]!="" and ("%.2f" % float(d["c3"])) or ""
                        else:
                            goon = False
                            for i in xrange(len(d)*2):
                                if d.get("c%s" % i):
                                    d["c%s" % i] = float(d["c%s" % i]) and ("%.2f" % float(d["c%s" % i])) or ""
                                    goon = True
                                if i%2==1 and d.get("c%s" % i)==None:
                                    break
                            
                            if goon == False:
                                d["c1"] = "1.00"

                        d["ly"] = self._lot
                        d["expect"] = expect
                        if d.get("r") == None or d["r"]=="":
                            d["r"] = 0
                        
                        #����������ֻ��������ʤ��������������֮���
                        if self._type == "sf" and d.get("lx")!=None:
                            if d.get("result"):
                                res = mod.upresult(d)
                                if res:
                                    changeBifen = True
                                    self.alert("[%s][%s] update result:%s" % (d["expect"], d["matchid"], d["result"]))
                            
                            d.pop("lx")
                            d.pop("result")
                        
                        if mod.isInsert(oldd.get(int(d["matchid"])), d):
                            dList.append(d)
                                
                self.gett("getdList:%s" % len(dList))
            else:
                self.alert("%s is not found" % classname)
            
            if len(dList) > 0:
                #������������
                num = self.allInsert(db, table, dList)
                
                self.gett("insert:%s" % num)
                
                #�������淨����pl����
                if self._type == "sf":
                    for d in dList:
                        singleplsf = ""
                        if d["c1"] == "":
                            singleplsf = d["c3"]
                        elif d["c3"] == "":
                            singleplsf = d["c1"]
                        else:
                            continue
                        
                        #ֻ��һ��sp����½�����
                        if singleplsf:
                            res = mod.upsingleplsf(d["expect"], d["matchid"], singleplsf)
                            self.alert("[%s][%s] update singleplsf:%s" % (d["expect"], d["matchid"], singleplsf))

                    if singleplsf or changeBifen:
                        infourl = _lotconf["infoadmin"] % expect
                        res = self.fopen(infourl)
                        self.alert("[CURL]%s:%s" % (infourl, res))
                        
            if (len(dList) > 0) or (self.n % 10 == 0):
                #10���������Ƿ��иı���������һ��XML
                self.n = 0
                #ȡ��XML����
                xmlStr = mod.getXmlData(table, expect)
                if xmlStr:
                    xmlStr = xmlStr.replace("&nbsp;", "")
                    self.gett("setxml")
                    htmlStr = '<?xml version="1.0" encoding="gbk"?><w st="-1">%s</w>' % (xmlStr)
                    path = _conf['path'] % (expect, _key)
                    if self._type == "sf":
                        path = path.replace("bjdc", "bjdcsf")
                    res = self.upload(_conf['FileServerURL'], path, htmlStr)
                    self.alert("xml-html:%s with %d is %s" % (path, len(dList), str(res)))
            self.n += 1
            
        else:
            self.alert("_keys.get(%s), %s" % (_keys.get(self._type), _lotconf))
