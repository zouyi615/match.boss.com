#coding=gbk
import sys, os
reload(sys)
sys.setdefaultencoding('gbk')

import datetime
import threading
import time
import logging

from BeautifulSoup import BeautifulSoup

import XmlConfig
import Db.Mysql
import JsonUtil
import EasClient

from Core import Base

conf = XmlConfig.get("/config/match")

class prototype(Base.Base):
    '''
            ����
    '''
    def __init__(self):
        super(prototype, self).__init__()
        self.contents = ""
    
    def getExpect(self):
        db = Db.Mysql.connect("info_read")
        sql = "SELECT periodicalnum FROM t_bjdc_periodical ORDER BY periodicalid DESC limit 1"
        res = db.queryOne(sql)
        if res and res.get("periodicalnum"):
            self.expect = res["periodicalnum"]
    
    def getFixmatch(self, m):
        db = Db.Mysql.connect("SoccerSlave")
        sql = "CALL p_bjdc_getfixtureid(%s, %s, %s, null)"
        res = db.queryOne(sql, (m['hometeamname'], m['guestteamname'], m['matchtime']))
        return res
    
    def sendMail(self, subject, content):
        result = []
        if type(content)==unicode:
            content = content.encode("gbk")
        if type(subject)==unicode:
            subject = subject.encode("gbk")
        if content != self.contents:
            res = self.fopen(conf["noticeurl"])
            if res:
                jdata = JsonUtil.read(res)
                if jdata and jdata.get("person"):
                    eas_instance = EasClient.EasClient().getInstance('others')
                    for d in jdata.get("person"):
                        if d.get("status") == "1":
                            params={
                                'tag':'www.server.notice',
                                'email':d["email"],
                                'args':JsonUtil.write({'subject':subject, 'content':content}),
                            }
                            res = eas_instance.invoke('sendEmail',params)
                            result.append("%s:%s" % (d["email"], str(res[0])))
                            self.content = content

        self.alert("sendmail '%s' with %s" % (content, str(result)))

class getMatch(prototype):

    '''
         ץȡ�������̣����
    '''
    def __init__(self, debug=False):
        self.debug = debug
        super(getMatch, self).__init__()
        self.expect = ""
        self.matchs = []
    
    def setExpect(self):
        db = Db.Mysql.connect("info_write")
        sql = "SELECT * FROM t_bjdc_periodical WHERE periodicalnum=%s"
        res = db.queryOne(sql, [self.expect])
        if res == None:
            sql = "INSERT INTO t_bjdc_periodical (periodicalnum, resulttime) VALUES (%s, %s)"
            inres = db.insert(sql, [self.expect, datetime.datetime.now()])
            if inres>0:
                self.alert("insert into (%s,%s) with %d" % (self.expect, datetime.datetime.now(), inres))
    
    def getmatch(self):
        url = conf['matchurl']
        res = self.wopen(url)
        soup = BeautifulSoup(res)
        expect = soup.find("select", id="drpWareNo").find("option", {"selected":"selected"}).text
        
        if expect and expect[0]!="1":
            expect = "1" + expect
            
            trs = soup.find("table", id="rounds").findAll("tr", {"onmouseover":True})
            if len(trs)>0:
                self.matchs = []
                for tr in trs:
                    tds = tr.findAll("td")
                    
                    matchtime = ""
                    now = datetime.datetime.now() - datetime.timedelta(days=30)
                    for i in xrange(3):
                        tmptime = datetime.datetime.strptime(tds[2].text, '%m-%d %H:%M').replace(year=(now.year+i))
                        if tmptime > now:
                            matchtime = tmptime
                            break
                    
                    self.matchs.append({
                        "periodicalnum" : str(expect),
                        "ordernum" : str(tds[0].text),
                        "leaguematchname" : tds[1].text,
                        "hometeamname" : tds[3].text,
                        "guestteamname" : tds[5].text,
                        "matchtime" : str(matchtime),
                        "fixtureid" : "-1",
                        "rangqiu" : tds[4].text,
                        "isright" : "1"
                    })
                self.expect = expect
                self.setExpect()
                return True
        return False
    
    def checkMatch(self, m):
        db = Db.Mysql.connect("info_read")
        sql = "SELECT * FROM t_bjdc_matchfixture WHERE periodicalnum=%s AND ordernum=%s"
        return db.queryOne(sql, [m["periodicalnum"], m["ordernum"]])
        
    def insertMatch(self, m):
        db = Db.Mysql.connect("info_write")
        sql = "INSERT INTO t_bjdc_matchfixture (%s) VALUES (%s)" % (",".join(m.keys()), ",".join(["%s" for i in xrange(len(m.keys()))]))
        inres = db.insert(sql, m.values())
        if inres>0:
            self.alert("insert into %s with %d" % (str(m), inres))

    def run(self):
        lastExpect = ""
        while True:
            if self.getmatch():
                if self.expect and self.expect != lastExpect:
                    lastExpect = self.expect
                    ordernums = []
                    islist = []
                    for m in self.matchs:
                        if self.checkMatch(m) == None:
                            odds = self.getFixmatch(m)
                            if type(odds)==dict and len(odds)>0:
                                m["fixtureid"] = odds["fixtureid"]
                                m["isright"] = odds["isright"]
                                
                                if int(m["isright"]) == -1:
                                    islist.append(m["ordernum"])
                            else:
                                ordernums.append(m["ordernum"])
                            self.insertMatch(m)
                    
                    if ordernums or islist:
                        subject = "��Ѷ����˶Է���[����]%s��" % self.expect
                        content = "��Ѷ����˶Է���[����]��%s��" % (self.expect)
                        if len(ordernums) > 0:
                            content += "����%s������ID��-1���˹�������¿�����ֶ�ƥ��" % len(ordernums)
                        
                        if len(islist) > 0:
                            content += "����%s����������˳��һ��" % len(islist)
                        self.sendMail(subject, content)
            if self.debug:
                break
            time.sleep(60)

class ckMatch(prototype):

    '''
         ��֤���¿��Ƿ�ƥ��
    '''
    def __init__(self, debug=False):
        self.debug = debug
        super(ckMatch, self).__init__()
            
    def ckList(self):
        db = Db.Mysql.connect("info_read")
        sql = "SELECT * FROM t_bjdc_matchfixture WHERE periodicalnum=%s"
        return db.query(sql, [self.expect])
    
    def udfix(self, m):
        db = Db.Mysql.connect("info_write")
        sql = "UPDATE t_bjdc_matchfixture SET fixtureid=%s, isright=%s WHERE matchfixtureid=%d" % (m["fixtureid"], m["isright"], m["matchfixtureid"])
        udres = db.execute(sql)
        if udres>0:
            self.alert("update %s with %d" % (str(m), udres))
            
    def ksMatch(self):
        db = Db.Mysql.connect("info_read")
        sql = "SELECT * FROM t_bjdc_periodical WHERE periodicalnum=%s AND isactive=0"
        res = db.queryOne(sql, [self.expect])
        if res:
            result = {
                "actres" : "0",
                "manactres" : "0",
                "jtzsres" : "failed"        
            }
            result["actres"] = self.fopen(conf["activeurl"] % (self.expect, res["periodicalid"]))
            if result["actres"] == "1":
                result["manactres"] = self.fopen(conf["manacturl"] % self.expect)
                result["jtzsres"] = self.fopen(conf["jtzsurl"])
            
            subject = "��Ѷ����˶Է���[����][�˶�]��%s��" % self.expect
            content = "��Ѷ����˶Է���[����]��%s�ڱ����˶Գɹ�,����״̬��%s" % (self.expect, str(result))
            self.sendMail(subject, content)
            self.alert("ksMatch %s with %s," % (self.expect, str(result)))
    
    def run(self):
        lastExpect = ""
        while True:
            self.getExpect()            
            if self.expect and self.expect != lastExpect:
                cklist = self.ckList()
                if cklist:
                    cstat = True
                    islist = []
                    for m in cklist:
                        if int(m["fixtureid"]) == -1:
                            odds = self.getFixmatch(m)
                            if type(odds)==dict and len(odds)>0:
                                m["fixtureid"] = odds["fixtureid"]
                                m["isright"] = odds["isright"]
                                
                                if int(m["isright"]) == -1:
                                    islist.append(m["ordernum"])
                                
                                self.udfix(m)
                            cstat = False
                            
                    if cstat:
                        self.ksMatch()
                        lastExpect = self.expect
                    
                    if islist:
                        subject = "��Ѷ����˶Է���[����][����˳��]��%s��" % self.expect
                        content = "��Ѷ����˶Է���[����]��%s����%s����������˳��һ��" % (self.expect, len(islist))
                        self.sendMail(subject, content)
                    
            if self.debug:
                break
            time.sleep(60)
            
class cpMatch(prototype):

    '''
         ��֤��Ʊ���Ƿ�ƥ��
    '''
    def __init__(self, debug=False):
        self.debug = debug
        super(cpMatch, self).__init__()
    
    def getcps(self):
        txtmatch = self.fopen(conf["txtmatch"] % self.expect)
        if txtmatch:
            jm = JsonUtil.read(txtmatch)
            return jm
            
    def getcks(self):
        db = Db.Mysql.connect("info_read")
        sql = "SELECT * FROM t_bjdc_matchfixture WHERE periodicalnum=%s"
        rows = db.query(sql, [self.expect])
        matchs = {}
        if rows:
            for r in rows:
                matchs[str(r["ordernum"])] = r
        return matchs
            
    def run(self):
        lastExpect = ""
        while True:
            self.getExpect()
            if self.expect and self.expect != lastExpect:
                cplist = self.getcps()
                ckok = []
                ckbad = []
                if cplist:
                    cklist = self.getcks()
                    for i in cplist:
                        stat = True
                        if cklist.get(i):
                            for k in cplist[i]:
                                if str(cplist[i][k]) != str(cklist[i].get(k)):
                                    stat = False
                                    break
                        else:
                            stat = False
                        
                        if stat:
                            ckok.append(i)
                        else:
                            ckbad.append(i)

                    cklist_key = sorted(cklist.keys(), key=lambda x:int(x))
                    for i in cklist_key:
                        if cplist.get(i) == None:
                            ckbad.append(i)
                
                    subject = "��Ʊ���˶�[����]��%s��" % (self.expect)
                    content = "��Ʊ���˶�[����]��%s��%s�������˶Գɹ���%s�������˶�ʧ��" % (self.expect, str(ckok), str(ckbad))
                    self.sendMail(subject, content)
                    lastExpect = self.expect
            
            if self.debug:
                break
            time.sleep(60)

def main(debug=False):
    
    ths = {}
    for c in ['getMatch', 'ckMatch']:
        ths[c] = globals()[c](debug)
        
    for c in ths:
        ths[c].start()
        
if __name__ == "__main__":
    main(True)