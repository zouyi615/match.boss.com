#encoding=gbk
import re

from BeautifulSoup import BeautifulSoup
import Db.Mysql

maxNum = 17

def getExpect(html):
    soup = BeautifulSoup(html)
    expect = ""
    if soup.find('div', {"class":"horstyNo"}):
        rexp = re.search(r"\d+", soup.find('div', {"class":"horstyNo"}).find("i").text)
        if rexp:
            expect = rexp.group()
        if expect[0] != '1':
            expect = "1%s" % expect
    return expect
    
def getIndata(html):   
    soup = BeautifulSoup(html)
    if soup:
        trs = soup.findAll("tr", id=re.compile(r'tr_\d+'))
        if trs:
            for tr in trs:
                tds = tr.findAll("td")
                if len(tds)>7:
                    temp = {}
                    temp["matchid"] = tds[0].text
                    temp["gn"] = tds[1].text
                    temp["h"] = re.sub("\[\d+\]", "", tds[4].text)
                    temp["a"] = re.sub("\[\d+\]", "", tds[5].text)
                    
                    for i in xrange(len(tds[6].findAll("em"))):
                        sk = "c%s" % (i*2+1)
                        temp[sk] = tds[6].findAll("em")[i].text
                    
                    for k in temp:
                        if temp[k] in ["--", "1.00"]:
                            temp[k] = ""
                    yield temp
                
def getHisdata(html): 
    soup = BeautifulSoup(html)
    if soup:
        trs = soup.findAll("tr", id=re.compile(r'tr_\d+'))
        if trs:
            for tr in trs:
                tds = tr.findAll("td")
                if len(tds)>7:
                    temp = {}
                    temp["matchid"] = tds[0].text
                    temp["gn"] = tds[1].text
                    temp["h"] = re.sub("\[\d+\]", "", tds[3].text)
                    temp["a"] = re.sub("\[\d+\]", "", tds[4].text)
                    
                    for i in xrange(8):
                        sk = "c%s" % (i*2+1)
                        temp[sk] = tds[5+i].text
                    
                    for k in temp:
                        if temp[k] in ["--", "1.00"]:
                            temp[k] = ""
                    yield temp
                
def isInsert(res, d):
    result = False
    if d.get("expect") and d.get("matchid"):
        if res:
            for i in xrange(1,maxNum,2):
                sk = "c%s" % i
                fl = lambda x:re.match(r'^\d+\.?\d*$', str(x)) and "%.2f" % float(x) or ""
                if fl(res[sk]) != fl(d[sk]):
                    result = True 
        else:
            result = True    
    return result
   
def getXmlData(table, expect):
    n2 = lambda x:re.match(r'^\d+\.?\d*$', str(x)) and "%.2f" % float(x) or ""
    db = Db.Mysql.get("info_read")
    sql = "select * from (select * from %s where expect='%s' order by id desc, matchid) as u group by matchid" % (table, expect)
    rows = db.query(sql)
    rowStr = ''
    
    for r in rows:
        lStr = ''
        for i in xrange(1,maxNum):
            lStr += ' c%d="%s"' % (i, n2(r.get("c%d" % i)))
        rowStr += '<w%d%s h="%s" a="%s" r="%s" gt="" gn="%s" st=""/>' % (r["matchid"], lStr, r["h"], r["a"], r["r"], r["gn"])
    if rowStr:
        return rowStr
    
    