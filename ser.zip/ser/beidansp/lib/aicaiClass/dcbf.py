#encoding=gbk
import re

from BeautifulSoup import BeautifulSoup
import Db.Mysql
import JsonUtil

maxNum = 26

def getExpect(html):
    expect = ''
    preg = re.search(r'term:\'(\d+)\'', html)
    if preg:
        expect = preg.group(1)
    return expect

def getIndata(html, _data):
    
    preg = re.search(r'qcbfSp:(\{[^\}]+\})', _data.replace("0.00", ""))
    
    dcsp = {}
    if preg:
        res = preg.group(1)
        dcsp = JsonUtil.read(res)
    
    soup = BeautifulSoup(html)
    if soup:
        ids = soup.findAll("input", id=re.compile(r"jq_qcbffushi_selectmatch_\d+"))
        if ids:
            for id in ids:
                tr = id.findParent("tr")
                tds = tr.findAll("td")
                
                if len(tds)>4:
                    temp = {}
                    temp["matchid"] = tds[0].text
                    temp["gn"] = tds[1].text
                    temp["h"] = tds[3].text
                    temp["a"] = tds[4].text
                    temp["r"] = ""
    
                    skey = "m%s-" % temp["matchid"]
                    
                    preg = re.compile(r"^\d+\.\d*$")
                    
                    sfyq = True
                    for i in range(1, maxNum):
                        nk = "%s%s" % (skey, i)
                        temp["c%d" % i] = preg.match(dcsp.get(nk)) and dcsp[nk] or ""
                        if temp["c%d" % i] != "1.00":
                            sfyq = False
                            
                    if sfyq:
                        for i in range(1, maxNum):
                            temp["c%d" % i] = ""
                    
                    for k in temp:
                        if temp[k] == "-":
                            temp[k] = ""
                        
                    yield temp
    
def getHisdata(html):
    soup = BeautifulSoup(html)
    if soup and soup.find("tbody"):
        trs = soup.find("tbody").findAll("tr")
        if trs:
            for tr in trs:
                tds = tr.findAll("td")
                if len(tds) == 9:
                    
                    sg = tds[6].text
                    sp = tds[7].find("input")["value"]
                        
                    nlist = ['ʤ����','1:0','2:0','2:1','3:0','3:1','3:2','4:0','4:1','4:2','ƽ����','0:0','1:1','2:2','3:3','������','0:1','0:2','1:2','0:3','1:3','2:3','0:4','1:4','2:4']
                        
                    if tds[5].text == "*":
                        sg = nlist[0]
                        sp = "1.00"
                        
                    if sg:
                        temp = {}
                        temp["matchid"] = tds[0].text
                        temp["gn"] = tds[1].text
                        temp["h"] = tds[2].text
                        temp["a"] = tds[3].text
                        temp["r"] = ""
                        
                        for i in xrange(1,maxNum):
                            sk = "c%s" % i
                            temp[sk] = ""
                        
                        if sg in nlist:
                            nk = nlist.index(sg)
                            
                            if type(nk)==int:
                                tk = "c%d" % (nk+1)
                                if temp.get(tk)!=None:
                                    temp[tk] = sp
                                    cin = True
                                
                            for k in temp:
                                if temp[k] == "-":
                                    temp[k] = ""
                                    
                            yield temp
                
def isInsert(res, d):
    result = False
    if d.get("expect") and d.get("matchid"):
        if res:
            for i in xrange(1,maxNum):
                sk = "c%s" % i
                fl = lambda x:re.match(r'^\d+\.?\d*$', str(x)) and "%.2f" % float(x) or ""
                if fl(res[sk]) != fl(d[sk]):
                    result = True 
        else:
            result = True
    return result
   
def getXmlData(table, expect):
    n2 = lambda x:re.match(r'^\d+\.?\d*$', str(x)) and "%.2f" % float(x) or ""
    db = Db.Mysql.get("info_read")
    sql = "select * from (select * from %s where expect='%s' order by id desc, matchid) as u group by matchid" % (table, expect)
    rows = db.query(sql)
    rowStr = ''
    
    for r in rows:
        lStr = ''
        for i in xrange(1,maxNum):
            lStr += ' c%d="%s"' % (i, n2(r.get("c%d" % i)))
        rowStr += '<w%d%s h="%s" a="%s" r="%s" gt="" gn="%s" st=""/>' % (r["matchid"], lStr, r["h"], r["a"], r["r"] and r["r"] or "", r["gn"])
    if rowStr:
        return rowStr
    
    