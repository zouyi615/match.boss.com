#encoding=gbk
import re

from BeautifulSoup import BeautifulSoup
import Db.Mysql

maxNum = 7

def getExpect(html):
    expect = ''
    preg = re.search(r'term:\'(\d+)\'', html)
    if preg:
        expect = preg.group(1)
    return expect
    
def getIndata(html):
    soup = BeautifulSoup(html)
    if soup:
        trs = soup.findAll("tr", id=re.compile(r'jq_spffushi_match_\d+_tr'))
        if trs:
            for tr in trs:
                tds = tr.findAll("td")
                
                if len(tds)>11:
                    temp = {}
                    temp["matchid"] = tds[0].text
                    temp["gn"] = tds[1].text
                    temp["h"] = tds[3].text
                    temp["r"] = tds[4].text
                    temp["a"] = tds[5].text
                    temp["c1"] = tds[9].text
                    temp["c3"] = tds[10].text
                    temp["c5"] = tds[11].text
                    
                    for k in temp:
                        if temp[k] == "-":
                            temp[k] = ""
                    yield temp
    
def getHisdata(html):
    soup = BeautifulSoup(html)
    if soup and soup.find("tbody"):
        trs = soup.find("tbody").findAll("tr")
        if trs:
            for tr in trs:
                tds = tr.findAll("td")
                if len(tds) == 10:
                    
                    sg = tds[7].text
                    sp = tds[8].find("input")["value"]
                    
                    nlist = ['ʤ','ƽ','��']
                    if tds[6].text == "*":
                        sg = nlist[0]
                        sp = "1.00"

                    if sg:
                        temp = {}
                        temp["matchid"] = tds[0].text
                        temp["gn"] = tds[1].text
                        temp["h"] = tds[2].text
                        temp["r"] = tds[3].text
                        temp["a"] = tds[4].text
                        
                        for i in xrange(1,maxNum,2):
                            sk = "c%s" % i
                            temp[sk] = ""
                        
                        if sg in nlist:
                            nk = nlist.index(sg)
                            
                            if type(nk)==int:
                                tk = "c%d" % (nk*2+1)
                                if temp.get(tk)!=None:
                                    temp[tk] = sp
                                    cin = True
                                
                            for k in temp:
                                if temp[k] == "-":
                                    temp[k] = ""
                                    
                            yield temp
                        
                
def isInsert(res, d):
    result = False
    if d.get("expect") and d.get("matchid"):
        if res:
            for i in xrange(1,maxNum,2):
                sk = "c%s" % i
                fl = lambda x:re.match(r'^\d+\.?\d*$', str(x)) and "%.2f" % float(x) or ""
                if fl(res[sk]) != fl(d[sk]):
                    result = True 
        else:
            result = True    
    return result
   
def getXmlData(table, expect):
    n2 = lambda x:re.match(r'^\d+\.?\d*$', str(x)) and "%.2f" % float(x) or ""
    db = Db.Mysql.get("info_read")
    sql = "select * from (select * from %s where expect='%s' order by id desc, matchid) as u group by matchid" % (table, expect)
    rows = db.query(sql)
    rowStr = ''
    
    for r in rows:
        lStr = ''
        for i in xrange(1,maxNum):
            lStr += ' c%d="%s"' % (i, n2(r.get("c%d" % i)))
        rowStr += '<w%d%s h="%s" a="%s" r="%s" gt="" gn="%s" st=""/>' % (r["matchid"], lStr, r["h"], r["a"], r["r"], r["gn"])
    if rowStr:
        return rowStr
    
    