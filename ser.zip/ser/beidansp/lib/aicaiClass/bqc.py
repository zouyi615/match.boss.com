#encoding=gbk
import re

from BeautifulSoup import BeautifulSoup
import Db.Mysql

maxNum = 19

def getExpect(html):
    expect = ''
    preg = re.search(r'term:\'(\d+)\'', html)
    if preg:
        expect = preg.group(1)
    return expect
    
def getIndata(html):
    soup = BeautifulSoup(html)
    if soup:
        ids = soup.findAll("input", id=re.compile(r"jq_bqcfushi_selectmatch_\d+"))
        #trs = soup.findAll("tr", {"class":"jq_move_tr gs"})
        if ids:
            for id in ids:
                tr = id.findParent("tr")
                tds = tr.findAll("td")

                if len(tds)>15:

                    temp = {}
                    temp["matchid"] = tds[0].text
                    temp["gn"] = tds[1].text
                    temp["h"] = tds[3].text
                    temp["a"] = tds[4].text
                    temp["r"] = ""
                    
                    temp["c1"] = tds[7].text
                    temp["c3"] = tds[8].text
                    temp["c5"] = tds[9].text
                    temp["c7"] = tds[10].text
                    temp["c9"] = tds[11].text
                    temp["c11"] = tds[12].text
                    temp["c13"] = tds[13].text
                    temp["c15"] = tds[14].text
                    temp["c17"] = tds[15].text
                    
                    for k in temp:
                        if temp[k] == "-":
                            temp[k] = ""

                    yield temp
    
def getHisdata(html):
    soup = BeautifulSoup(html)
    if soup and soup.find("tbody"):
        trs = soup.find("tbody").findAll("tr")
        if trs:
            for tr in trs:
                tds = tr.findAll("td")
                
                if len(tds) == 9:
                    
                    sg = tds[6].text
                    sp = tds[7].find("input")["value"]
                                                
                    nlist = ['ʤ-ʤ','ʤ-ƽ','ʤ-��','ƽ-ʤ','ƽ-ƽ','ƽ-��','��-ʤ','��-ƽ','��-��']

                    if tds[5].text == "*":
                        sg = nlist[0]
                        sp = "1.00"
                        
                    if sg:
                        temp = {}
                        temp["matchid"] = tds[0].text
                        temp["gn"] = tds[1].text
                        temp["h"] = tds[2].text
                        temp["a"] = tds[3].text
                        temp["r"] = ""
                        
                        for i in xrange(1,maxNum,2):
                            sk = "c%s" % i
                            temp[sk] = ""
                        
                        if sg in nlist:
                            nk = nlist.index(sg)
                            
                            if type(nk)==int:
                                tk = "c%d" % (nk*2+1)
                                if temp.get(tk)!=None:
                                    temp[tk] = sp
                                    cin = True
                                
                            for k in temp:
                                if temp[k] == "-":
                                    temp[k] = ""
                                    
                            yield temp
                        
                
def isInsert(res, d):
    result = False
    if d.get("expect") and d.get("matchid"):
        if res:
            for i in xrange(1,maxNum,2):
                sk = "c%s" % i
                fl = lambda x:re.match(r'^\d+\.?\d*$', str(x)) and "%.2f" % float(x) or ""
                if fl(res[sk]) != fl(d[sk]):
                    result = True 
        else:
            result = True
    return result
   
def getXmlData(table, expect):
    n2 = lambda x:re.match(r'^\d+\.?\d*$', str(x)) and "%.2f" % float(x) or ""
    db = Db.Mysql.get("info_read")
    sql = "select * from (select * from %s where expect='%s' order by id desc, matchid) as u group by matchid" % (table, expect)
    rows = db.query(sql)
    rowStr = ''
    
    for r in rows:
        lStr = ''
        for i in xrange(1,maxNum):
            lStr += ' c%d="%s"' % (i, n2(r.get("c%d" % i)))
        rowStr += '<w%d%s h="%s" a="%s" r="%s" gt="" gn="%s" st=""/>' % (r["matchid"], lStr, r["h"], r["a"], r["r"] and r["r"] or "", r["gn"])
    if rowStr:
        return rowStr
    
    