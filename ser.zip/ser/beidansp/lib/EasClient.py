#coding=gbk
import os
import sys
import traceback
import logging
import Ice
import XmlConfig

import socket
import fcntl
import struct

Ice.loadSlice(os.environ['_BASIC_PATH_']+'/etc/EAS.ice')
import ESUN
props = Ice.createProperties(sys.argv)
props.setProperty("Ice.MessageSizeMax", "20480")
id = Ice.InitializationData()
id.properties = props
ic = Ice.initialize(id)

instance ={}
class EasClient:

    def __init__(self, host='', port='', timeout=''):
        self.host     = host
        self.port     = str(port)
        self.timeout  = str(timeout)
        self.proxy    = False
        self.getProxy()
    
    def getProxy(self):
        if self.proxy != False:
            return True
        stringProxy = "ESunEAS:"
        
        if not self.host:
            return False
        
        conf1 = self.host.split(",")
        conf2 = self.port.split(",")
        conf3 = self.timeout.split(",")
        for i in range(len(conf1)):
            stringProxy +="tcp -h "+conf1[i]+' -p '+conf2[i]+' -t '+conf3[i]+' : '
        
        stringProxy = stringProxy[:-2]
        try:
            twoway = ESUN.EASPrx.checkedCast(ic.stringToProxy(stringProxy))
            if not twoway:
                return False
        except:
            return False
        self.proxy = twoway
        return True   
    
    def getInstance(self,serid):
        if not instance.has_key(serid):
            conf    = XmlConfig.get('/service/eas/'+serid)
            
            host      = conf["host"]
            port    = conf["port"]
            timeout = conf["timeout"]
            Client = EasClient(host, port, timeout)
            instance[serid] = Client
        return instance[serid]
    
    
    def invoke(self, id, param):
        try:
            data ={'from':'python','resource':get_ip_address()}
            ret = self.proxy.invoke(id, param, data)
            return ret
        except Ice.Exception, ex:
            return False


def get_ip_address(ifname = 'eth0'):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915, # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])
