#encoding=gbk
import re
import traceback
import logging

from BeautifulSoup import BeautifulSoup
import Db.Mysql

maxNum = 5

def getExpect(html):
    soup = BeautifulSoup(html)
    expect = ""
    if soup.find('div', {"class":"horstyNo"}):
        rexp = re.search(r"\d+", soup.find('div', {"class":"horstyNo"}).find("i").text)
        if rexp:
            expect = rexp.group()

    return expect
    
def getIndata(html):   
    soup = BeautifulSoup(html)
    if soup:
        trs = soup.findAll("tr", id=re.compile(r'tr_\d+'))
        if trs:
            for tr in trs:
                
                tds = tr.findAll("td")
                                
                if len(tds)>7:
                    temp = {}
                    
                    try:
                        temp["c1"] = tds[5].find("em").text.replace("--", "")
                        temp["c3"] = tds[7].find("em").text.replace("--", "")
                                
                        temp["matchid"] = tds[0].text
                        temp["gn"] = tds[2].text
                        temp["h"] = tds[5].find("b").text
                        temp["r"] = tds[6].find("b").text
                        temp["a"] = tds[7].find("b").text
                        
                        if tds[1].text not in ["����", "����"]:
                            temp["lx"] = tds[1].text
                            temp["result"] = tds[10].find("b") and tds[10].find("b").text or ""
                    except:
                        temp["c1"] = tds[4].find("em").text.replace("--", "")
                        temp["c3"] = tds[6].find("em").text.replace("--", "")
                                
                        temp["matchid"] = tds[0].text
                        temp["gn"] = tds[2].text
                        temp["h"] = tds[4].find("b").text
                        temp["r"] = tds[5].text
                        temp["a"] = tds[6].find("b").text
                        
                        if tds[1].text not in ["����", "����"]:
                            temp["lx"] = tds[1].text
                            temp["result"] = tds[7].find("b") and tds[7].find("b").text or ""
                    
                    if temp["c1"]!="" or temp["c3"]!="":
                        yield temp
                
def getHisdata(html):
    soup = BeautifulSoup(html)
    if soup:
        trs = soup.findAll("tr", id=re.compile(r'tr_\d+'))
        if trs:
            for tr in trs:
                
                tds = tr.findAll("td")
                                
                if len(tds)>7:
                    temp = {}
                    
                    temp["c1"] = tds[4].find("em").text.replace("--", "")
                    temp["c3"] = tds[6].find("em").text.replace("--", "")
                            
                    temp["matchid"] = tds[0].text
                    temp["gn"] = tds[2].text
                    temp["h"] = tds[4].find("b").text
                    temp["r"] = tds[5].text
                    temp["a"] = tds[6].find("b").text
                    
                    if tds[1].text not in ["����", "����"]:
                        temp["lx"] = tds[1].text
                        temp["result"] = tds[7].find("b") and tds[7].find("b").text or ""
                    
                    if temp["c1"]!="" or temp["c3"]!="":
                        yield temp
                
def isInsert(res, d):
    result = False
    if d.get("expect") and d.get("matchid"):
        if res:
            for i in xrange(1,maxNum,2):
                sk = "c%s" % i
                fl = lambda x:re.match(r'^\d+\.?\d*$', str(x)) and "%.2f" % float(x) or ""
                if fl(res[sk]) != fl(d[sk]):
                    result = True
        else:
            result = True
    return result

def upresult(data):
    try:
        db = Db.Mysql.get("info_write")
        expect, matchid = data["expect"], data["matchid"]
        sql = "select homescore, guestscore from t_bjdcsf_matchfixture where singleplsf='' AND periodicalnum=%s AND ordernum=%s" % (expect, matchid)
        res = db.queryOne(sql)
        if res:
            if data["result"] == "��":
                sql = "UPDATE t_bjdcsf_matchfixture SET homescore=-1, guestscore=-1, resultsf='',isdelay=1 WHERE periodicalnum=%s AND ordernum=%s" % (expect, matchid)
                return db.execute(sql)
            elif ":" in data["result"]:
                homescore, guestscore = data["result"].split(":")
                result = int(homescore) + float(data["r"]) > int(guestscore) and "ʤ" or "��"
                sql = "UPDATE t_bjdcsf_matchfixture SET homescore=%s, guestscore=%s, resultsf='%s', isdelay=3 WHERE periodicalnum=%s AND ordernum=%s" % (homescore, guestscore, result, expect, matchid)
                return db.execute(sql)
    except Exception,e:
        logging.info(traceback.format_exc())

def upsingleplsf(expect, matchid, upsingleplsf):
    db = Db.Mysql.get("info_write")
    sql = "UPDATE t_bjdcsf_matchfixture SET singleplsf=%s WHERE periodicalnum=%s AND ordernum=%s" % (upsingleplsf, expect, matchid)
    return db.execute(sql)
   
def getXmlData(table, expect):
    n2 = lambda x:re.match(r'^\d+\.?\d*$', str(x)) and "%.2f" % float(x) or ""
    db = Db.Mysql.get("info_read")
    sql = "select * from (select * from %s where expect='%s' order by id desc, matchid) as u group by matchid" % (table, expect)
    rows = db.query(sql)
    rowStr = ''
    
    for r in rows:
        lStr = ''
        
        goon = False
        for i in xrange(1,maxNum):
            if r.get("c%s" % i):
                if float(r["c%s" % i]) in [0, 1]:
                    r["c%s" % i] = ""
                else:
                    goon = True
            
        if goon == False:
            r["c1"] = "1.00"

        for i in xrange(1,maxNum):
            lStr += ' c%d="%s"' % (i, n2(r.get("c%d" % i)))
        rowStr += '<w%d%s h="%s" a="%s" r="%s" gt="" gn="%s" st=""/>' % (r["matchid"], lStr, r["h"], r["a"], r["r"], r["gn"])
    if rowStr:
        return rowStr
    
    