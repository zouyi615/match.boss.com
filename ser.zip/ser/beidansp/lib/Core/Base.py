#coding=gbk
import logging
import os
import urllib,urllib2
import traceback
import datetime
import time
import threading

_MOD_LIBS_ = {}

class Base(threading.Thread):
    """docstring for Base"""
    def __init__(self):
        super(Base, self).__init__()

    def createInstance(self, class_name, *args, **kwargs):
        '''
        [Example]
        class_name = 'knightmade.logging.Logger'
        logger = Activator.createInstance(class_name, 'logname')
        '''
        if not _MOD_LIBS_.has_key(id):
            (module_name, class_name) = class_name.rsplit('.', 1)
            resultmodule = __import__(module_name, globals(), locals(), [class_name])
            resultclass = getattr(resultmodule, class_name)
            _MOD_LIBS_[class_name] = resultclass(*args, **kwargs)
        return _MOD_LIBS_[class_name]

    def wopen(self, path,post={}):
        host = path.split("/")[2]
        heads = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Charset':'GB2312,utf-8;q=0.7,*;q=0.7',
        'Accept-Language':'zh-cn,zh;q=0.5',
        'Cache-Control':'max-age=0',
        'Connection':'keep-alive',
        'Host':host,
        'Keep-Alive':'115',
        'Referer':path,
        'User-Agent':'Mozilla/5.0 (X11; U; Linux x86_64; zh-CN; rv:1.9.2.14) Gecko/20110221 Ubuntu/10.10 (maverick) Firefox/3.6.14'}
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor())
        urllib2.install_opener(opener)
        data = urllib.urlencode(post)
        req = urllib2.Request(path,data,headers=heads)

        for i in range(5):
            try:
                content = opener.open(req, timeout=30).read()
                break
            except Exception,e:
                content = ""
                time.sleep(1)
                self.alert("%s %s" % (path, e))
                self.alert(traceback.format_exc())
        return content.strip()

    def fopen(self, path,post={}):
        try:
            if post:
                data = urllib.urlencode(post)
                headers = {}
                res  = urllib2.Request(path,data,headers)
            else:
                res = path
            resp = urllib2.urlopen(res,timeout=15)
            content = resp.read()
            resp.close()
        except Exception,e:
            content = ""
            self.alert("%s %s" % (path, e))
        return content.strip()

    def upload(self, url, path, body):  
        values = {'url'   :   path, 'content'   :   body}
        res = self.fopen(url, values)
        #self.alert("%s is %s" % (path, res))
        return res

    def UpLoadMonitor(self, pu, level, job, content, jgtime, phone):
            values = {'LEVEL':level, 'TIME':datetime.datetime.now(),'TYPE':'infolocalserver', 'JOB':job, 'SERVICE':'CheckData', 'CONTENT':content.encode("gb2312"), 'NEXTTIME':jgtime, 'PHONELIST':phone}
            str = urllib.urlencode(values)
            url = "%s?%s" % (pu, str)
            #boss must be zhushi
            if self.debug:
                return '<?xml version="1.0" encoding="utf-8" ?><result>OK</result>'
            else:
                self.res = self.fopen(url)
                return res

    def insert(self, db, table, data = {}):
        if data:
            keylist = data.keys()
            vallist = data.values()
            sql = "INSERT INTO %s (%s) VALUES (%s)" % (table, ",".join(keylist), ",".join(['%s']*len(keylist)))
            ret = db.execute(sql, vallist)
            return ret
    
    def allInsert(self, db, table, dList = []):
        if dList:
            keylist = dList[0].keys()
            sql = "INSERT INTO %s (%s) VALUES (%s)" % (table, ",".join(keylist), ",".join(['%s']*len(keylist)))
            vallist = []
            for d in dList:
                vallist.append(d.values())
            ret = db.executeMany(sql, vallist)
            return ret

    def alert(self, msg, e=False):
        msg = str(msg)
        if self.debug:
            print msg
        else:
            logging.info(msg)
        if e:
            exit()