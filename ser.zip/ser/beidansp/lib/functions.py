#encoding=gbk
import urllib, urllib2
import XmlConfig
import random
from BeautifulSoup import BeautifulSoup
import logging

def upload(url, path, body):    
    values = {'url'   :   path, 'content'   :   body}
    data = urllib.urlencode(values)
    headers = {}
    res  = urllib2.Request(url,data,headers)
    resp = urllib2.urlopen(res)
    
    return resp.read()

def getUrl(url):
    if url:
        num = random.randint(1, 3)
        conf = XmlConfig.get('/config/define')
        return conf['daili'] % (num, url)
    return ''
    
def n2(str):
    if str:
        return '%.2f' % float(str)
    else:
        return ''

def _getlastexp():
    _lastexp = ""
    try:
        _cururl = "http://www.500.com/static/public/bjdc/xml/expect/activeexpectinfo.xml"
        _res = urllib2.urlopen(_cururl).read()
        _soup = BeautifulSoup(_res) 
        _curexp = _soup.find("row") and _soup.find("row")["expect"] or ""
        if _curexp:
            _lasturl = "http://www.500.com/static/public/bjdc/xml/hcount/expect.xml"
            _res = urllib2.urlopen(_lasturl).read()
            _soup = BeautifulSoup(_res)
            _lastexp = _soup.find("row", {"expect":_curexp}).nextSibling["expect"]
    except:
        logging.info("ǰһ�ڵ��ں��޷���ȷȡ��")
    return _lastexp