#encoding=gbk
import os
import XmlConfig
import urllib2
import re
import datetime, time
from BeautifulSoup import BeautifulSoup
import functions
import logging
import traceback
status = 0

class kjsp:    
    '''�������������'''
    def __init__(self):
        XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/config.xml')
        XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/db.xml')
        pass

    def setXml(self, expect):
        type = '34'
        lx = 'aoke'
        oname = 'kjsp'
        key = "%s_%s" % (oname, type)
        
        today = datetime.datetime.today()
        
        conf = XmlConfig.get('/config/define')
        
        xmlData = {}
        xmlStr = '<?xml version="1.0" encoding="utf-8"?><xml>'
        urllist = XmlConfig.get('/config/%s/url' % lx)
        xmllist = XmlConfig.get('/config/xml')
        
        if expect == '':
            ourl = urllist[key]
        else:
            if expect[0] != '1':
                expect = "1%s" % expect
            ourl = '%s%s/' % (urllist[key], expect)
            
        url = functions.getUrl(ourl)
        resp = urllib2.urlopen(url)
        soap = BeautifulSoup(resp)
        
        if expect == '':
            expect = soap.find('select', {"name":"LotteryNo"}).find("option", {"selected":"selected"})['value']
            if expect[0] != '1':
                expect = "1%s" % expect
        
        data  = soap.find('table', {"class":"ContentBrim"})
        
        if data:
            for d in data.findAll('tr'):
                if d.get('class') != 'LotteryListTitle':
                    tdlist = d.findAll('td')
                    if tdlist:
                            num = int(tdlist[0].text)
                            if not xmlData.get(num):
                                xmlData[num] = []
                                
                            pl = tdlist[8].text
                            
                            xmlData[num].append(num)
                            xmlData[num].append(pl)
                    
        if xmlData:
            for i in range(1, len(xmlData)+1):
                str1 = xmllist[key] % tuple(xmlData[i])
                xmlStr += '<row %s />' % str1
    
        xmlStr += '</xml>'
        path = conf['opath'] % (oname, expect, type)
        
        atnum = functions.upload(conf['FileServerURL'], path, xmlStr)
        logging.info('����XML:%s,���:%s' % (path, atnum))

def checkall(seconds, expect):
    while int(status):
        try:
            p = kjsp()
            p.setXml(expect)
        except:
            logging.info(traceback.format_exc())
        logging.info('sleep %d seconds.' % (seconds))
        time.sleep(seconds)
