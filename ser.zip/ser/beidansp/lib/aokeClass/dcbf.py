#encoding=gbk
import os
import XmlConfig
import urllib2
import re
import datetime, time
from BeautifulSoup import BeautifulSoup
import functions
import logging
import traceback
status = 0

class dcbf:    
    '''�������������'''
    def __init__(self):
        XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/config.xml')
        XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/db.xml')
        pass

    def setXml(self, expect):
        type = '42'
        lx = 'aoke'
        key = "%s_%s" % ('beidan', type)
        today = datetime.datetime.today()
        
        conf = XmlConfig.get('/config/define')
        
        xmlData = {}
        xmlStr = '<?xml version="1.0" encoding="gbk"?><w st="-1">'
        urllist = XmlConfig.get('/config/%s/url' % lx)
        xmllist = XmlConfig.get('/config/xml')
        
        if expect == '':
            ourl = urllist[key]
        else:
            if expect[0] != '1':
                expect = "1%s" % expect
            ourl = '%s%s/' % (urllist[key], expect)
            
        url = functions.getUrl(ourl)
        resp = urllib2.urlopen(url)
        soap = BeautifulSoup(resp)
        
        if expect == '':
            expect = soap.find('select', id="SelectLotteryNo").find("option", {"selected":"true"})['value']
            if expect[0] != '1':
                expect = "1%s" % expect
        
        data  = soap.find('div', id="gametablesend")
        if data:
            num = 0
            for d in data.findAll('tr'):
                if d.get('id'):
                    tdlist = d.findAll('td')
                    if tdlist:
                        num = int(tdlist[0].find("i").text)
                        if not xmlData.get(num):
                            xmlData[num] = []
                        
                        gn = tdlist[0].find("a").text                            
                        h = tdlist[2].find("a", {"class":"duinameh"}).text
                        a = tdlist[2].find("a", {"class":"duinamea"}).text
                        
                        if tdlist[6].text != '-':
                            olist = {}
                            for i in range(25):
                                olist[i] = ''
                                
                            bf = tdlist[6].text.replace("&nbsp;", "").split("-")
                            
                            if len(bf) == 2:
                                a = int(bf[0])
                                b = int(bf[1])
                                
                                pl = ''
                                if tdlist[3].findAll("strong"):
                                    if tdlist[3].findAll("strong")[1]:
                                        pl = functions.n2(tdlist[3].findAll("strong")[1].text.replace("&nbsp;", ""))
                                    
                                if a>b:
                                    if a==1 and b==0:
                                        olist[1] = pl
                                    else:
                                        if a==2 and b==0:
                                            olist[2] = pl
                                        else:
                                            if a==2 and b==1:
                                                olist[3] = pl
                                            else:
                                                if a==3 and b==0:
                                                    olist[4] = pl
                                                else:
                                                    if a==3 and b==1:
                                                        olist[5] = pl
                                                    else:
                                                        if a==3 and b==2:
                                                            olist[6] = pl
                                                        else:
                                                            if a==4 and b==0:
                                                                olist[7] = pl
                                                            else:
                                                                if a==4 and b==1:
                                                                    olist[8] = pl
                                                                else:
                                                                    if a==4 and b==2:
                                                                        olist[9] = pl
                                                                    else:
                                                                        olist[0] = pl
                                else:
                                    if a==b:
                                        if a==0:
                                            olist[11] = pl
                                        else:
                                            if a==1:
                                                olist[12] = pl
                                            else:
                                                if a==2:
                                                    olist[13] = pl
                                                else:
                                                    if a==3:
                                                        olist[14] = pl
                                                    else:
                                                        olist[15] = pl
                                    else:
                                        if a==0 and b==1:
                                                olist[16] = pl
                                        else:
                                            if a==0 and b==2:
                                                olist[17] = pl
                                            else:
                                                if a==1 and b==2:
                                                    olist[18] = pl
                                                else:
                                                    if a==0 and b==3:
                                                        olist[19] = pl
                                                    else:
                                                        if a==1 and b==3:
                                                            olist[20] = pl
                                                        else:
                                                            if a==2 and b==3:
                                                                olist[21] = pl
                                                            else:
                                                                if a==0 and b==4:
                                                                    olist[22] = pl
                                                                else:
                                                                    if a==1 and b==4:
                                                                        olist[23] = pl
                                                                    else:
                                                                        if a==2 and b==4:
                                                                            olist[24] = pl
                                                                        else:
                                                                            olist[15] = pl
                                
                            
                            gn = tdlist[0].find("a").text                            
                            h = tdlist[2].find("a", {"class":"duinameh"}).text
                            a = tdlist[2].find("a", {"class":"duinamea"}).text
                            
                            xmlData[num].append(num)
                            for i in range(25):
                                xmlData[num].append(olist[i])
                            xmlData[num].append(h)
                            xmlData[num].append(a)
                            xmlData[num].append(gn)
                else:
                    pldiv = d.find('div', {"class":"scoretz_main"})
                    if pldiv:
                        xmlData[num].append(num)
                        for p in pldiv.findAll("p"):
                            olist = []
                            alist = p.findAll("a")
                            for o in p.findAll("a"):
                                pl = o.find("span")
                                if pl:
                                    olist.append(pl.text.replace("&nbsp;", ""))
                            olist.insert(0, olist.pop())
                            
                            for o in olist:
                                xmlData[num].append(o)
                            
                        xmlData[num].append(h)
                        xmlData[num].append(a)
                        xmlData[num].append(gn)
                    else:
                        if num and len(xmlData[num]) == 0:
                            xmlData[num].append(num)
                            for i in range(25):
                                xmlData[num].append('')
                            xmlData[num].append(h)
                            xmlData[num].append(a)
                            xmlData[num].append(gn)
                    
        if xmlData:
            for i in range(1, len(xmlData)+1):
                str1 = xmllist[key] % tuple(xmlData[i])
                xmlStr += '<%s />' % str1
    
        xmlStr += '</w>'
        path = conf['path'] % (expect, type)
        atnum = functions.upload(conf['FileServerURL'], path, xmlStr)
        logging.info('����XML:%s,���:%s' % (path, atnum))

def checkall(seconds, expect):
    while int(status):
        try:
            p = dcbf()
            p.setXml(expect)
        except:
            logging.info(traceback.format_exc())
        logging.info('sleep %d seconds.' % (seconds))
        time.sleep(seconds)
