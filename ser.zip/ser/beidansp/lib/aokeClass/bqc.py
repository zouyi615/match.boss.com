#encoding=gbk
import os
import XmlConfig
import urllib2
import re
import datetime, time
from BeautifulSoup import BeautifulSoup
import functions
import logging
import traceback
status = 0

class bqc:    
    '''�������������'''
    def __init__(self):
        XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/config.xml')
        XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/db.xml')
        pass

    def setXml(self, expect):
        type = '51'
        lx = 'aoke'
        key = "%s_%s" % ('beidan', type)
        today = datetime.datetime.today()
        
        conf = XmlConfig.get('/config/define')
        
        xmlData = {}
        xmlStr = '<?xml version="1.0" encoding="gbk"?><w st="-1">'
        urllist = XmlConfig.get('/config/%s/url' % lx)
        xmllist = XmlConfig.get('/config/xml')
        
        if expect == '':
            ourl = urllist[key]
        else:
            if expect[0] != '1':
                expect = "1%s" % expect
            ourl = '%s%s/' % (urllist[key], expect)
            
        url = functions.getUrl(ourl)
        resp = urllib2.urlopen(url)
        soap = BeautifulSoup(resp)
        
        if expect == '':
            expect = soap.find('select', id="SelectLotteryNo").find("option", {"selected":"true"})['value']
            if expect[0] != '1':
                expect = "1%s" % expect
            
        data  = soap.find('div', id="gametablesend")
        if data:
            for d in data.findAll('tr'):
                if d.get('id'):
                    tdlist = d.findAll('td')
                    if tdlist:
                        num = int(tdlist[0].find("i").text)
                        
                        if not xmlData.get(num):
                            xmlData[num] = []
                            
                        gn = tdlist[0].find("a").text
                        
                        h = tdlist[2].find("a", {"class":"duinameh"}).text
                        a = tdlist[2].find("a", {"class":"duinamea"}).text
                        
                        pl = tdlist[3].findAll("a")
                        if pl:
                            c1 = pl[0].text.replace("&nbsp;", "")
                            c3 = pl[1].text.replace("&nbsp;", "")
                            c5 = pl[2].text.replace("&nbsp;", "")
                            c7 = pl[3].text.replace("&nbsp;", "")
                            c9 = pl[4].text.replace("&nbsp;", "")
                            c11 = pl[5].text.replace("&nbsp;", "")
                            c13 = pl[6].text.replace("&nbsp;", "")
                            c15 = pl[7].text.replace("&nbsp;", "")
                            c17 = pl[8].text.replace("&nbsp;", "")
                        
                        xmlData[num].append(num)
                        xmlData[num].append(c1)
                        xmlData[num].append(c3)
                        xmlData[num].append(c5)
                        xmlData[num].append(c7)
                        xmlData[num].append(c9)
                        xmlData[num].append(c11)
                        xmlData[num].append(c13)
                        xmlData[num].append(c15)
                        xmlData[num].append(c17)
                        xmlData[num].append(h)
                        xmlData[num].append(a)
                        xmlData[num].append(gn)                        
        
        if xmlData:
            for i in range(1, len(xmlData)+1):
                istr = xmllist[key] % tuple(xmlData[i])
                xmlStr += '<%s />' % istr
    
        xmlStr += '</w>'
        path = conf['path'] % (expect, type)
        atnum = functions.upload(conf['FileServerURL'], path, xmlStr)
        logging.info('����XML:%s,���:%s' % (path, atnum))

def checkall(seconds, expect):
    while int(status):
        try:
            p = bqc()
            p.setXml(expect)
        except:
            logging.info(traceback.format_exc())
        logging.info('sleep %d seconds.' % (seconds))
        time.sleep(seconds)
