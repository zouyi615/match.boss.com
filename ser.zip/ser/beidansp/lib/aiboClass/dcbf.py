#encoding=gbk
import os
import XmlConfig
import urllib2
import re
import datetime, time
from BeautifulSoup import BeautifulSoup
import functions
import logging
import traceback
status = 0

class dcbf:    
    '''�������������'''
    def setXml(self, expect):
        type = '42'
        lx = 'aibo'
        key = "%s_%s" % ('beidan', type)
        today = datetime.datetime.today()
        
        conf = XmlConfig.get('/config/define')
        
        xmlData = {}
        xmlStr = '<?xml version="1.0" encoding="gbk"?><w st="-1">'
        urllist = XmlConfig.get('/config/%s/url' % lx)
        xmllist = XmlConfig.get('/config/xml')
        if expect == '':
            url = functions.getUrl(urllist[key])
            resp = urllib2.urlopen(url)
            soap = BeautifulSoup(resp)
            
            expect = soap.find('select', id="drpWareNo").find("option", {"selected":"selected"}).text
            if expect[0] != '1':
                expect = "1%s" % expect
            dataList  = soap.findAll('div', {"class":"tzScroll"})
            if dataList:
                i = 0
                for data in dataList:
                    i += 1
                    for d in data.findAll('tr'):
                        if d.get('id'):
                            idlist = d["id"].split("_")
                            if idlist[0] == 'R1' or idlist[0] == 'S1':
                                thlist = d.findAll("th")
                                num = int(thlist[0].text)
                                if not xmlData.get(num):
                                    xmlData[num] = []
                                gn = thlist[1].text
                                h = thlist[2].text.replace("���ӣ�", "")
                                a = thlist[3].text.replace("�Ͷӣ�", "")
                                olist = []
                            else:
                                tdlist = d.findAll("td")
                                pattern = re.compile('<span class="bf">[^\<]+</span><(strong|span)[^\>]*>([^\<]*)<')
                                for i in range(len(tdlist)):
                                    m = pattern.findall(str(tdlist[i]))
                                    if m:
                                        if m[0][1] and m[0][1] != '&nbsp;':
                                            olist.append(functions.n2(m[0][1])) 
                                        else:
                                            olist.append('')
                                    else:
                                        #<td class="box"><span class="bf">1:0</span>8.52</td>
                                        pattern1 = re.compile('<td class="box"><span class="bf">[^\<]+</span>([^\<]*)</td>')
                                        tm = pattern1.findall(str(tdlist[i]))
                                        if tm:
                                            if tm[0] and tm[0] != '&nbsp;':
                                                olist.append(functions.n2(tm[0])) 
                                            else:
                                                olist.append('')
                                
                                if idlist[0] == 'R4' or idlist[0] == 'S4':
                                    xmlData[num].append(num)
                                    for o in olist:
                                        xmlData[num].append(o)
                                    xmlData[num].append(h)
                                    xmlData[num].append(a)
                                    xmlData[num].append(gn)
                            
        else:
            hiskey = "%s_his" % (lx)
            url = functions.getUrl(urllist[hiskey] % expect)
            if expect[0] != '1':
                expect = "1%s" % expect
            resp = urllib2.urlopen(url)
            soap = BeautifulSoup(resp)
            if soap and soap.find("table", id="drawBox"):
                trlist = soap.find("table", id="drawBox").findAll("tr")
                if trlist:
                    for tr in trlist:
                        tdlist = tr.findAll("td")
                        if tdlist:
                            num = int(tdlist[0].text)
                            if not xmlData.get(num):
                                xmlData[num] = []
                                
                            if re.search('\(([^\)]+)\)', tdlist[2].text):
                                r = re.search('\(([^\)]+)\)', tdlist[2].text).group(1)
                            else:
                                r = 0
                            
                            olist = {}
                            for i in range(25):
                                olist[i] = ''
                            
                            bf = tdlist[4].text.replace("&nbsp;", "").split(":")
                            if len(bf) == 2:
                                a = int(bf[0])
                                b = int(bf[1])
                            	pl = functions.n2(tdlist[9].text.replace("&nbsp;", ""))
                                if a>b:
                                    if a==1 and b==0:
                                        olist[1] = pl
                                    else:
                                        if a==2 and b==0:
                                            olist[2] = pl
                                        else:
                                            if a==2 and b==1:
                                                olist[3] = pl
                                            else:
                                                if a==3 and b==0:
                                                    olist[4] = pl
                                                else:
                                                    if a==3 and b==1:
                                                        olist[5] = pl
                                                    else:
                                                        if a==3 and b==2:
                                                            olist[6] = pl
                                                        else:
                                                            if a==4 and b==0:
                                                                olist[7] = pl
                                                            else:
                                                                if a==4 and b==1:
                                                                    olist[8] = pl
                                                                else:
                                                                    if a==4 and b==2:
                                                                        olist[9] = pl
                                                                    else:
                                                                        olist[0] = pl
                                else:
                                    if a==b:
                                        if a==0:
                                            olist[11] = pl
                                        else:
                                            if a==1:
                                                olist[12] = pl
                                            else:
                                                if a==2:
                                                    olist[13] = pl
                                                else:
                                                    if a==3:
                                                        olist[14] = pl
                                                    else:
                                                        olist[15] = pl
                                    else:
                                        if a==0 and b==1:
                                                olist[16] = pl
                                        else:
                                            if a==0 and b==2:
                                                olist[17] = pl
                                            else:
                                                if a==1 and b==2:
                                                    olist[18] = pl
                                                else:
                                                    if a==0 and b==3:
                                                        olist[19] = pl
                                                    else:
                                                        if a==1 and b==3:
                                                            olist[20] = pl
                                                        else:
                                                            if a==2 and b==3:
                                                                olist[21] = pl
                                                            else:
                                                                if a==0 and b==4:
                                                                    olist[22] = pl
                                                                else:
                                                                    if a==1 and b==4:
                                                                        olist[23] = pl
                                                                    else:
                                                                        if a==2 and b==4:
                                                                            olist[24] = pl
                                                                        else:
                                                                            olist[15] = pl
                                
                            h = re.search('([^\(]+)', tdlist[2].text.replace("&nbsp;", "")).group(0) 
                            a = tdlist[5].text.replace("&nbsp;", "")
                                
                            gn = tdlist[1].text.replace("&nbsp;", "")
                                
                            xmlData[num].append(num)
                            for i in range(25):
                                xmlData[num].append(olist[i])
                            xmlData[num].append(h)
                            xmlData[num].append(a)
                            xmlData[num].append(gn)
        if xmlData:
            for i in range(1, len(xmlData)+1):
                if len(xmlData[i]) == 29:
                    str1 = xmllist[key] % tuple(xmlData[i])
                    xmlStr += '<%s />' % str1
    
        xmlStr += '</w>'
        path = conf['path'] % (expect, type)
        atnum = functions.upload(conf['FileServerURL'], path, xmlStr)
        logging.info('����XML:%s,���:%s' % (path, atnum))

def checkall(seconds, expect):
    while int(status):
        try:
            p = dcbf()
            p.setXml(expect)
            
            lastexp = functions._getlastexp()
            if lastexp:
                p.setXml(lastexp)
        except:
            logging.info(traceback.format_exc())
        logging.info('sleep %d seconds.' % (seconds))
        time.sleep(seconds)
