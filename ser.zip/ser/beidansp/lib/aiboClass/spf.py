#encoding=gbk
import os
import XmlConfig
import urllib2
import re
import datetime, time
from BeautifulSoup import BeautifulSoup
import functions
import logging
import traceback
status = 0

class spf:
    '''�������������'''
    def setXml(self, expect):
        type = '34'
        lx = 'aibo'
        key = "%s_%s" % ('beidan', type)
        today = datetime.datetime.today()
        
        conf = XmlConfig.get('/config/define')
        
        xmlData = {}
        xmlStr = '<?xml version="1.0" encoding="gbk"?><w st="-1">'
        urllist = XmlConfig.get('/config/%s/url' % lx)
        xmllist = XmlConfig.get('/config/xml')
        if expect == '':
            url = functions.getUrl(urllist[key])
            resp = urllib2.urlopen(url)
            soap = BeautifulSoup(resp)
            
            expect = soap.find('select', id="drpWareNo").find("option", {"selected":"selected"}).text
            if expect[0] != '1':
                expect = "1%s" % expect
            dataList  = soap.findAll('div', {"class":"tzScroll"})
            if dataList:
                for data in dataList:
                    for d in data.findAll('tr'):
                        if d.get('id'):
                            tdlist = d.findAll('td')
                            if tdlist:
                                num = int(tdlist[0].text)
                                if not xmlData.get(num):
                                    xmlData[num] = []
                                    
                                gn = re.search('([^\(]+)', tdlist[1].text).group(0)
                                h = tdlist[2].text.replace("&nbsp;", "")
                                r = tdlist[3].text.replace("&nbsp;", "")
                                a = tdlist[4].text.replace("&nbsp;", "")
                                c1 = functions.n2(re.sub('[^\d|\.]+', '', tdlist[5].text))
                                c3 = functions.n2(re.sub('[^\d|\.]+', '', tdlist[6].text))
                                c5 = functions.n2(re.sub('[^\d|\.]+', '', tdlist[7].text))
                                
                                xmlData[num].append(num)
                                xmlData[num].append(c1)
                                xmlData[num].append(c3)
                                xmlData[num].append(c5)
                                xmlData[num].append(h)
                                xmlData[num].append(a)
                                xmlData[num].append(r)
                                xmlData[num].append(gn)
                            
        else:
            hiskey = "%s_his" % (lx)
            url = functions.getUrl(urllist[hiskey] % expect)
            if expect[0] != '1':
                expect = "1%s" % expect
            resp = urllib2.urlopen(url)
            soap = BeautifulSoup(resp)
            if soap and soap.find("table", id="drawBox"):
                trlist = soap.find("table", id="drawBox").findAll("tr")
                if trlist:
                    for tr in trlist:
                        tdlist = tr.findAll("td")
                        if tdlist:
                            num = int(tdlist[0].text)
                            if not xmlData.get(num):
                                xmlData[num] = []
                                
                            if re.search('\(([^\)]+)\)', tdlist[2].text):
                                r = re.search('\(([^\)]+)\)', tdlist[2].text).group(1)
                            else:
                                r = 0
                                
                            c1 = c3 = c5 = ''
                            bf = tdlist[4].text.replace("&nbsp;", "").split(":")
                            if len(bf) == 2:
                                if int(bf[0])+int(r) > int(bf[1]):
                                    c1 = functions.n2(tdlist[6].text.replace("&nbsp;", ""))
                                else:
                                    if int(bf[0])+int(r) == int(bf[1]):
                                        c3= functions.n2(tdlist[6].text.replace("&nbsp;", ""))
                                    else:
                                        c5 = functions.n2(tdlist[6].text.replace("&nbsp;", ""))
                            else:
                                c5 = functions.n2(tdlist[6].text.replace("&nbsp;", ""))
                                
                            h = re.search('([^\(]+)', tdlist[2].text.replace("&nbsp;", "")).group(0) 
                            a = tdlist[5].text.replace("&nbsp;", "")
                                
                            gn = tdlist[1].text.replace("&nbsp;", "")
                                
                            xmlData[num].append(num)
                            xmlData[num].append(c1)
                            xmlData[num].append(c3)
                            xmlData[num].append(c5)
                            xmlData[num].append(h)
                            xmlData[num].append(a)
                            xmlData[num].append(r)
                            xmlData[num].append(gn)
        
        if xmlData:
            for i in range(1, len(xmlData)+1):
                str = xmllist[key] % tuple(xmlData[i])
                xmlStr += '<%s />' % str
    
        xmlStr += '</w>'
        path = conf['path'] % (expect, type)
        atnum = functions.upload(conf['FileServerURL'], path, xmlStr)
        logging.info('����XML:%s,���:%s' % (path, atnum))

def checkall(seconds, expect):
    while status:
        try:
            p = spf()
            p.setXml(expect)
            
            lastexp = functions._getlastexp()
            if lastexp:
                p.setXml(lastexp)
        except:
            logging.info(traceback.format_exc())
        logging.info('sleep %d seconds.' % (seconds))
        time.sleep(seconds)
