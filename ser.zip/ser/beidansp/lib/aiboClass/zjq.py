#encoding=gbk
import os
import XmlConfig
import urllib2
import re
import datetime, time
from BeautifulSoup import BeautifulSoup
import functions
import logging
import traceback
status = 0

class zjq:    
    '''�������������'''
    def setXml(self, expect):
        type = '40'
        lx = 'aibo'
        key = "%s_%s" % ('beidan', type)
        today = datetime.datetime.today()
        
        conf = XmlConfig.get('/config/define')
        
        xmlData = {}
        xmlStr = '<?xml version="1.0" encoding="gbk"?><w st="-1">'
        urllist = XmlConfig.get('/config/%s/url' % lx)
        xmllist = XmlConfig.get('/config/xml')
        if expect == '':
            url = functions.getUrl(urllist[key])
            resp = urllib2.urlopen(url)
            soap = BeautifulSoup(resp)
            
            expect = soap.find('select', id="drpWareNo").find("option", {"selected":"selected"}).text
            if expect[0] != '1':
                expect = "1%s" % expect
            dataList  = soap.findAll('div', {"class":"tzScroll"})
            if dataList:
                i = 0
                for data in dataList:
                    i += 1
                    for d in data.findAll('tr'):
                        if d.get('id'):
                            tdlist = d.findAll('td')
                            if tdlist:                            	
                                num = int(tdlist[0].text)
                                if not xmlData.get(num):
                                    xmlData[num] = []
                                    
                                gn = re.search('([^\(]+)', tdlist[1].text).group(0)
                                h = tdlist[2].text.replace("&nbsp;", "")
                                a = tdlist[3].text.replace("&nbsp;", "")
                                
                                pattern = re.compile('<span class="FloatNote">\d\+?</span>[^\d]*(\d+\.?\d*)<')
                                
                                m = pattern.findall(str(tdlist[4]))
                                c1 = functions.n2(m and m[0] or '')
                                m = pattern.findall(str(tdlist[5]))
                                c3 = functions.n2(m and m[0] or '')
                                m = pattern.findall(str(tdlist[6]))
                                c5 = functions.n2(m and m[0] or '')
                                m = pattern.findall(str(tdlist[7]))
                                c7 = functions.n2(m and m[0] or '')
                                m = pattern.findall(str(tdlist[8]))
                                c9 = functions.n2(m and m[0] or '')
                                m = pattern.findall(str(tdlist[9]))
                                c11 = functions.n2(m and m[0] or '')
                                m = pattern.findall(str(tdlist[10]))
                                c13 = functions.n2(m and m[0] or '')
                                m = pattern.findall(str(tdlist[11]))
                                c15 = functions.n2(m and m[0] or '')
                                
                                xmlData[num].append(num)
                                xmlData[num].append(c1)
                                xmlData[num].append(c3)
                                xmlData[num].append(c5)
                                xmlData[num].append(c7)
                                xmlData[num].append(c9)
                                xmlData[num].append(c11)
                                xmlData[num].append(c13)
                                xmlData[num].append(c15)
                                xmlData[num].append(h)
                                xmlData[num].append(a)
                                xmlData[num].append(gn)
                            
        else:
            hiskey = "%s_his" % (lx)
            url = functions.getUrl(urllist[hiskey] % expect)
            if expect[0] != '1':
                expect = "1%s" % expect
            resp = urllib2.urlopen(url)
            soap = BeautifulSoup(resp)
            if soap and soap.find("table", id="drawBox"):
                trlist = soap.find("table", id="drawBox").findAll("tr")
                if trlist:
                    for tr in trlist:
                        tdlist = tr.findAll("td")
                        if tdlist:
                            num = int(tdlist[0].text)
                            if not xmlData.get(num):
                                xmlData[num] = []
                                
                            if re.search('\(([^\)]+)\)', tdlist[2].text):
                                r = re.search('\(([^\)]+)\)', tdlist[2].text).group(1)
                            else:
                                r = 0
                                
                            c1 = c3 = c5 = c7 = c9 = c11 = c13 = c15 = ''
                            bf = tdlist[4].text.replace("&nbsp;", "").split(":")
                            if len(bf) == 2:
                            	zjq = int(bf[0])+int(bf[1])
                            	pl = functions.n2(tdlist[7].text.replace("&nbsp;", ""))
                            	if zjq == 0:
                            		c1 = pl
                            	else:
                            		if zjq == 1:
                            			c3 = pl
                            		else:
                            			if zjq == 2:
                            				c5 = pl
	                            		else:
	                            			if zjq == 3:
	                            				c7 = pl
		                            		else:
		                            			if zjq == 4:
		                            				c9 = pl
			                            		else:
			                            			if zjq == 5:
			                            				c11 = pl
				                            		else:
				                            			if zjq == 6:
				                            				c13 = pl
				                            			else:
				                            				c15 = pl
                            else:
                            	c15 = pl
                                
                            h = re.search('([^\(]+)', tdlist[2].text.replace("&nbsp;", "")).group(0) 
                            a = tdlist[5].text.replace("&nbsp;", "")
                                
                            gn = tdlist[1].text.replace("&nbsp;", "")
                                
                            xmlData[num].append(num)
                            xmlData[num].append(c1)
                            xmlData[num].append(c3)
                            xmlData[num].append(c5)
                            xmlData[num].append(c7)
                            xmlData[num].append(c9)
                            xmlData[num].append(c11)
                            xmlData[num].append(c13)
                            xmlData[num].append(c15)
                            xmlData[num].append(h)
                            xmlData[num].append(a)
                            xmlData[num].append(gn)
        
        if xmlData:
            for i in range(1, len(xmlData)+1):
                str1 = xmllist[key] % tuple(xmlData[i])
                xmlStr += '<%s />' % str1
    
        xmlStr += '</w>'
        path = conf['path'] % (expect, type)
        atnum = functions.upload(conf['FileServerURL'], path, xmlStr)
        logging.info('����XML:%s,���:%s' % (path, atnum))

def checkall(seconds, expect):
    while int(status):
        try:
            p = zjq()
            p.setXml(expect)
            
            lastexp = functions._getlastexp()
            if lastexp:
                p.setXml(lastexp)
        except:
            logging.info(traceback.format_exc())
        logging.info('sleep %d seconds.' % (seconds))
        time.sleep(seconds)
