#coding:gbk
import time
import Db.Mysql
from module.func import common as Func
__DB_CONN__={}
def Db_Instance(id):
    if not __DB_CONN__.has_key(id):
        __DB_CONN__[id]=Db.Mysql.get(id)
    return __DB_CONN__[id]

Redis_Obj={}
def Redis_Instance():
    global Redis_Obj
    if not Redis_Obj:
        import redis
        config=Func.getPath('redis_config')
        Redis_Obj=redis.Redis(config['host'],config['port'])
    return Redis_Obj
        
class Db_Betbrain:
    def __init__(self):
        pass
    
    def getDownloadFile(self):
        '''��ȡδ������update�ļ�'''
        sql='select * from t_zq_downloadfile where status=0 order by id limit 50'
        return Db.Mysql.get('BetbrainSlave').query(sql)  
    
    def updateFileStatus(self,status,id):
        '''����update�ļ���״̬'''
        if isinstance(id,list):
            sql='update t_zq_downloadfile set status=%s where id in(%s)'%(status,','.join(id))
        else:
            sql='update t_zq_downloadfile set status=%s where id=%s'%(status,id)
        Db.Mysql.get('BetbrainMaster').execute(sql)
    
    def insertOutcomeInfo(self,row):
        #��������id���������͵���Ϣ
#         sql='insert into t_zq_outcome(id,iscomplete,typeid,isnegation,statusid,eventid,eventpartid,paramparticipantid1,paramparticipantid2,paramparticipantid3,parameventpartid1,paramfloat1,paramfloat2,paramfloat3,paramboolean1,paramstring1)values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
#         args=[row['id'],row['iscomplete'],row['typeid'],row['isnegation'],row['statusid'],row['eventid'],row['eventpartid'],row['paramparticipantid1'],row['paramparticipantid2'],row['paramparticipantid3'],row['parameventpartid1'],row['paramfloat1'],row['paramfloat2'],row['paramfloat3'],row['paramboolean1'],row['paramstring1']]
#         Db.Mysql.get('BetbrainMaster').query(sql,args)
        sql='insert into '+self.getOutcomeTable(row['id'])+'(id,typeid,isnegation,eventid,eventpartid,paramparticipantid1,paramparticipantid2,paramfloat1,paramfloat2)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        args=[row['id'],row['typeid'],row['isnegation'],row['eventid'],row['eventpartid'],row['paramparticipantid1'],row['paramparticipantid2'],row['paramfloat1'],row['paramfloat2']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
        
        sql='insert into '+self.getOutcomeTableByEventid(row['eventid'])+'(id,typeid,isnegation,eventid,eventpartid,paramparticipantid1,paramparticipantid2,paramfloat1,paramfloat2)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        args=[row['id'],row['typeid'],row['isnegation'],row['eventid'],row['eventpartid'],row['paramparticipantid1'],row['paramparticipantid2'],row['paramfloat1'],row['paramfloat2']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
        self.saveOutcomeEventRelation(row['id'],row['eventid'])
    
    def deleteOutcomeInfo(self,id):
        #ɾ������id���������͵���Ϣ
#         sql='delete from t_zq_outcome where id=%s'
#         args=[id]
#        Db.Mysql.get('BetbrainMaster').query(sql,args)
        sql="delete from "+self.getOutcomeTable(id)+' where id=%s'
        args=[id]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def updateOutcomeInfo(self,row):
        #�޸�����id���������͵���Ϣ
#         sql='update t_zq_outcome set '
#         args=[]
#         sp=''
#         for k in row:
#             sql+=sp+k+'=%s'
#             sp=','
#             args.append(row[k])
#         sql+=' where id=%s'
#         args.append(row['id'])
#         Db.Mysql.get('BetbrainMaster').execute(sql,args)
        args=[]
        field_arr=[]
        for field in ['typeid','isnegation','eventid','eventpartid','paramparticipantid1','paramparticipantid2','paramfloat1','paramfloat2']:
            if row.has_key(field):
                field_arr.append('field=%s')
                args.append(row[field])
        
        if field_arr:
            field_str=','.join(field_arr)
            db=Db.Mysql.get('BetbrainMaster')
            sql='update '+self.getOutcomeTable(row['id'])+' set '+field_str+' where id=%s'
            args.append(row['id'])
            affect_rows=Db.Mysql.get('BetbrainMaster').execute(sql,args)
            #�ж��Ƿ��и���
            if affect_rows:
               sql='select eventid from '+self.getOutcomeTable(row['id'])+ ' where id=%s'
               tmp=db.queryOne(sql,[row['id']])
               if tmp:
                   sql='update '+self.getOutcomeTableByEventid(row['eventid'])+' set '+field_str+' where id=%s'
                   Db.Mysql.get('BetbrainMaster').execute(sql,args)
            
    
    def saveOutcomeInfo(self,row):
        #��������id���������͵���Ϣ
#         sql='replace into t_zq_outcome set iscomplete=%s,typeid=%s,isnegation=%s,statusid=%s,eventid=%s,eventpartid=%s,paramparticipantid1=%s,paramparticipantid2=%s,paramparticipantid3=%s,parameventpartid1=%s,paramfloat1=%s,paramfloat2=%s,paramfloat3=%s,paramboolean1=%s,paramstring1=%s,id=%s'
#         args=[row['iscomplete'],row['typeid'],row['isnegation'],row['statusid'],row['eventid'],row['eventpartid'],row['paramparticipantid1'],row['paramparticipantid2'],row['paramparticipantid3'],row['parameventpartid1'],row['paramfloat1'],row['paramfloat2'],row['paramfloat3'],row['paramboolean1'],row['paramstring1'],row['id']]
#         Db.Mysql.get('BetbrainMaster').query(sql,args)
        sql="replace into "+self.getOutcomeTable(row['id'])+" set typeid=%s,isnegation=%s,eventid=%s,eventpartid=%s,paramparticipantid1=%s,paramparticipantid2=%s,paramfloat1=%s,paramfloat2=%s,id=%s"
        args=[row['typeid'],row['isnegation'],row['eventid'],row['eventpartid'],row['paramparticipantid1'],row['paramparticipantid2'],row['paramfloat1'],row['paramfloat2'],row['id']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)        
        
        sql="replace into "+self.getOutcomeTableByEventid(row['eventid'])+" set typeid=%s,isnegation=%s,eventid=%s,eventpartid=%s,paramparticipantid1=%s,paramparticipantid2=%s,paramfloat1=%s,paramfloat2=%s,id=%s"
        args=[row['typeid'],row['isnegation'],row['eventid'],row['eventpartid'],row['paramparticipantid1'],row['paramparticipantid2'],row['paramfloat1'],row['paramfloat2'],row['id']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
        
        
        self.saveOutcomeEventRelation(row['id'],row['eventid'])
    
    def getOutcomeTable(self,outcomeid):
        return 't_zq_outcome_sec_%s'%(outcomeid%30)
    
    def getOutcomeTableByEventid(self,eventid):
        return 't_zq_outcome_event_sec_%s'%(eventid%30)
    
    def saveOutcomeEventRelation(self,outcomeid,eventid):
        '''����outcomeid��eventid�Ĺ�����ϵ'''
        key='outcome:%s'%outcomeid
        Redis_Instance().set(key,eventid)
        Redis_Instance().expire(key,3600)
    
    def getOutcomeEventRelation(self,outcomeid):
        '''��ȡoutcomeid��eventid�Ĺ�����ϵ'''
        return Redis_Instance().get('outcome:%s'%outcomeid)
    
    def updateEventInfo(self,row):
        #�޸�������Ϣ
        sql='update t_zq_event set '
        args=[]
        sp=''
        for k in row:
            sql+=sp+k+'=%s'
            sp=','
            args.append(row[k])
        sql+=' where id=%s'
        args.append(row['id'])
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    

    def insertEventInfo(self,row):
        #����������Ϣ
        sql='insert into t_zq_event(id,iscomplete,typeid,sportid,templateid,promotionid,parentid,parentpartid,name,starttime,endtime,deletetimeoffset,venueid,statusid,rootpartid,currentpartid,url,popularity,note)values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        args=[row['id'],row['iscomplete'],row['typeid'],row['sportid'],row['templateid'],row['promotionid'],row['parentid'],row['parentpartid'],row['name'],row['starttime'],row['endtime'],row['deletetimeoffset'],row['venueid'],row['statusid'],row['rootpartid'],row['currentpartid'],row['url'],row['popularity'],row['note']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def deleteEventInfo(self,id):
        #ɾ��������Ϣ
        sql='delete from t_zq_event where id=%s'
        args=[id]
#        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def saveEventInfo(self,row):
        #����������Ϣ
        sql='replace into t_zq_event set iscomplete=%s,typeid=%s,sportid=%s,templateid=%s,promotionid=%s,parentid=%s,parentpartid=%s,name=%s,starttime=%s,endtime=%s,deletetimeoffset=%s,venueid=%s,statusid=%s,rootpartid=%s,currentpartid=%s,url=%s,popularity=%s,note=%s,id=%s'
        args=[row['iscomplete'],row['typeid'],row['sportid'],row['templateid'],row['promotionid'],row['parentid'],row['parentpartid'],row['name'],row['starttime'],row['endtime'],row['deletetimeoffset'],row['venueid'],row['statusid'],row['rootpartid'],row['currentpartid'],row['url'],row['popularity'],row['note'],row['id']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def insertEventParticipantRelationInfo(self,row):
        #������������ӹ�����Ϣ
        sql='insert into t_zq_eventparticipantrelation(id,eventid,eventpartid,participantid,participantroleid,parentparticipantid)values(%s,%s,%s,%s,%s,%s)'
        args=[row['id'],row['eventid'],row['eventpartid'],row['participantid'],row['participantroleid'],row['parentparticipantid']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def deleteEventParticipantRelationInfo(self,id):
        #ɾ����������ӹ�����Ϣ
        sql='delete from t_zq_eventparticipantrelation where id=%s'
        args=[id]
#        Db.Mysql.get('BetbrainMaster').query(sql,args)

    def updateEventParticipantRelationInfo(self,row):
            #�޸�������Ϣ
            sql='update t_zq_eventparticipantrelation set '
            args=[]
            sp=''
            for k in row:
                sql+=sp+k+'=%s'
                sp=','
                args.append(row[k])
            sql+=' where id=%s'
            args.append(row['id'])
            Db.Mysql.get('BetbrainMaster').query(sql,args)

    def saveEventParticipantRelationInfo(self,row):
        #������������ӹ�����Ϣ
        sql='replace into t_zq_eventparticipantrelation set eventid=%s,eventpartid=%s,participantid=%s,participantroleid=%s,parentparticipantid=%s,id=%s'
        args=[row['eventid'],row['eventpartid'],row['participantid'],row['participantroleid'],row['parentparticipantid'],row['id']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def insertParticipantInfo(self,row):
        #���������Ϣ
        sql='insert into t_zq_participant(id,typeid,name,firstname,lastname,ismale,birthtime,countryid,retirementtime,note)values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        args=[row['id'],row['typeid'],row['name'],row['firstname'],row['lastname'],row['ismale'],row['birthtime'],row['countryid'],row['retirementtime'],row['note']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def saveParticipantInfo(self,row):  
        #���������Ϣ      
        sql='replace into t_zq_participant set typeid=%s,name=%s,firstname=%s,lastname=%s,ismale=%s,birthtime=%s,countryid=%s,retirementtime=%s,note=%s,id=%s'
        args=[row['typeid'],row['name'],row['firstname'],row['lastname'],row['ismale'],row['birthtime'],row['countryid'],row['retirementtime'],row['note'],row['id']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def deleteParticipantInfo(self,id):
        sql='delete from t_zq_participant where id=%s'
        args=[id]
        Db.Mysql.get('BetbrainMaster').execute(sql,args)
    
    def updateParticipantInfo(self,row):
        #�޸������Ϣ
        sql='update t_zq_participant set '
        args=[]
        sp=''
        for k in row:
            sql+=sp+k+'=%s'
            sp=','
            args.append(row[k])
        sql+=' where id=%s'
        args.append(row['id'])
        Db.Mysql.get('BetbrainMaster').query(sql,args)
        
    def insertProviderInfo(self,row):
        #���ӹ�˾��Ϣ
        sql='insert into t_zq_provider(id,name,locationid,url,isbookmaker,isbettingexchange,bettingcommissionvacs,isnewssource,isenabled,note)values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        args=[row['id'],row['name'],row['locationid'],row['url'],row['isbookmaker'],row['isbettingexchange'],row['bettingcommissionvacs'],row['isnewssource'],row['isenabled'],row['note']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def saveProviderInfo(self,row):
        #���湫˾��Ϣ
#         sql='replace into t_zq_provider set name=%s,locationid=%s,url=%s,isbookmaker=%s,isbettingexchange=%s,bettingcommissionvacs=%s,isnewssource=%s,isenabled=%s,note=%s,id=%s'
#         args=[row['name'],row['locationid'],row['url'],row['isbookmaker'],row['isbettingexchange'],row['bettingcommissionvacs'],row['isnewssource'],row['isenabled'],row['note'],row['id']]
        sql='insert into t_zq_provider(id,name,locationid,url,isbookmaker,isbettingexchange,bettingcommissionvacs,isnewssource,isenabled,note)values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) ON DUPLICATE KEY UPDATE name=%s,locationid=%s,url=%s,isbookmaker=%s,isbettingexchange=%s,bettingcommissionvacs=%s,isnewssource=%s,isenabled=%s,note=%s'
        args=[row['id'],row['name'],row['locationid'],row['url'],row['isbookmaker'],row['isbettingexchange'],row['bettingcommissionvacs'],row['isnewssource'],row['isenabled'],row['note'],row['name'],row['locationid'],row['url'],row['isbookmaker'],row['isbettingexchange'],row['bettingcommissionvacs'],row['isnewssource'],row['isenabled'],row['note']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def updateProviderInfo(self,row):
        #�޸Ĺ�˾��Ϣ
        sql='update t_zq_provider set '
        args=[]
        sp=''
        for k in row:
            sql+=sp+k+'=%s'
            sp=','
            args.append(row[k])
        sql+=' where id=%s'
        args.append(row['id'])
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def insertBettingOfferInfo(self,row):
#        '''����BettingOffer��ǩ'''       
        tmp=self.getEventidByOutcomeid(row['outcomeid'])
        if tmp:
            sql='insert into '+self.geteBettingOfferLiveTable(row['id'])+'(bettingofferid,bettingtypeid,outcomeid,eventid,providerid,odds,lastchangedtime,lastchangedtime_ms)values(%s,%s,%s,%s,%s,%s,%s,%s)'
            args=[row['id'],row['bettingtypeid'],row['outcomeid'],tmp['eventid'],row['providerid'],row['odds'],row['lastchangedtime'],row['lastchangedtime_ms']]
            Db.Mysql.get('BetbrainMaster').execute(sql,args)
            
            sql='insert into '+self.getOddsChangeTable(tmp['eventid'],row['bettingtypeid'])+'(bettingofferid,bettingtypeid,eventid,outcomeid,providerid,odds,lastchangedtime,lastchangedtime_ms,addtime)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)'
            args=[row['id'],row['bettingtypeid'],tmp['eventid'],row['outcomeid'],row['providerid'],row['odds'],row['lastchangedtime'],row['lastchangedtime_ms'],time.strftime("%Y-%m-%d %H:%M:%S")]
            Db.Mysql.get('BetbrainMaster').execute(sql,args)
    
    def deleteBettingOfferInfo(self,id):
#        '''ɾ��BettingOffer��ǩ'''
#        sql='delete from t_zq_bettingoffer where id=%s'
#        args=[id]
#        Db.Mysql.get('BetbrainMaster').execute(sql,args)

#        sql='select * from '+self.geteBettingOfferLiveTable(id)+' where bettingofferid=%s'
#        args=[id]
#        tmp=Db.Mysql.get('BetbrainSlave').queryOne(sql,args)
#        if tmp:
#            sql='delete from '+self.geteBettingOfferLiveTable(id)+' where bettingofferid=%s'
#            args=[id]
#            Db.Mysql.get('BetbrainMaster').execute(sql,args)
#            
#            sql='delete from '+self.getOddsChangeTable(tmp['eventid'])+' where bettingofferid=%s'
#            args=[id]
#            Db.Mysql.get('BetbrainMaster').execute(sql,args)
        sql='delete from '+self.geteBettingOfferLiveTable(id)+' where bettingofferid=%s'
        args=[id]
        Db.Mysql.get('BetbrainMaster').execute(sql,args)
        
    
    def updateBettingOfferInfo(self,row):
#        '''����BettingOffer��ǩ'''
#        sql='update t_zq_bettingoffer set '
#        args=[]
#        sp=''
#        for k in row:
#            sql+=sp+k+'=%s'
#            sp=','
#            args.append(row[k])
#        sql+=' where id=%s'
#        args.append(row['id'])
#        Db.Mysql.get('BetbrainMaster').execute(sql,args)
        
        '''���ʷ����仯'''
        if row.has_key('odds'):
            '''��ȡ����id����ǰ������Ϣ'''
            sql='select * from '+self.geteBettingOfferLiveTable(row['id'])+' where bettingofferid=%s'
            args=[row['id']]
            tmp=Db.Mysql.get('BetbrainMaster').queryOne(sql,args)
            if tmp and row['odds']!=tmp['odds']:
                '''���ʷ����仯'''
                if row.has_key('lastchangedtime'):
                    lastchangedtime=row['lastchangedtime']
                    lastchangedtime_ms=row['lastchangedtime_ms']
                else:
                    lastchangedtime=tmp['lastchangedtime']
                    lastchangedtime_ms=tmp['lastchangedtime_ms']
                sql='insert into '+self.getOddsChangeTable(tmp['eventid'],tmp['bettingtypeid'])+'(bettingofferid,bettingtypeid,eventid,outcomeid,providerid,odds,lastchangedtime,lastchangedtime_ms,addtime)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)'
                args=[row['id'],tmp['bettingtypeid'],tmp['eventid'],tmp['outcomeid'],tmp['providerid'],row['odds'],lastchangedtime,lastchangedtime_ms,time.strftime("%Y-%m-%d %H:%M:%S")]
                Db.Mysql.get('BetbrainMaster').execute(sql,args)
                
        '''�޸ļ�ʱ��������'''
        if row.has_key('odds') and row.has_key('lastchangedtime'):
            sql='update '+self.geteBettingOfferLiveTable(row['id'])+' set odds=%s,lastchangedtime=%s,lastchangedtime_ms=%s where bettingofferid=%s'
            args=[row['odds'],row['lastchangedtime'],row['lastchangedtime_ms'],row['id']]
            Db.Mysql.get('BetbrainMaster').execute(sql,args)
        
        elif row.has_key('odds'):
            sql='update '+self.geteBettingOfferLiveTable(row['id'])+' set odds=%s where bettingofferid=%s'
            args=[row['odds'],row['id']]
            Db.Mysql.get('BetbrainMaster').execute(sql,args)
        
        elif row.has_key('lastchangedtime'):
            sql='update '+self.geteBettingOfferLiveTable(row['id'])+' set lastchangedtime=%s,lastchangedtime_ms=%s where bettingofferid=%s'
            args=[row['lastchangedtime'],row['lastchangedtime_ms'],row['id']]
            Db.Mysql.get('BetbrainMaster').execute(sql,args)

    def saveBettingOfferInfo(self,row):
#        '''����BettingOffer��ǩ'''
#        sql='replace into t_zq_bettingoffer set id=%s,providerid=%s,sourceid=%s,outcomeid=%s,bettingtypeid=%s,statusid=%s,islive=%s,odds=%s,multiplicity=%s,volume=%s,volumecurrencyid=%s,couponkey=%s,slotnum=%s,lastchangedtime=%s,lastchangedtime_ms=%s'
#        args=[row['id'],row['providerid'],row['sourceid'],row['outcomeid'],row['bettingtypeid'],row['statusid'],row['islive'],row['odds'],row['multiplicity'],row['volume'],row['volumecurrencyid'],row['couponkey'],row['slotnum'],row['lastchangedtime'],row['lastchangedtime_ms']]
#        Db.Mysql.get('BetbrainMaster').execute(sql,args)
        
        tmp=self.getEventidByOutcomeid(row['outcomeid'])
        if tmp:
            sql='insert into '+self.geteBettingOfferLiveTable(row['id'])+'(bettingofferid,bettingtypeid,outcomeid,eventid,providerid,odds,lastchangedtime,lastchangedtime_ms)values(%s,%s,%s,%s,%s,%s,%s,%s) ON DUPLICATE KEY UPDATE odds=%s,lastchangedtime=%s,lastchangedtime_ms=%s'
            args=[row['id'],row['bettingtypeid'],row['outcomeid'],tmp['eventid'],row['providerid'],row['odds'],row['lastchangedtime'],row['lastchangedtime_ms'],row['odds'],row['lastchangedtime'],row['lastchangedtime_ms']]
            result=Db.Mysql.get('BetbrainMaster').execute(sql,args)
            if result:
                sql='insert into '+self.getOddsChangeTable(tmp['eventid'],row['bettingtypeid'])+'(bettingofferid,bettingtypeid,eventid,outcomeid,providerid,odds,lastchangedtime,lastchangedtime_ms,addtime)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)'
                args=[row['id'],row['bettingtypeid'],tmp['eventid'],row['outcomeid'],row['providerid'],row['odds'],row['lastchangedtime'],row['lastchangedtime_ms'],time.strftime("%Y-%m-%d %H:%M:%S")]
                Db.Mysql.get('BetbrainMaster').execute(sql,args)
    
    def getEventidByOutcomeid(self,outcomeid):
        eventid=self.getOutcomeEventRelation(outcomeid)
        if not eventid:
            sql='select eventid from '+self.getOutcomeTable(outcomeid)+' where id=%s'
            args=[outcomeid]
            tmp=Db.Mysql.get('BetbrainMaster').queryOne(sql,args)
            if tmp:
                self.saveOutcomeEventRelation(outcomeid,tmp['eventid'])
        else:
            tmp={'eventid':int(eventid)}
        return tmp
    
#     def saveBettingOfferLiveCacheInfo(self,id,info):
#         key='bettingofferlive:%s'%id
#         Redis_Instance().set(key,info)
#         Redis_Instance().expire(key,3600)
    
#     def getBettingOfferLiveCacheInfo(self,id):
#         return Redis_Instance().get('bettingofferlive:%s'%id)
    
#     def getBettingOfferLiveInfo(self,id):
#         row=self.getBettingOfferLiveCacheInfo(id)
#         if not row:
#             sql='select * from '+self.geteBettingOfferLiveTable(id)+' where bettingofferid=%s'
#             args=[id]
#             row=Db.Mysql.get('BetbrainMaster').queryOne(sql,args)
#             if row:
#                 self.saveBettingOfferLiveCacheInfo(id,{'outcomeid':row['outcomeid'],'eventid':row['eventid'],'providerid':row['providerid'],'odds':row['odds'],'lastchangedtime':row['lastchangedtime'],'lastchangedtime_ms':row['lastchangedtime_ms']})
#         return row     
        
    def geteBettingOfferLiveTable(self,id):
        return 't_zq_bettingoffer_live_%s'%(id%100)
    
    def geteBettingOfferLiveBakTable(self):
        return 't_zq_bettingoffer_live_bak'
        
    def getOddsChangeTable(self,eventid,bettingtypeid):
        if bettingtypeid==69:
            i=0
        elif bettingtypeid==48:
            i=1
        else:
            i=2            
        return 't_zq_odds_change_%s_%s'%(eventid%200,i)
    
    def getOddsChangeBakTable(self):
        return 't_zq_odds_change_bak'
        
#    def getBetttingOfferInfoById(self,id):
#        '''ͨ��id��ȡͶע����'''
#        sql='select * from t_zq_bettingoffer_base where bettingofferid=%s'
#        args=[id]
#        return Db.Mysql.get('BetbrainMaster').queryOne(sql,args)
#    
#    def getBettingOfferTable(self,typeid):
#        #47��С��  69ŷ��  48����
#        if typeid==69:
#            table='t_zq_bettingoffer_euro'
#        elif typeid==48:
#            table='t_zq_bettingoffer_asian'
#        elif typeid==47:
#            table='t_zq_bettingoffer_big'
#        else:
#            table=''
#        return table
    
#    def getOddsTable(self,typeid):
#        if typeid==69:
#            table='t_zq_odds_euro'
#        elif typeid==48:
#            table='t_zq_odds_asian'
#        elif typeid==47:
#            table='t_zq_odds_big'
#        else:
#            table=''
#        return table
    
#    def addBetbrainOdds(self,typeid,bettingofferid,odds,lastchangedtime):
#        sql='insert into '+self.getOddsTable(typeid)+'(bettingofferid,odds,lastchangedtime,addtime)values(%s,%s,%s,%s)'
#        args=[bettingofferid,odds,lastchangedtime,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())]
#        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    def getEventInfo(self,begin,endtime):
        '''��ȡ������Ϣ'''
        sql='select id,DATE_ADD(starttime,INTERVAL 8 hour) as starttime from t_zq_event where iscomplete=1 and starttime>=%s and starttime<%s and typeid=1 and statusid!=3'
        args=[begin,endtime]
        return Db.Mysql.get('BetbrainSlave').query(sql,args)
    
    def get500MatchList(self,begintime,endtime):
        '''��ȡ���¿�����'''
        sql="select a.fixtureid,a.home,a.away,a.vsdate as matchdatetime,a.betbrain_1,a.betbrain_2,a.islottyle,a.isbeidan,b.sourcelimit,b.sourceoddslimit from v_getfixturepipei as a left join t_s_fixture_ext as b on a.fixtureid=b.fixtureid where a.vsdate>=%s and a.vsdate<%s"
        args=[begintime,endtime]
        return Db.Mysql.get('SoccerSlave').query(sql,args)
    
    def getParticipantInfoByEventId(self,eventid):
        '''ParticipantRole��������:
        <ParticipantRole  id="1" name="Home" isPrimary="true" />
        <ParticipantRole  id="2" name="Away" isPrimary="true" />
        <ParticipantRole  id="3" name="Player" isPrimary="true" />
        <ParticipantRole  id="4" name="Primary" isPrimary="true" />
        '''
        sql='select a.*,b.name from t_zq_eventparticipantrelation as a inner join t_zq_participant as b on a.participantid=b.id where a.eventid=%s and participantroleid in(1,2)'
        args=[eventid]
        return Db.Mysql.get('BetbrainSlave').query(sql,args)    
    
#     def getOddsInfoByEventId(self,type,eventid,lastchangedtime):
#         changeTable=self.getOddsChangeTable(eventid,self.getBettingTypeid(type))
#         eventTable=self.getOutcomeTableByEventid(eventid)
#         sql='''select a.id,a.bettingofferid,a.outcomeid,a.providerid as companyid,a.odds,a.lastchangedtime,c.name as companyname,b.typeid as outcometype,b.paramparticipantid1,b.paramfloat1  from %s as a inner join %s as b on a.outcomeid=b.id inner join t_zq_provider as c on a.providerid=c.id'''%(changeTable,eventTable)
#         if type=='euro':
#             sql+=' where b.eventid=%s and b.isnegation=0 and b.typeid in(10,11) and b.eventpartid=3 and a.status=0 and a.lastchangedtime<%s'
#             
#         elif type=='asian':
#             sql+=' where b.eventid=%s and b.isnegation=0 and b.typeid=60 and b.eventpartid=3 and a.status=0 and a.lastchangedtime<%s'
#         
#         else:
#             sql+=' where b.eventid=%s and b.isnegation=0 and b.typeid in(13,14) and b.eventpartid=3 and a.status=0 and a.lastchangedtime<%s'
#         sql+=" order by a.lastchangedtime_ms,a.id"
#         args=[eventid,lastchangedtime]
#         
#         return Db.Mysql.get('BetbrainSlave').query(sql,args)
    
    def getOddsListByEventid(self,type,eventid,lastchangedtime):
        changeTable=self.getOddsChangeTable(eventid,self.getBettingTypeid(type))
        eventTable=self.getOutcomeTableByEventid(eventid)
        sql='''select a.id,a.outcomeid,a.providerid as companyid,a.odds,a.lastchangedtime,c.name as companyname,c.companyid_500,b.typeid as outcometype,b.paramparticipantid1,b.paramfloat1 from %s as a inner join %s as b on a.outcomeid=b.id inner join t_zq_provider as c on a.providerid=c.id'''%(changeTable,eventTable)
        #ŷ��
        if type=='euro':
            sql+=' where b.eventid=%s and b.isnegation=0 and b.typeid in(10,11) and b.eventpartid=3 and a.status=0 and a.lastchangedtime<%s and c.companyid_500>0 and c.source_betbrain=1'
        #����
        elif type=='asian':
            sql+=' where b.eventid=%s and b.isnegation=0 and b.typeid=60 and b.eventpartid=3 and a.status=0 and a.lastchangedtime<%s and c.companyid_500>0 and c.source_betbrain_a=1'
        #��С
        else:
            sql+=' where b.eventid=%s and b.isnegation=0 and b.typeid in(13,14) and b.eventpartid=3 and a.status=0 and a.lastchangedtime<%s and c.companyid_500>0 and c.source_betbrain_a=1'
            
        args=[eventid,lastchangedtime]
        return Db.Mysql.get('BetbrainSlave').query(sql,args)
            
    def get500CompanyInfoByName(self,companyname):
        '''��ȡ��˾��Ϣ'''
        sql="select id,companyname,source_betbrain,source_betbrain_a from t_odds_company where betbrain=%s"
        args=[companyname]
        return Db.Mysql.get('SoccerSlave').queryOne(sql,args)

    def updateOddsInfoStatus(self,type,eventid,ids):
        if isinstance(ids,list):
            sql='update '+self.getOddsChangeTable(eventid,self.getBettingTypeid(type))+' set status=1 where id in (%s)'%(','.join(ids))
            Db.Mysql.get('BetbrainMaster').execute(sql)
        else:
            sql='update '+self.getOddsChangeTable(eventid,self.getBettingTypeid(type))+' set status=1 where id=%s'
            args=[ids]
            Db.Mysql.get('BetbrainMaster').execute(sql,args)
    
    def getAsianHandicapline(self):
        sql='select handicaplineid,handicapline,handicaplinename from t_s_odds_handicapline'
        return Db.Mysql.get('SoccerSlave').query(sql)
    
    def getBigHandicapline(self):
        sql='select handiname,handivalue from t_s_odds_handicapbig'
        return Db.Mysql.get('SoccerSlave').query(sql)
    
    def getLiveOdds(self,eventid,type):
        '''��ȡĳ�������й�˾����������'''
        bettingtypeid=self.getBettingTypeid(type)
        sql='select * from '+self.getLiveOddsTableByEventId(eventid)+' where eventid=%s and bettingtypeid=%s'
        args=[eventid,bettingtypeid]
        return Db.Mysql.get('BetbrainSlave').query(sql,args)
    
    def deleteLiveOddsByEventid(self,eventid):
        sql='delete from '+self.getLiveOddsTableByEventId(eventid)+' where eventid=%s'
        args=[eventid]
#        return Db.Mysql.get('BetbrainMaster').execute(sql,args)
    
    def updateLiveOdds(self,row,id):
        sql='update '+self.getLiveOddsTableByEventId(row['eventid'])+' set odds_param1=%s,odds_param2=%s,odds_param3=%s'
        sql+=' where id=%s'
        args=[row['odds_param1'],row['odds_param2'],row['odds_param3'],id]
        return Db.Mysql.get('BetbrainMaster').execute(sql,args)
    
    def getLiveOddsTableByEventId(self,eventid):
        return 't_zq_live_odds_sec_%s'%(eventid%10)
    
    def getBettingTypeid(self,type):
        '''��ȡĳ�������й�˾����������'''
        if type=='euro':
            bettingtypeid=69
        elif type=='asian':
            bettingtypeid=48
        elif type=='big':
            bettingtypeid=47
        else:
            bettingtypeid=-1
        return bettingtypeid
    
    def addLiveOdds(self,type,row):
        '''��ȡĳ�������й�˾����������'''
        bettingtypeid=self.getBettingTypeid(type)
        sql='insert into '+self.getLiveOddsTableByEventId(row['eventid'])+'(eventid,providerid,bettingtypeid,odds_param1,odds_param2,odds_param3)values(%s,%s,%s,%s,%s,%s)'
        args=[row['eventid'],row['providerid'],bettingtypeid,row['odds_param1'],row['odds_param2'],row['odds_param3']]
        return Db.Mysql.get('BetbrainMaster').execute(sql,args)
    
    def add_odds(self,fixtureid,companyid,win,draw,lost,lastchangedtime):
        db=Db.Mysql.get('SoccerMaster')
        result=-1
        sql='set @odds_result=-1;call p_s_updateodds_europe_new(%s,%s,%s,%s,%s,%s,@odds_result)'
        args=[fixtureid,companyid,win,draw,lost,lastchangedtime]
        db.query(sql,args)
        sql='select @odds_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    def add_asian(self,fixtureid,companyid,sp,handicaplineid,xp,lastchangedtime):
        result=-1
        db=Db.Mysql.get('SoccerMaster')
        sql='set @asian_result=-1;call p_s_updateodds_asian_new(%s,%s,%s,%s,%s,%s,@asian_result)'
        args=[fixtureid,companyid,float(sp)-1,handicaplineid,float(xp)-1,lastchangedtime]
        db.query(sql,args)
        sql='select @asian_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    def add_bigsmall(self,fixtureid,companyid,big,name,small,lastchangedtime):
        result=-1
        db=Db.Mysql.get('SoccerMaster')
        sql='set @big_result=-1;call p_s_updateodds_big_new(%s,%s,%s,%s,%s,%s,@big_result)'
        args=[fixtureid,companyid,float(big)-1,name,float(small)-1,lastchangedtime]
        db.query(sql,args)
        sql='select @big_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    def add_secondary_asian(self,fixtureid,companyid,sp,handicaplineid,xp,lastchangedtime):
        sql='call p_s_updateodds_secondary_asian(%s,%s,%s,%s,%s,%s,@secondary_asian_result)'
        args=[fixtureid,companyid,float(sp)-1,handicaplineid,float(xp)-1,lastchangedtime]
        Db.Mysql.get('SoccerMaster').query(sql,args)
    
    def add_secondary_big(self,fixtureid,companyid,big,name,small,lastchangedtime):
        sql='call p_s_updateodds_secondary_big(%s,%s,%s,%s,%s,%s,@secondary_big_result)'
        args=[fixtureid,companyid,float(big)-1,name,float(small)-1,lastchangedtime]
        Db.Mysql.get('SoccerMaster').query(sql,args)
        
    def getHistoryEventList(self):
        '''��ȡ3��ǰ������'''
#        sql='select id from t_zq_event where typeid=1 and starttime<%s'
        sql='select id from t_zq_event where (typeid=1 and starttime<%s) or (typeid=2 and endtime<%s)'
        timestamp=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()-8*3600-36*3600))
        args=[timestamp,timestamp]
        return Db.Mysql.get('BetbrainSlave').query(sql,args)
    
    def deleteEventRelationInfo(self,eventid):
        '''ɾ��outcomeid��Ϣ'''
        db=Db.Mysql.get('BetbrainMaster')
        sql='delete from '+self.getOutcomeTableByEventid(eventid)+' where eventid=%s'
        args=[eventid]
        db.execute(sql,args)
        
        for i in [47,48,69]:
            sql='delete from '+self.getOddsChangeTable(eventid,i)+' where eventid=%s'
            args=[eventid]
            db.execute(sql,args)
        
        sql='delete from '+self.getLiveOddsTableByEventId(eventid)+' where eventid=%s'
        args=[eventid]
        db.execute(sql,args)
        
        #ɾ����������ӹ�����Ϣ
        sql='delete from t_zq_eventparticipantrelation where eventid=%s'
        args=[eventid]
        db.execute(sql,args)
        
        #ɾ��500wan�����¹�����
        sql='delete from t_zq_eventrelation_500wan where eventid=%s'
        args=[eventid]
        db.execute(sql,args)
        
        #ɾ��������Ϣ
        sql='delete from t_zq_event where id=%s'
        args=[eventid]
        db.query(sql,args)
    
    def saveEventRelation500wan(self,row):
        sql='replace into t_zq_eventrelation_500wan set eventid=%s,fixtureid=%s'
        args=[row['eventid'],row['fixtureid']]
        Db.Mysql.get('BetbrainMaster').query(sql,args)
    
    '''��ȡ�������籭��ŷ������(�ݹ����)'''
    def getSpecialEventInfo(self,eventid):
        sql='select id,DATE_ADD(starttime,INTERVAL 8 hour) as starttime,typeid  from t_zq_event where parentid in (%s) and ((typeid=2 and endtime>%s) or (typeid=1 and starttime>%s))'
        args=[eventid,time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()-8*3600)),time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()-8*3600))]
        list=Db.Mysql.get('BetbrainMaster').query(sql,args)
        result=[]
        for row in list:
            #������׶�
            if row['typeid']==2:
                result.extend(self.getSpecialEventInfo(row['id']))
            else:
                result.append({'id':row['id'],'starttime':row['starttime']})
        return result
    
    def get500MatchListBySeasonId(self,seasonid):
        '''��ȡ���¿�����'''
        sql='''select a.fixtureid,a.vsdate as matchdatetime,d.teamgbname as home,e.teamgbname as away,b.teamname_betbrain as betbrain_1,c.teamname_betbrain as betbrain_2
                from t_s_fixture as a 
                inner join t_s_teambyname as b on a.hometeamid=b.teamid
                inner join t_s_teambyname as c on a.awayteamid=c.teamid
                inner join t_s_team as d on a.hometeamid = d.teamid 
                inner join t_s_team as e on a.awayteamid = e.teamid
                where a.seasonid=%s and vsdate>%s'''
        args=[seasonid,time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())]
        return Db.Mysql.get('SoccerSlave').query(sql,args)
    
    def getProviderPipeiList(self):
        sql='select * from t_zq_provider where isenabled=1'
        return Db.Mysql.connect('BetbrainSlave').query(sql)
    
    def updateProviderPipeiInfo(self,id,row):
        field_arr=[]
        args=[]
        for key in row:
            field_arr.append(key+'=%s')
            args.append(row[key])
        sql='update t_zq_provider set '+(','.join(field_arr))+' where id=%s'
        args.append(id)
        Db.Mysql.connect('BetbrainMaster').execute(sql,args)