#coding:gbk
'''���������Ϣ'''
config={}

'''�߳�˯��ʱ��'''
config['thread_sleep_time']={
   'betbrain_parse':1,
   'betbrain_match':300,
   'betbrain_big':30,
   'betbrain_euro':30,
   'betbrain_asian':30,
   'betbrain_clear':3600,
   
   'betbrain_company':30
}
'''���xml������ҳ���·��'''
config['path']={ 
    'interface':'http://resources.boss.com/',
#    'upload_odds_xml':'interface/odds/update_uad_odds_xml.php?key=esun500wan&Fixtureid=%s&companyid=%s&peilv=%s&Typeid=%s',
    'update_live_xml':'interface/odds/updatelivexml.php?Fixtureid=%s&companyid=%s&peilv=%s&Typeid=%s', 
#    'update_asian_xml':'interface/odds/UpLoadAsianXml.php?Fixtureid=%s&companyid=%s&peilv=%s&CreateTime=%s',
    
    '500wan':'http://news.boss.com',
    '500wanxml_interface_url':'http://dist.boss.com/dist/distribute.php',
    'create_betbrain_day_txt_path':'/static/info/info_server/eas_betball/betbrain_day_%s.txt',
    'day_range':range(1,16),  
    'match_file_range':[-23, -22, -21, -20, -19, -18, -17, -16, -15, -14, -13, -12, -11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],    
    'redis_config':{
         'host':'localhost', 
         'port':6379,
    }
}