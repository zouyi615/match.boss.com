#coding:gbk
import os,re,time,traceback,random
import gzip
import Queue
import hashlib
from threading import Thread
import module.func.common as fc
from module.db.betbrain import Db_Betbrain
from module.func import post as Post
#�ļ����Ŀ¼
local_path='/data/betbrain/'
def readLocalGzFile(fname):
    handle = gzip.GzipFile(r'%s%s'%(local_path,fname))
    content=[]
    while True:
        line=handle.readline()
        if line:
            content.append(line)
        else:
            break
    handle.close()
    return ''.join(content)

def getNodeAttribute(node_str):
    row={}
    tmp=re.findall(r'([\w]+)="([^"]+)"',node_str)
    for r in tmp:
        row[r[0].encode('gbk')]=r[1].decode('utf-8').encode('gbk','ignore')
    return row

_instance=None
def getInstance():
    global _instance
    if not _instance:
        _instance=Db_Betbrain()
    return _instance

class Interface(Thread):
    def __init__(self,q):
        self.queue=q
        Thread.__init__(self)
                 
    def run(self):
        '''�߳�����'''
        while True:
            if self.queue.qsize()>0:
                try:
                    row=self.queue.get()
                    type=row['type']
                    data=row['data']
                    oddstype=row['oddstype']
                    if oddstype=='euro':
#                        if type=='odds':
#                            Post.upload_odds_xml(data)
#                        elif type=='live':
                        Post.upload_odds_xml(data,2)
                    else:
#                        if type=='odds':
#                            Post.upload_asian_xml_new(data)
#                        elif type=='live':
                        Post.upload_asian_xml(data,2)
                    row=data=None
                except:
                    fc.write_log('[betbrain:Interface]ִ����������쳣:%s[%s]'%(traceback.format_exc(),row))
            else:
                time.sleep(2)

post_queue=Queue.Queue(100)
post_th=[]
for i in range(0,10):
    p=Interface(post_queue)
    p.setDaemon(True)
    p.start()
    post_th.append(p)

#��������߳�
class combina_script(Thread):
    def __init__(self,t,q):
        self.queue=q
        self.t=t
        Thread.__init__(self)
    def run(self):
        while True:
            if self.queue.qsize()>0:
                try:
                    row=self.queue.get()
                    if self.t=='euro':
                        euro_combination(row)
                    elif self.t=='asian':
                        asian_combination(row)
                    elif self.t=='big':
                        big_combination(row)
                    del row
                except:
                    fc.write_log('[betbrain:Interface]ִ����������쳣:%s[%s]'%(traceback.format_exc(),row))
            else:
                time.sleep(2)

# Queue_List={}
# for type in ['euro','asian','big']:
#     Queue_List[type]=Queue.Queue(150)
#     for i in range(0,20):
#         th=combina_script(type,Queue_List[type])
#         th.setDaemon(True)
#         th.start()

def Sc_Interface(type,fixtureid):
    import EasClient
    import XmlConfig
    import os
    #�ϴ��ӿ�
    XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/service.xml')
    eas_instance = EasClient.EasClient().getInstance('odds_interface')
    if type=='euro':
        type_param='euro'
    elif type=='asian':
        type_param='asian'
    else:
        type_param='dxq'
    params={'type':type_param,'fid':str(fixtureid)}
    eas_instance.invoke('api/make',params)
    
'''����'''
class parse_script(Thread):
    def __init__(self,q):
        self.queue=q
        Thread.__init__(self)
         
    def run(self):
        '''�߳�����'''
        while True:
            if self.queue.qsize():
                try:
                    data=self.queue.get()
                    action_type=data['action']
                    row=data['data']
                    type=data['type']
                    #Outcome��ǩ����
                    if type=='Outcome': 
                        saveOutcomeInfo(action_type,row)
                                          
                    #Event����
                    elif type=='Event':
                        saveEventInfo(action_type,row)
                                         
                    #Eventparticipantrelation
                    elif type=='EventParticipantRelation':
                        saveEventParticipantRelationInfo(action_type,row)
                                                                           
                    #Participant�����Ϣ
                    elif type=='Participant':
                        saveParticipantInfo(action_type,row)
                                          
                    #��˾��Ϣ
                    elif type=='Provider':
                        saveProviderInfo(action_type,row)
                                                
                    #������Ϣ
                    elif type=='BettingOffer':
                        saveBettingOfferInfo(action_type,row)
                                                  
                    del data,row
                except:
                    fc.write_log('[betbrain:task]ִ����������쳣:%s[args:%s]'%(traceback.format_exc(),row))
            else:
                #���˯��ʱ��...��Χ��0-2��
                time.sleep(random.random()*2)
#�����߳�
script_queue=Queue.Queue(30000)
th=[]
for i in range(0,800):
    t=parse_script(script_queue)
    t.setDaemon(True)
    t.start()
    th.append(t)

def parse(type,node):
    if type=='Outcome':
        node=parseOutcomeInfo(node)
        
    elif type=='Event':
        node=parseEventInfo(node)
          
    elif type=='EventParticipantRelation':
        node=parseEventParticipantRelationInfo(node)
         
    elif type=='Participant':
        node=parseParticipantInfo(node)
    
    elif type=='Provider':
        node=parseProviderInfo(node)
    
    elif type=='BettingOffer':
        node=parseBettingOfferInfo(node)
        
    else:
        node=None
        
    if node:
        node['type']=type
        script_queue.put(node)

def parseOutcomeInfo(node):
    #����outcome����
    try:
        result={}
        row={}
        row['id']=int(node['id'])
        if node.has_key('typeId'):
            row['typeid']=int(node['typeId'])
        
        if node.has_key('isComplete'):
            if node['isComplete']=='true':
                iscomplete=1
            else:
                iscomplete=0
            row['iscomplete']=iscomplete
        
        if node.has_key('isNegation'):
            if node['isNegation']=='true':
                isnegation=1
            else:
                isnegation=0
            row['isnegation']=isnegation
        
        if node.has_key('statusId'):
            row['statusid']=int(node['statusId'])
        
        if node.has_key('eventId'):
            row['eventid']=int(node['eventId'])
        
        if node.has_key('eventPartId'):
            row['eventpartid']=int(node['eventPartId'])
        
        if node.has_key('paramParticipantId1'):
            row['paramparticipantid1']=int(node['paramParticipantId1'])
        
        if node.has_key('paramParticipantId2'):
            row['paramparticipantid2']=int(node['paramParticipantId2'])
        
        if node.has_key('paramParticipantId3'):
            row['paramparticipantid3']=int(node['paramParticipantId3'])
        
        if node.has_key('paramFloat1'):
            row['paramfloat1']='%.4f'%float(node['paramFloat1'])
        
        if node.has_key('paramFloat2'):
            row['paramfloat2']='%.4f'%float(node['paramFloat2'])
        
        if node.has_key('paramFloat3'):
            row['paramfloat3']='%.4f'%float(node['paramFloat3'])
        
        if node.has_key('paramBoolean1'):
            if node['paramBoolean1'].encode('gbk')=='true':
                paramboolean1=1
            else:
                paramboolean1=0
            row['paramboolean1']=paramboolean1
        
        if node.has_key('paramString1'):
            row['paramstring1']=node['paramString1']
        
        if node.has_key('paramEventPartId1'):
            row['parameventpartid1']=int(node['paramEventPartId1'])
                    
        #��ȡ��������
        if node.has_key('type'):
            action_type=node['type']
        else:
            action_type=None
            
        #����/�滻
        if not action_type or action_type=='create':
            tmp={'paramparticipantid1':0,'paramparticipantid2':0,'paramparticipantid3':0,'parameventpartid1':0,'paramfloat1':0,'paramfloat2':0,'paramfloat3':0,'paramboolean1':-1,'paramstring1':''} #ʡ�Էǿյ��ֶ�
            row=dict(tmp,**row)            
        result={'action':action_type,'data':row}
    except:
        fc.write_log('[betbrain:parseOutcomeInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id'])) 
    return result

def saveOutcomeInfo(action_type,row):
    #����outcome����
    try:
        if action_type=='create':
            #����
            getInstance().insertOutcomeInfo(row)
        elif action_type=='delete':
            #ɾ��
            getInstance().deleteOutcomeInfo(row['id'])
        
        elif action_type=='update':
            #����
            getInstance().updateOutcomeInfo(row)        
        elif action_type==None:
            #��ʼ������
            getInstance().saveOutcomeInfo(row)         
        else:
            fc.write_log('saveOutcomeInfo:id:%s---action_type:%s'%(row['id'],action_type)) 
    except:
        fc.write_log('[betbrain:saveOutcomeInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id']))    


def parseEventInfo(node):
    '''����������Ϣ'''
    try:
        result={}
        row={}
        row['id']=int(node['id'])
        if node.has_key('typeId'):     
            row['typeid']=int(node['typeId'])
            
        if node.has_key('isComplete'):
            if node['isComplete']=='true':
                iscomplete=1
            else:
                iscomplete=0
            row['iscomplete']=iscomplete      
        if node.has_key('sportId'):         
            row['sportid']=int(node['sportId'])
                       
        if node.has_key('templateId') and node['templateId']!='null':
            row['templateid']=int(node['templateId'])
                 
        if node.has_key('promotionId'):
            row['promotionid']=int(node['promotionId'])
        
        if node.has_key('parentId'):
            row['parentid']=int(node['parentId'])
        
        if node.has_key('parentPartId'):
            row['parentpartid']=int(node['parentPartId'])
        
        if node.has_key('name'):
            row['name']=node['name']
            
        if node.has_key('startTime'):
            row['starttime']=node['startTime'].split('.')[0]
        
        if node.has_key('endTime'):
            row['endtime']=node['endTime'].split('.')[0]
        
        if node.has_key('deleteTimeOffset'):
            row['deletetimeoffset']=int(node['deleteTimeOffset'])
        
        if node.has_key('venueId'):
            row['venueid']=int(node['venueId'])
        
        if node.has_key('statusId'):
            row['statusid']=int(node['statusId'])
        
        if node.has_key('rootPartId'):
            row['rootpartid']=int(node['rootPartId'])
        
        if node.has_key('currentPartId'):
            if node['currentPartId']=='null':
                row['currentpartid']=0
            else:
                row['currentpartid']=int(node['currentPartId'])
        
        if node.has_key('url'):
            row['url']=node['url']
        
        if node.has_key('popularity'):
            row['popularity']=int(node['popularity'])
        
        if node.has_key('note'):
            row['note']=node['note']
            
        #��ȡ��������
        if node.has_key('type'):
            action_type=node['type']
        else:
            action_type=None
        
        if not action_type or action_type=='create':
            #����
            tmp={'templateid':0,'promotionid':0,'parentid':0,'parentpartid':0,'name':None,'starttime':None,'endtime':None,'venueid':0,'currentpartid':0,'url':None,'popularity':0,'note':None} #ʡ�Էǿյ��ֶ�
            row=dict(tmp,**row)         
        result={'action':action_type,'data':row}
    except:
        fc.write_log('[betbrain:parseEventInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id']))
    return result

def saveEventInfo(action_type,row):
    '''����������Ϣ'''
    try:
        if action_type=='update':
            #����
            getInstance().updateEventInfo(row)
        elif action_type=='create':
            #����
            getInstance().insertEventInfo(row)
        elif action_type=='delete':
            #ɾ��
            getInstance().deleteEventInfo(row['id'])
            
            #ɾ��������������
            getInstance().deleteLiveOddsByEventid(row['id'])
        elif action_type==None:
            #��ʼ������
            getInstance().saveEventInfo(row)   
        else:
            fc.write_log('saveEventInfo:id:%s---action_type:%s'%(row['id'],action_type))
    except:
        fc.write_log('[betbrain:saveEventInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id']))
        
def parseEventParticipantRelationInfo(node):
    '''������������ӹ�������'''
    try:
        result={}
        row={}
        row['id']=int(node['id'])
        if node.has_key('eventId'):
            row['eventid']=int(node['eventId'])
        
        if node.has_key('eventPartId'):
            row['eventpartid']=int(node['eventPartId'])
        
        if node.has_key('participantId'):
            row['participantid']=int(node['participantId'])
        
        if node.has_key('participantRoleId'):
            row['participantroleid']=int(node['participantRoleId'])
            
        if node.has_key('parentParticipantId'):
            row['parentparticipantid']=int(node['parentParticipantId'])
        
        #��ȡ��������
        if node.has_key('type'):
            action_type=node['type']
        else:
            action_type=None
        
        if not action_type or action_type=='create':
            #����
            tmp={'parentparticipantid':0}
            row=dict(tmp,**row)
        result={'action':action_type,'data':row}
    except:
        fc.write_log('[betbrain:parseEventParticipantRelationInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id']))    
    return result

def saveEventParticipantRelationInfo(action_type,row):
    '''������������ӹ�������'''
    try:
        if action_type=='create':
            #����
            getInstance().insertEventParticipantRelationInfo(row)        
        elif action_type=='delete':
            #ɾ��
            getInstance().deleteEventParticipantRelationInfo(row['id'])        
        elif action_type=='update':
            #����
            getInstance().updateEventParticipantRelationInfo(row)           
        elif action_type==None:
            #��ʼ��
            getInstance().saveEventParticipantRelationInfo(row)            
        else:
            fc.write_log('saveEventParticipantRelationInfo:id:%s---action_type:%s'%(row['id'],action_type))
    except:
        fc.write_log('[betbrain:saveEventParticipantRelationInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id']))

def parseParticipantInfo(node):
    '''�����������Ϣ'''
    try:
        result={}
        row={}
        row['id']=int(node['id'])
        if node.has_key('typeId'):
            row['typeid']=int(node['typeId'])
                              
        if node.has_key('name'):
            row['name']=node['name'].strip()
        
        if node.has_key('firstName'):
            row['firstname']=node['firstName'].strip()
        
        if node.has_key('lastName'):
            row['lastname']=node['lastName'].strip()
        
        if node.has_key('isMale'):
            ismale_str=node['isMale']
            if ismale_str=='true':
                ismale=1
            elif ismale_str=='false':
                ismale=0
            else:
                ismale=-1
            row['ismale']=ismale
        
        if node.has_key('birthTime'):
            row['birthtime']=node['birthTime']
        
        if node.has_key('countryId'):
            row['countryid']=int(node['countryId'])
        
        if node.has_key('retirementTime'):
            row['retirementtime']=node['retirementtime']
        
        if node.has_key('note'):
            row['note']=node['note']
            
        #��ȡ��������
        if node.has_key('type'):
            action_type=node['type']
        else:
            action_type=None
        if not action_type or action_type=='create':
            #����
            tmp={'firstname':None,'lastname':None,'ismale':-1,'birthtime':None,'countryid':0,'retirementtime':None,'note':None} #ʡ�Էǿյ��ֶ�
            row=dict(tmp,**row)
        result={'action':action_type,'data':row}
    except:
        fc.write_log('[betbrain:parseParticipantInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id']))
    return result

def saveParticipantInfo(action_type,row):
    '''�����������Ϣ'''
    try:
        if action_type=='create':
            #����
            getInstance().insertParticipantInfo(row)
        
        elif action_type=='delete':
            #ɾ��
            getInstance().deleteParticipantInfo(row['id'])
        
        elif action_type=='update':
            #�޸�
            getInstance().updateParticipantInfo(row)
        
        elif action_type==None:
            #��ʼ������
            getInstance().saveParticipantInfo(row)
        else:
            fc.write_log('saveParticipantInfo:id:%s---action_type:%s'%(row['id'],action_type))
    except:
        fc.write_log('[betbrain:saveParticipantInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id']))

def parseProviderInfo(node):
    '''���ʹ�˾��Ϣ'''
    try:
        result={}
        row={}
        row['id']=int(node['id'])
        if node.has_key('name'):
            row['name']=node['name'].strip()
        
        if node.has_key('locationId'):
            row['locationid']=int(node['locationId'])        
        if node.has_key('url'):
            row['url']=node['url']
                 
        if node.has_key('isBookmaker'):
            if node['isBookmaker']=='true':
                isbookmaker=1
            else:
                isbookmaker=0
            row['isbookmaker']=isbookmaker
        
        if node.has_key('isBettingExchange'):
            if node['isBettingExchange']=='true':
                isbettingexchange=1
            else:
                isbettingexchange=0
            row['isbettingexchange']=isbettingexchange
        
        if node.has_key('bettingCommissionVACs'):
            row['bettingcommissionvacs']='%.4f'%float(node['bettingCommissionVACs'])
        
        if node.has_key('isNewsSource'):
            if node['isNewsSource']=='true':
                isnewssource=1
            else:
                isnewssource=0
            row['isnewssource']=isnewssource
        
        if node.has_key('isEnabled'):
            if node['isEnabled']=='true':
                isenabled=1
            else:
                isenabled=0
            row['isenabled']=isenabled
        
        if node.has_key('note'):
            row['note']=node['note']
        
        #��ȡ��������
        if node.has_key('type'):
            action_type=node['type']
        else:
            action_type=None
        if not action_type or action_type=='create':
            tmp={'url':None,'note':None} #ʡ�Էǿյ��ֶ�
            row=dict(tmp,**row)
        result={'action':action_type,'data':row}
    except:
        fc.write_log('[betbrain:parseProviderInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id']))
    return result

def saveProviderInfo(action_type,row):
    '''�������ʹ�˾��Ϣ'''
    try:
        if action_type=='create':
            #����
            getInstance().insertProviderInfo(row)        
        elif action_type==None:
            #��ʼ������
            getInstance().saveProviderInfo(row)
        elif action_type=='update':
            #�޸�
            getInstance().updateProviderInfo(row)
        else:
            fc.write_log('saveProviderInfo:id:%s---action_type:%s'%(row['id'],action_type))
    except:
        fc.write_log('[betbrain:saveProviderInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id']))

def parseBettingOfferInfo(node):
    '''������������'''
    try:
        result={}
        row={}
        row['id']=int(node['id'])        
        if node.has_key('providerId'):
            row['providerid']=int(node['providerId'])
            
        if node.has_key('sourceId'):
            row['sourceid']=int(node['sourceId'])
        
        if node.has_key('outcomeId'):
            row['outcomeid']=int(node['outcomeId'])
        
        if node.has_key('bettingTypeId'):
            row['bettingtypeid']=int(node['bettingTypeId'])
        
        if node.has_key('statusId'):
            row['statusid']=int(node['statusId'])
        
        if node.has_key('isLive'):
            if node['isLive']=='true':
                islive=1
            elif node['isLive']=='false':
                islive=0
            else:
                islive=-1
            row['islive']=islive
        
        if node.has_key('odds'):
            row['odds']='%.4f'%float(node['odds'])
        
        if node.has_key('multiplicity'):
            row['multiplicity']=int(node['multiplicity'])
        
        if node.has_key('couponKey'):
            row['couponkey']=node['couponKey']
        
        if node.has_key('slotNum'):
            row['slotnum']=int(node['slotNum'])
        
        if node.has_key('lastChangedTime'):
#            row['lastchangedtime']=node['lastChangedTime'].split('.')[0]
            time_tmp=node['lastChangedTime'].split('.')
            #ȡ����ʱ��(��ȷ����)
            row['lastchangedtime']=time_tmp[0]
            #ת����ʱ���(��ȷ������)
            hs=int(time_tmp[1])+int(time.mktime(time.strptime(time_tmp[0],'%Y-%m-%d %H:%M:%S')))*1000
            row['lastchangedtime_ms']=hs
        
        if node.has_key('volume'):
            row['volume']='%.4f'%float(node['volume'])
            
        if node.has_key('volumecurrencyid'):
            row['volumecurrencyid']=int(node['volumecurrencyid'])
               
        #��ȡ��������
        if node.has_key('type'):
            action_type=node['type']
        else:
            action_type=None
        
        if not action_type or action_type=='create':
            #��ʼ��/����
            tmp={'volume':None,'volumecurrencyid':None,'couponkey':None,'multiplicity':0}
            row=dict(tmp,**row)
                    
        result={'action':action_type,'data':row}
    except:
        fc.write_log('[betbrain:parseBettingOfferInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id']))
    return result

def saveBettingOfferInfo(action_type,row):
    '''������������'''
    try:
        if action_type=='create':
            getInstance().insertBettingOfferInfo(row)
        elif action_type=='update':
            #����
            getInstance().updateBettingOfferInfo(row)
        elif action_type=='delete':
            #ɾ��
            getInstance().deleteBettingOfferInfo(row['id'])
            
        elif action_type==None:
            #��ʼ��            
            getInstance().saveBettingOfferInfo(row)
        else:
            fc.write_log('saveBettingOfferInfo:id:%s---action_type:%s'%(row['id'],action_type))
    except:
        fc.write_log('[betbrain:saveBettingOfferInfo]�������ݳ����쳣:%s[id:%s]'%(traceback.format_exc(),row['id']))


def check_day_diff(time1,time2):
    '''������Դ����ʱ�������¿�Ա�,�ж�����Ƿ���һ��֮��'''
    flag=False
    if time1 and time2:
        timestamp_1=time.mktime(time.strptime(str(time1),'%Y-%m-%d %H:%M:%S'))
        timestamp_2=time.mktime(time.strptime(str(time2),'%Y-%m-%d %H:%M:%S'))
        if abs(timestamp_1-timestamp_2)/86400.0<1:
            flag=True
    return flag

def pipeiMatchList(type):
    try:
        '''ƥ������'''
        result=[]
        timestamp=time.time()+(type-1)*86400
        timestamp=time.mktime(time.strptime(time.strftime("%Y-%m-%d 00:00:00",time.localtime(timestamp)),"%Y-%m-%d %H:%M:%S"))
        #��ѯbetbrain������Ϣʱ����ת��Ϊ��������ʱ��
        begintime=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(timestamp-8*3600))
        endtime=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(timestamp+16*3600))
        list_source=Db_Betbrain().getEventInfo(begintime,endtime)
        
        #��ȡ���¿�Ķ�����Ϣ(ǰ�������һ��)
        begintime=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(timestamp-24*3600))
        endtime=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(timestamp+48*3600))
        tmp=Db_Betbrain().get500MatchList(begintime,endtime)
        list_500={}
        for row in tmp:
            key='h:%s-a:%s'%(row['betbrain_1'],row['betbrain_2'])
            index=hashlib.md5(key).hexdigest()
            #ע:���ܴ��������Ͷ���ͬ������
            if not list_500.has_key(index):
                list_500[index]=[]
            list_500[index].append(row)
        
        if list_500:
            for row in list_source:
                tmp=Db_Betbrain().getParticipantInfoByEventId(row['id'])
                home_tmp=None
                away_tmp=None
                for t in tmp:
                    if t['participantroleid']==1:
                        home_tmp=t
                    else:
                        away_tmp=t
                matchdate_source=row['starttime']
                
                if home_tmp and away_tmp:
                    match_list=[]
                    #����һ�µ����
                    #key
                    key='h:%s-a:%s'%(home_tmp['name'],away_tmp['name'])
                    #���ܺ������
                    index=hashlib.md5(key).hexdigest()
                    if list_500.has_key(index):
                        for r in list_500[index]:
                            match_list.append(r)
                            
                    #�����෴�����
                    #key
                    key='h:%s-a:%s'%(away_tmp['name'],home_tmp['name'])
                    #���ܺ������
                    index=hashlib.md5(key).hexdigest()
                    if list_500.has_key(index):
                        for r in list_500[index]:
                            match_list.append(r)
                    
                    for r in match_list:
                        home_500=r['betbrain_1']
                        away_500=r['betbrain_2']
                        matchdate_500=r['matchdatetime']
                        flag1=home_500==home_tmp['name'] and away_500==away_tmp['name']
                        flag2=home_500==away_tmp['name'] and away_500==home_tmp['name']
                        #�Ƚ�����Դ�����¿����ʱ����Χ
                        flag3=check_day_diff(matchdate_source,matchdate_500)
                        #�ɹ�ƥ��
                        if (flag1 or flag2) and flag3:
                            if flag1:
                                isreverse=0
                                home_source=home_tmp['name']
                                away_source=away_tmp['name']
                                homeid_source=home_tmp['participantid']
                                awayid_source=away_tmp['participantid']
                            else:
                                isreverse=1
                                home_source=away_tmp['name']
                                away_source=home_tmp['name']
                                homeid_source=away_tmp['participantid']
                                awayid_source=home_tmp['participantid']
                            Db_Betbrain().saveEventRelation500wan({'eventid':row['id'],'fixtureid':r['fixtureid']})
                            result.append({'fixtureid':r['fixtureid'],'home_500':r['home'],'away_500':r['away'],'home_source':home_source,'away_source':away_source,'homeid_source':homeid_source,'awayid_source':awayid_source,'matchid':row['id'],'matchdate':str(row['starttime']),'isreverse':isreverse,'matchdate_500':str(matchdate_500)})
                            break
        #����ƥ�䴦��
        if type==1:
            list_tmp={}
            for i in range(0,24):
                list_tmp[i]=[]
                
            for row in result:
#                 k=int(time.strftime('%H',time.strptime(changeGMTtoBjTime(row['matchdate']),'%Y-%m-%d %H:%M:%S')))
                k=int(time.strftime('%H',time.strptime(row['matchdate'],'%Y-%m-%d %H:%M:%S')))
                list_tmp[k].append(row)
                
            #����ƥ�䰴Сʱ����Ϊ24��С�ļ�                 
            for i in range(0,24):
                Post.post_betbrain_txt(list_tmp[i],i*-1)             
        
        Post.post_betbrain_txt(result,type)
    except:
        fc.write_log('[betbrain:pipeiMatchList]ƥ�����̳����쳣:%s[type:%s]'%(traceback.format_exc(),type))

def pipeiSpecialMatchList(type,seasonid_source,seasonid_500):
    try:
        result=[]
        #��ѯbetbrain������Ϣ
        list_source=Db_Betbrain().getSpecialEventInfo(seasonid_source)
                
        #��������id��ȡ������Ϣ
        tmp=Db_Betbrain().get500MatchListBySeasonId(seasonid_500)        
        list_500={}
        for row in tmp:
            key='h:%s-a:%s'%(row['betbrain_1'],row['betbrain_2'])
            index=hashlib.md5(key).hexdigest()
            #ע:���ܴ��������Ͷ���ͬ������
            if not list_500.has_key(index):
                list_500[index]=[]
            list_500[index].append(row)
        
        if list_500:
            for row in list_source:
                tmp=Db_Betbrain().getParticipantInfoByEventId(row['id'])
                home_tmp=None
                away_tmp=None
                for t in tmp:
                    if t['participantroleid']==1:
                        home_tmp=t
                    else:
                        away_tmp=t
                matchdate_source=row['starttime']
                
                if home_tmp and away_tmp:
                    match_list=[]
                    #����һ�µ����
                    #key
                    key='h:%s-a:%s'%(home_tmp['name'],away_tmp['name'])
                    #���ܺ������
                    index=hashlib.md5(key).hexdigest()
                    if list_500.has_key(index):
                        for r in list_500[index]:
                            match_list.append(r)
                            
                    #�����෴�����
                    #key
                    key='h:%s-a:%s'%(away_tmp['name'],home_tmp['name'])
                    #���ܺ������
                    index=hashlib.md5(key).hexdigest()
                    if list_500.has_key(index):
                        for r in list_500[index]:
                            match_list.append(r)
                    
                    for r in match_list:
                        home_500=r['betbrain_1']
                        away_500=r['betbrain_2']
                        matchdate_500=r['matchdatetime']
                        flag1=home_500==home_tmp['name'] and away_500==away_tmp['name']
                        flag2=home_500==away_tmp['name'] and away_500==home_tmp['name']
                        #�Ƚ�����Դ�����¿����ʱ����Χ
                        flag3=check_day_diff(matchdate_source,matchdate_500)
                        #�ɹ�ƥ��
                        if (flag1 or flag2) and flag3:
                            if flag1:
                                isreverse=0
                                home_source=home_tmp['name']
                                away_source=away_tmp['name']
                                homeid_source=home_tmp['participantid']
                                awayid_source=away_tmp['participantid']
                            else:
                                isreverse=1
                                home_source=away_tmp['name']
                                away_source=home_tmp['name']
                                homeid_source=away_tmp['participantid']
                                awayid_source=home_tmp['participantid']
                            Db_Betbrain().saveEventRelation500wan({'eventid':row['id'],'fixtureid':r['fixtureid']})
                            result.append({'fixtureid':r['fixtureid'],'home_500':r['home'],'away_500':r['away'],'home_source':home_source,'away_source':away_source,'homeid_source':homeid_source,'awayid_source':awayid_source,'matchid':row['id'],'matchdate':str(row['starttime']),'isreverse':isreverse,'matchdate_500':str(matchdate_500)})
                            break
        if result:
            Post.post_betbrain_txt(result,type)
    except:
        fc.write_log('[betbrain:pipeiSpecialMatchList]ƥ�����̳����쳣:%s[type:%s]'%(traceback.format_exc(),type)) 
        
def getMatchList(type):
    try:
        result=[]
        url=fc.getPath('create_betbrain_day_txt_path')%type
        url=fc.getPath('500wan')+url
        content=fc.fopen(url)
        if content:
            #ת��utf8��ʽ  ���⺺�����������
            list=re.compile(r'\[([^\[\]]+)\]').findall(content.decode('gbk').encode('utf-8'))
        else:
            list=[]
        for r in list:
            t=r.decode('utf-8').encode('gbk').split(',')
            result.append({
                'fixtureid':int(t[0]),
                'matchid':int(t[1]),
                'home_500':t[2],
                'away_500':t[3],
                'home_source':t[4],
                'away_source':t[5],
                'homeid_source':int(t[6]),
                'awayid_source':int(t[7]),
                'matchdate':t[8].strip('"'),
                'isreverse':int(t[9]),
                'matchdate_500':t[10].strip('"')
            })
    except:
        fc.write_log('[betbrain:getMatchList]��ȡ����ƥ�����ݳ����쳣:%s[url:%s]'%(traceback.format_exc(),url))
    return result

def euro_combination(row):
    #���ŷ������
    try:
        cp_info={}
        outcomeinfo={}
        fixtureid=row['fixtureid']
        odds_type='euro'
        ##��ȡ��������
        #����matchdate_500����,�������¿�ʼ������ʸ�������
#         odds_tmp=Db_Betbrain().getOddsInfoByEventId(odds_type,row['matchid'],changeBjtoGMTTime(row['matchdate_500']))
        
        odds_tmp=Db_Betbrain().getOddsListByEventid(odds_type,row['matchid'],changeBjtoGMTTime(row['matchdate_500']))
        if odds_tmp:
            #�����Ϻõ�����
            odds_info={}
            #����˾���飬�ٰ�����ʱ������ ע����������б�����ʱ��˳��,��Ϊ�ֵ��������
            odds_index={}
            
            for odds in odds_tmp:
                cid = odds['companyid']
                
                #500wan���¿⹫˾id
                cid_500 = odds['companyid_500']
#                 #���ݹ�˾���ӹ�˾��Ϣ����ȡ��Ϣ
#                 if not cp_info.has_key(cid):
#                     cp_info[cid]=Db_Betbrain().get500CompanyInfoByName(odds['companyname'])
                
#                 #�ж��Ƿ��ȡ�ù�˾����
#                 if cp_info[cid] and cp_info[cid]['source_betbrain']==1:
#                      #���ݿ��Ӧ��id
#                     cid_500=cp_info[cid]['id']
#                     #���ʸ���ʱ��
#                     key=str(odds['lastchangedtime']).replace(' ','').replace(':','').replace('-','')
#                     if not odds_info.has_key(cid):
#                         odds_info[cid]={}
#                         odds_index[cid]=[]
                #���ʸ���ʱ��
                key=str(odds['lastchangedtime']).replace(' ','').replace(':','').replace('-','')
                if not odds_info.has_key(cid):
                    odds_info[cid]={}
                    odds_index[cid]=[]
                    
                #�����ʰ���˾�����ʸ���ʱ�����;ע���ط�ָ��ͬһʱ���ж�����������
                if not odds_info[cid].has_key(key):
                    odds_index[cid].append(key)
                    odds_info[cid][key]={'lastchangedtime':changeGMTtoBjTime(odds['lastchangedtime']),'ids':[],'companyid':cid_500,'fixtureid':fixtureid}
                
                value='%.2f'%odds['odds']
                #ƽ
                if odds['outcometype']==11:
                    odds_info[cid][key]['draw']=value
                #ʤ
                elif odds['paramparticipantid1']==row['homeid_source']:
                    odds_info[cid][key]['win']=value
                #��
                else:
                    odds_info[cid][key]['lost']=value                    
                odds_info[cid][key]['ids'].append(str(odds['id']))
                            
            #�ж��Ƿ�����Ҫ��ϵ�����
            if len(odds_info):
                #���¿������Ƿ����仯
                is_update_flag=False
                #��ȡ��ǰ���¸���˾����������
                live_odds_tmp=Db_Betbrain().getLiveOdds(row['matchid'],'euro')
                live_odds={}
                for r in live_odds_tmp:
                    live_odds[r['providerid']]=r
            
                for c in odds_index:
                    if live_odds.has_key(c):
                        isexists=True
                        win=live_odds[c]['odds_param1']
                        draw=live_odds[c]['odds_param2']
                        lost=live_odds[c]['odds_param3']
                    else:
                        isexists=False
                        win=draw=lost=None                        
                    #2013-10-17�޸�:��ͬһʱ�䣨��ȷ���룩�����ݺϲ���һ��,����ʾ���µ�����
                    for k in odds_index[c]:
                        info=odds_info[c][k]
                        if info.has_key('win'):
                            win=info['win']
                        if info.has_key('draw'):
                            draw=info['draw']
                        if info.has_key('lost'):
                            lost=info['lost']
                        #��ŷ���3��ֵ��С��2ʱ,��Ϊ��Ч����,���й��˲���
                        if win and draw and lost and (float(win)>2 or float(draw)>2 or float(lost)>2):
                            if Db_Betbrain().add_odds(info['fixtureid'],info['companyid'],win,draw,lost,info['lastchangedtime'])==1:
                                is_update_flag=True
                                #�������ݵ��ӿ�
                                data={'fixtureid':info['fixtureid'],'companyid':info['companyid'],'win':win,'draw':draw,'lost':lost}
                                if checkEuroLiveCompanyidRange(info['companyid']):
                                    post_queue.put({'oddstype':'euro','data':data,'type':'live'})
                                                            
                        #������ϵ����ʱ�ʶ"�Ѹ���"״̬
                        Db_Betbrain().updateOddsInfoStatus(odds_type,row['matchid'],info['ids'])
                    if isexists:
                        Db_Betbrain().updateLiveOdds({'odds_param1':win,'odds_param2':draw,'odds_param3':lost,'eventid':row['matchid']},live_odds[c]['id'])
                    else:
                        Db_Betbrain().addLiveOdds('euro',{'odds_param1':win,'odds_param2':draw,'odds_param3':lost,'providerid':c,'eventid':row['matchid']})
                
                #�����������ɽӿ�
                if is_update_flag:
                    Sc_Interface('euro',fixtureid)
    except:
        fc.write_log('[betbrain:euro_combination]���ŷ�����ݳ����쳣:%s'%traceback.format_exc())

def euro_action(type):
    #����ŷ������
    list=getMatchList(type)
    for row in list:
        try:
#             if type in [1,2]:
#                 #��������������׵������д���
#                 Queue_List['euro'].put(row)
#             else:    
                #�������
                euro_combination(row)
        except:
            fc.write_log('[betbrain:euro_action]����ŷ�����ݳ����쳣:%s'%traceback.format_exc())

def asian_combination(row):
    '''�����������'''
    try:
        handicapline_info={}
        handi_tmp=Db_Betbrain().getAsianHandicapline()
        for r in handi_tmp:
            handicapline_info[float(r['handicapline'])]=r
        
        '''�����ж���̿�,����ͬ�̿ڵ�outcomeid��Ϊһ��'''
        #��ʱ���湫˾��Ϣ
        cp_info={}                
        fixtureid=row['fixtureid']
        odds_info={}
        odds_index={}
        odds_type='asian'
        ##��ȡ��������
#         odds_tmp=Db_Betbrain().getOddsInfoByEventId(odds_type,row['matchid'],changeBjtoGMTTime(row['matchdate_500']))
        odds_tmp=Db_Betbrain().getOddsListByEventid(odds_type,row['matchid'],changeBjtoGMTTime(row['matchdate_500']))
        if odds_tmp:            
            for odds in odds_tmp:
                outcomeid=odds['outcomeid']
                cid=odds['companyid']
#                 #���ݹ�˾���ӹ�˾��Ϣ����ȡ��Ϣ
#                 if not cp_info.has_key(cid):
#                     cp_info[cid]=Db_Betbrain().get500CompanyInfoByName(odds['companyname'])
                
                paramfloat1=odds['paramfloat1']
                if odds['paramparticipantid1']==row['homeid_source']:
                    issw1=1
                else:
                    issw1=0
                    #ע:0.0*-1=-0.0,�����ж�outcome['paramfloat1']�Ƿ�Ϊ0
                    if paramfloat1:
                        paramfloat1=paramfloat1*-1
                handi_str=str(paramfloat1)
                
#                 #�ж��Ƿ��ȡ�ù�˾����
#                 if cp_info[cid] and cp_info[cid]['source_betbrain_a']==1:
#                     #500���ݿ��Ӧ�Ĺ�˾��id
#                     cid_500=cp_info[cid]['id']
#                     
#                     #���ʸ���ʱ��
#                     key=str(odds['lastchangedtime']).replace(' ','').replace(':','').replace('-','')
#                     if not odds_info.has_key(cid):
#                         odds_info[cid]={}
#                         odds_index[cid]={}
#                         
#                     if not odds_info[cid].has_key(handi_str):
#                         odds_info[cid][handi_str]={}
#                         odds_index[cid][handi_str]=[]
#                         
#                     #�����ʰ���˾�����ʸ���ʱ�����;ע���ط�ָ��ͬһʱ���ж�����������
#                     if not odds_info[cid][handi_str].has_key(key):
#                         odds_info[cid][handi_str][key]={'lastchangedtime':changeGMTtoBjTime(odds['lastchangedtime']),'ids':[],'sw1':[],'sw2':[],'companyid':cid_500}
#                         odds_index[cid][handi_str].append(key)
#                         
#                     value='%.3f'%odds['odds']
#                     if issw1:
#                         odds_info[cid][handi_str][key]['sw1'].append(value)
#                     else:
#                         odds_info[cid][handi_str][key]['sw2'].append(value)
#                     odds_info[cid][handi_str][key]['ids'].append(str(odds['id']))

                #500���ݿ��Ӧ�Ĺ�˾��id
                cid_500=odds['companyid_500']
                
                #���ʸ���ʱ��
                key=str(odds['lastchangedtime']).replace(' ','').replace(':','').replace('-','')
                if not odds_info.has_key(cid):
                    odds_info[cid]={}
                    odds_index[cid]={}
                    
                if not odds_info[cid].has_key(handi_str):
                    odds_info[cid][handi_str]={}
                    odds_index[cid][handi_str]=[]
                    
                #�����ʰ���˾�����ʸ���ʱ�����;ע���ط�ָ��ͬһʱ���ж�����������
                if not odds_info[cid][handi_str].has_key(key):
                    odds_info[cid][handi_str][key]={'lastchangedtime':changeGMTtoBjTime(odds['lastchangedtime']),'ids':[],'sw1':[],'sw2':[],'companyid':cid_500}
                    odds_index[cid][handi_str].append(key)
                    
                value='%.3f'%odds['odds']
                if issw1:
                    odds_info[cid][handi_str][key]['sw1'].append(value)
                else:
                    odds_info[cid][handi_str][key]['sw2'].append(value)
                odds_info[cid][handi_str][key]['ids'].append(str(odds['id']))
            
            if len(odds_info):
                
                #��ȡ��ǰ���¸���˾����������
                live_odds_tmp=Db_Betbrain().getLiveOdds(row['matchid'],'asian')
                live_odds={}
                
                #��¼���ҹ�˾��ǰ��С��ˮλ��ֵ,��������ҹ�˾��ǰ����
                cp_min_sw_diff_tmp={}
                for r in live_odds_tmp:
                    if not live_odds.has_key(r['odds_param2']):
                        live_odds[r['odds_param2']]={}
                    live_odds[r['odds_param2']][r['providerid']]=r
                    
                    if r['odds_param1'] and r['odds_param3']:
                        diff_tmp=abs(r['odds_param1']-r['odds_param3'])
                        if not cp_min_sw_diff_tmp.has_key(r['providerid']) or cp_min_sw_diff_tmp[r['providerid']]>diff_tmp:
                            cp_min_sw_diff_tmp[r['providerid']]=diff_tmp
                        
                        
                #���¿������Ƿ����仯
                is_update_flag=False            
                for cid in odds_index:
                    #��ˮλ��ֵ������̿���Ϊ����
                    main_handi=main_sw1=main_sw2=max_lastchangedtime=diff_val=None
                
                    #��ȡ�ù�˾��ǰ��Сˮλ��
                    if cp_min_sw_diff_tmp.has_key(cid):
                        sw_diff_old_tmp=cp_min_sw_diff_tmp[cid]
                    else:
                        sw_diff_old_tmp=None
                                           
                    for handi_str in odds_index[cid]:
                        #��ȡ���һ�θ��¼�¼
                        handi=float(handi_str)
                        if live_odds.has_key(handi) and live_odds[handi].has_key(cid):
                            isexists=True
                            sw1=live_odds[handi][cid]['odds_param1']
                            sw2=live_odds[handi][cid]['odds_param3']
                        else:
                            isexists=False
                            sw1=sw2=None
                        #��ʱ������
                        odds_index[cid][handi_str].sort()
                        
                        for key in odds_index[cid][handi_str]:
                            info=odds_info[cid][handi_str][key]
                            lastchangedtime=info['lastchangedtime']
                            if info.has_key('sw1'):
                                sw1_tmp=info['sw1']
                            else:
                                sw1_tmp=[]
                            if info.has_key('sw2'):
                                sw2_tmp=info['sw2']
                            else:
                                sw2_tmp=[]
                            s1_l=len(sw1_tmp)
                            s2_l=len(sw2_tmp)
                            l=max(s1_l,s2_l)
                            
                            for i in range(0,l):
                                if i<s1_l:
                                    sw1=float(sw1_tmp[i])
                                if i<s2_l:
                                    sw2=float(sw2_tmp[i])
                                
                                #ɸѡ��Ч����
                                if sw1 and sw2 and sw1>1.1 and sw2>1.1 and (diff_val==None or abs(sw1-sw2)<diff_val):
                                    main_handi=handi
                                    main_sw1=sw1
                                    main_sw2=sw2
                                    diff_val=abs(sw1-sw2)
                                    main_lastchangedtime=lastchangedtime
                    
                            #������ϵ����ʱ�ʶ"�Ѹ���"״̬
                            Db_Betbrain().updateOddsInfoStatus(odds_type,row['matchid'],info['ids'])
                        
                        #ɸѡ��Ч����,��¼���̿�����
                        if sw1 and sw2 and sw1>1.1 and sw2>1.1:
                            Db_Betbrain().add_secondary_asian(fixtureid,info['companyid'],sw1,handicapline_info[handi]['handicaplineid'],sw2,lastchangedtime)
                        
                        if isexists:
                            Db_Betbrain().updateLiveOdds({'odds_param1':sw1,'odds_param2':handi,'odds_param3':sw2,'eventid':row['matchid']},live_odds[handi][cid]['id'])
                        else:
                            Db_Betbrain().addLiveOdds('asian',{'odds_param1':sw1,'odds_param2':handi,'odds_param3':sw2,'providerid':cid,'eventid':row['matchid']})                  
                    
                    if main_handi!=None and main_sw1!=None and main_sw2!=None:
                        diff_tmp=abs(main_sw1-main_sw2)
                        #��û���̿����ݻ�����Сˮλ��<��ǰ��Сˮλ�� �� ����Сˮλ��-��ǰ��Сˮλ��<0.2 ʱ,�����������Ϊ���̿ڸ�������
                        if sw_diff_old_tmp==None or diff_tmp<sw_diff_old_tmp or diff_tmp-sw_diff_old_tmp<0.2:
                            handicaplineid=handicapline_info[main_handi]['handicaplineid']
                            if Db_Betbrain().add_asian(fixtureid,info['companyid'],main_sw1,handicaplineid,main_sw2,main_lastchangedtime)==1:
                                is_update_flag=True
                                data={'fixtureid':fixtureid,'companyid':info['companyid'],'sw1':'%.3f'%(float(main_sw1)-1),'handicaplinename':handicapline_info[main_handi]['handicaplinename'],'sw2':'%.3f'%(float(main_sw2)-1)} 
                                if checkAsianLiveCompanyidRange(info['companyid']):
                                    post_queue.put({'oddstype':'asian','data':data,'type':'live'})
                #�����������ɽӿ�
                if is_update_flag:
                    Sc_Interface('asian',fixtureid)
    except:
        fc.write_log('[betbrain:asian_combination]����������ݳ����쳣:%s'%traceback.format_exc())
    
def asian_action(type):
    '''�����������'''
    #��ȡƥ������
    list=getMatchList(type)
    for row in list:
        try:
#             if type in [1,2]:
#                 #��������������׵������д���
#                 Queue_List['asian'].put(row)
#             else:    
                #�������
                asian_combination(row)
        except:
            fc.write_log('[betbrain:asian_action]�����������ݳ����쳣:%s'%traceback.format_exc())

def big_combination(row):
    '''��ϴ�С�ܷ�����'''
    try:
        #��Ź�˾��Ϣ
        cp_info={}           
        fixtureid=row['fixtureid']
        
        handicapline_info={}
        handi_tmp=Db_Betbrain().getBigHandicapline()
        for r in handi_tmp:
            handicapline_info[r['handivalue']]=r['handiname']
            
        #�����������
        odds_info={}    
        #����˾,�̿�,����ʱ������ ע����������б�����ʱ��˳��,��Ϊ�ֵ��������
        odds_index={}  
        odds_type='big'
        ##��ȡ��������
        #13:Total Score Over
        #14:Total Score Under
        #����ͬ�̿ڵ�outcome��Ϊһ������
#         odds_tmp=Db_Betbrain().getOddsInfoByEventId(odds_type,row['matchid'],changeBjtoGMTTime(row['matchdate_500']))
        odds_tmp=Db_Betbrain().getOddsListByEventid(odds_type,row['matchid'],changeBjtoGMTTime(row['matchdate_500']))
        if odds_tmp:
            for odds in odds_tmp:
                outcomeid=odds['outcomeid']
                cid=odds['companyid']
#                 #���ݹ�˾���ӹ�˾��Ϣ����ȡ��Ϣ
#                 if not cp_info.has_key(cid):
#                     cp_info[cid]=Db_Betbrain().get500CompanyInfoByName(odds['companyname'])
#                 
#                 #�ж��Ƿ��ȡ�ù�˾����
#                 if cp_info[cid] and cp_info[cid]['source_betbrain_a']==1:
#                     #500���ݿ��Ӧ�Ĺ�˾��id
#                     cid_500=cp_info[cid]['id']
#                     
#                     #�������ʸ���ʱ�����
#                     key=str(odds['lastchangedtime']).replace(' ','').replace(':','').replace('-','')
#                     if not odds_info.has_key(cid):
#                         odds_info[cid]={}
#                         odds_index[cid]={}
#                     
#                     handi_str=str(odds['paramfloat1'])
#                     
#                     if not odds_info[cid].has_key(handi_str):
#                         odds_info[cid][handi_str]={}
#                         odds_index[cid][handi_str]=[]
#                     
#                     #�����ʰ���˾�����ʸ���ʱ�����;ע���ط�ָ��ͬһʱ���ж�����������
#                     if not odds_info[cid][handi_str].has_key(key):
#                         odds_info[cid][handi_str][key]={'lastchangedtime':changeGMTtoBjTime(odds['lastchangedtime']),'ids':[],'big':[],'small':[],'companyid':cid_500}
#                         odds_index[cid][handi_str].append(key)
#                     
#                     value='%.2f'%odds['odds']
#                     
#                     if odds['outcometype']==13:
#                         odds_info[cid][handi_str][key]['big'].append(value)
#                     else:
#                         odds_info[cid][handi_str][key]['small'].append(value)
#                     odds_info[cid][handi_str][key]['ids'].append(str(odds['id']))
        
                #500���ݿ��Ӧ�Ĺ�˾��id
                cid_500 = odds['companyid_500']
                
                #�������ʸ���ʱ�����
                key=str(odds['lastchangedtime']).replace(' ','').replace(':','').replace('-','')
                if not odds_info.has_key(cid):
                    odds_info[cid]={}
                    odds_index[cid]={}
                
                handi_str=str(odds['paramfloat1'])
                
                if not odds_info[cid].has_key(handi_str):
                    odds_info[cid][handi_str]={}
                    odds_index[cid][handi_str]=[]
                
                #�����ʰ���˾�����ʸ���ʱ�����;ע���ط�ָ��ͬһʱ���ж�����������
                if not odds_info[cid][handi_str].has_key(key):
                    odds_info[cid][handi_str][key]={'lastchangedtime':changeGMTtoBjTime(odds['lastchangedtime']),'ids':[],'big':[],'small':[],'companyid':cid_500}
                    odds_index[cid][handi_str].append(key)
                
                value='%.2f'%odds['odds']
                
                if odds['outcometype']==13:
                    odds_info[cid][handi_str][key]['big'].append(value)
                else:
                    odds_info[cid][handi_str][key]['small'].append(value)
                odds_info[cid][handi_str][key]['ids'].append(str(odds['id']))
                
        if len(odds_info):    
            #��ȡ��ǰ���¸���˾����������
            live_odds_tmp=Db_Betbrain().getLiveOdds(row['matchid'],'big')
            live_odds={}
            #��¼���ҹ�˾��ǰ��С��ˮλ��ֵ
            cp_min_sw_diff_tmp={}
            for r in live_odds_tmp:
                if not live_odds.has_key(r['odds_param2']):
                    live_odds[r['odds_param2']]={}
                live_odds[r['odds_param2']][r['providerid']]=r
                
                if r['odds_param1'] and r['odds_param3']:
                    diff_tmp=abs(r['odds_param1']-r['odds_param3'])
                    if not cp_min_sw_diff_tmp.has_key(r['providerid']) or cp_min_sw_diff_tmp[r['providerid']]>diff_tmp:
                        cp_min_sw_diff_tmp[r['providerid']]=diff_tmp
                    
            #���¿������Ƿ����仯
            is_update_flag=False
            for cid in odds_index:
                #��ˮλ��ֵ������̿���Ϊ����
                main_handi=main_big=main_small=diff_val=main_lastchangedtime=None
                
                #��ȡ�ù�˾��ǰ��Сˮλ��
                if cp_min_sw_diff_tmp.has_key(cid):
                    sw_diff_old_tmp=cp_min_sw_diff_tmp[cid]
                else:
                    sw_diff_old_tmp=None    
                for handi_str in odds_index[cid]:
                     #��ȡ���һ�θ��¼�¼
                    handi=float(handi_str)
                    if live_odds.has_key(handi) and live_odds[handi].has_key(cid):
                        isexists=True
                        big=live_odds[handi][cid]['odds_param1']
                        small=live_odds[handi][cid]['odds_param3']
                    else:
                        isexists=False
                        big=small=None
                    
                    #��ʱ������
                    odds_index[cid][handi_str].sort()                    
                    for key in odds_index[cid][handi_str]:
                        info=odds_info[cid][handi_str][key]
                        lastchangedtime=info['lastchangedtime']
                        big_tmp=info['big']
                        small_tmp=info['small']
                        b_l=len(big_tmp)
                        s_l=len(small_tmp)
                        l=max(s_l,b_l)
                        
                        for i in range(0,l):
                            if i<b_l:
                                big=float(big_tmp[i])
                            if i<s_l:
                                small=float(small_tmp[i])
                            
                            #ɸѡ��Ч����
                            if big and small and big>1.1 and small>1.1 and (diff_val==None or abs(big-small)<diff_val):
                                main_handi=handi
                                main_big=big
                                main_small=small
                                main_lastchangedtime=lastchangedtime
                                diff_val=abs(big-small)                           
                            #������ϵ����ʱ�ʶ"�Ѹ���"״̬
                            Db_Betbrain().updateOddsInfoStatus(odds_type,row['matchid'],info['ids'])
                    
                    #ɸѡ��Ч����
                    if big and small and big>1.1 and small>1.1:
                        Db_Betbrain().add_secondary_big(fixtureid,info['companyid'],big,handicapline_info[handi],small,lastchangedtime)                
                    #��¼���µ���������
                    if isexists:
                        Db_Betbrain().updateLiveOdds({'odds_param1':big,'odds_param2':handi,'odds_param3':small,'eventid':row['matchid']},live_odds[handi][cid]['id'])
                    else:
                        Db_Betbrain().addLiveOdds('big',{'odds_param1':big,'odds_param2':handi,'odds_param3':small,'providerid':cid,'eventid':row['matchid']})
                    
                if main_big and main_small:
                    diff_tmp=abs(main_big-main_small)
                    #��û���̿����ݻ�����Сˮλ��<��ǰ��Сˮλ�� �� ����Сˮλ��-��ǰ��Сˮλ��<0.2 ʱ,�����������Ϊ���̿ڸ�������
                    if sw_diff_old_tmp==None or diff_tmp<sw_diff_old_tmp or diff_tmp-sw_diff_old_tmp<0.2:
                        addtime=main_lastchangedtime
                        handiname=handicapline_info[main_handi]
                        Db_Betbrain().add_bigsmall(fixtureid,info['companyid'],main_big,handiname,main_small,addtime)
                        is_update_flag=True
                        
            #�����������ɽӿ�
            if is_update_flag:
                Sc_Interface('big',fixtureid)
    except:
        fc.write_log('[betbrain:big_combination]��ϴ�С�ܷ����ݳ����쳣:%s'%traceback.format_exc())

def big_action(type):
    '''��ϴ�С�ܷ�����'''
    #��ȡƥ������
    list=getMatchList(type)
    for row in list:
        try:
#             if type in [1,2]:
#                 #��������������׵������д���
#                 Queue_List['big'].put(row)
#             else:    
                #�������
                big_combination(row)
        except:
            fc.write_log('[betbrain:big_action]������С�ܷ����ݳ����쳣:%s'%traceback.format_exc())
        
def changeGMTtoBjTime(datetime):
    '''����������ʱ��ת���ɱ���ʱ��'''
    timestamp=time.mktime(time.strptime(str(datetime),'%Y-%m-%d %H:%M:%S'))
    timestamp+=8*3600
    return time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(timestamp))


def changeBjtoGMTTime(datetime):
    '''������ʱ��ת���ɸ�������ʱ��'''
    timestamp=time.mktime(time.strptime(str(datetime),'%Y-%m-%d %H:%M:%S'))
    timestamp-=8*3600
    return time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(timestamp))

def checkEuroOddsCompanyidRange(companyid):
    if companyid in [2,3,4,5,6,7,8,9,10,11,15,18,280]:
        return True
    else:
        return False
    
def checkEuroLiveCompanyidRange(companyid):
    if companyid in [2,3,4,5,6,7,8,9,10,11,15,276,293]:
        return True
    else:
        return False

def checkAsianOddsCompanyidRange(companyid):
    if companyid in [2,3,5,6,9,16,277,280]:
        return True
    else:
        return False
        
def checkAsianLiveCompanyidRange(companyid):
    if companyid in [2,3,5,6,9,16,276,277,280]:
        return True
    else:
        return False