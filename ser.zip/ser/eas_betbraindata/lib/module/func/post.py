#coding:gbk
import time
import module.func.common as fc
'''ŷ�����ͽӿ�'''
def upload_odds_xml(row,type=1):
    if type==2:
        path=fc.getPath('interface')+fc.getPath('update_live_xml')
    else:
        path=fc.getPath('interface')+fc.getPath('upload_odds_xml')
    url=path%(row['fixtureid'],row['companyid'],'%s,%s,%s'%(row['win'],row['draw'],row['lost']),2)
    content=fc.fopen(url,type='[FUNC:upload_odds_xml]')
    if content.lower()!='ok':
        fc.write_log('[upload_odds_xml]����%s�ӿڲ���ʧ��!'%url)
        
'''�������ͽӿ�'''
def upload_asian_xml(row,type=1):
    if type==2:
        path=fc.getPath('interface')+fc.getPath('update_live_xml')
    else:
        path=fc.getPath('interface')+fc.getPath('upload_odds_xml')
    url=path%(row['fixtureid'],row['companyid'],'%s,%s,%s'%(row['sw1'],row['handicaplinename'],row['sw2']),1)
    content=fc.fopen(url,type='[FUNC:upload_asian_xml]')
    if content.lower()!='ok':
        fc.write_log('[upload_aisan_xml]����%s�ӿڲ���ʧ��!'%url)

'''����ball365.xml today.xml, future.xml�ļ�'''
def post_500wan_xml(path,content):
    flag=True
    url=fc.getPath('500wanxml_interface_url')
    content=fc.fopen(url,{'url':path,'content':content},'[POST:post_500wan_xml]')
    if content.lower()!='ok':
        flag=False
        fc.write_log('[post_500wan_xml]����%s�ӿ�����%s�ļ�ʧ��!'%(url,path))
    return flag

def post_betbrain_txt(data,type):
    try:
        flag=False
        url=fc.getPath('create_betbrain_day_txt_path')%type
        txt='{"updatetime":"%s","data":['%time.strftime("%Y-%m-%d %H:%M:%S")
        sp=''
        for k in data:
            t=k
            txt+=sp+'[%s,%s,"%s","%s","%s","%s",%s,%s,"%s",%s,"%s"]'%(t['fixtureid'],t['matchid'],t['home_500'],t['away_500'],t['home_source'],t['away_source'],t['homeid_source'],t['awayid_source'],t['matchdate'],t['isreverse'],t['matchdate_500'])
            sp=','
        txt+=']}'
        flag=post_500wan_xml(url,txt)
    except Exception,e:
        fc.write_log('[betbrain:post_gooooal_txt]���������쳣:%s!'%e)
    return flag