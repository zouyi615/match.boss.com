#coding:gbk
'''�����ʷ��������'''
from module.threads.base import base
from module.db.betbrain import Db_Betbrain
class betbrain_clear(base):
    def __init__(self):
        super(betbrain_clear,self).__init__('betbrain_clear')
    
    def do(self):
        list=Db_Betbrain().getHistoryEventList()
        for row in list:
            Db_Betbrain().deleteEventRelationInfo(row['id'])