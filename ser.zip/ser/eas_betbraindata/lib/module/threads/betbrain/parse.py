#coding:gbk
'''����������Ϣ'''
import re
import traceback,time
from module.threads.base import base
from module.db.betbrain import Db_Betbrain
from module.func import betbrain as Bet
class betbrain_parse(base):
    def __init__(self):
        super(betbrain_parse,self).__init__('betbrain_parse')
    
    def do(self):
        list=Db_Betbrain().getDownloadFile()
        for row in list:
            try:
                '''��ȡ�������ļ�'''
                a=time.time()
                '''��ȡ�ļ�����'''
                fname=row['fname']
                data=Bet.readLocalGzFile(fname)
                b=time.time()
                Db_Betbrain().updateFileStatus(-1,row['id'])
                flag=0
                count=0
                if data.find('<Outcome ')!=-1:
                    '''outcome�����¹�����Ϣ'''
                    node_arr=re.findall(r'<Outcome\s+[^>]+>',data)
                    for node in node_arr:
                        Bet.parse('Outcome',Bet.getNodeAttribute(node))
                    flag=1
                    count+=len(node_arr)
                    
                if data.find('<Event ')!=-1:
                    '''������Ϣ'''
                    node_arr=re.findall(r'<Event\s+[^>]+>',data)
                    for node in node_arr:
                        Bet.parse('Event',Bet.getNodeAttribute(node))
                    flag=2
                    count+=len(node_arr)
                      
                if data.find('<EventParticipantRelation ')!=-1:
                    '''����id����ӹ�����Ϣ'''
                    node_arr=re.findall(r'<EventParticipantRelation\s+[^>]+>',data)
                    for node in node_arr:
                        Bet.parse('EventParticipantRelation',Bet.getNodeAttribute(node))
                    flag=4
                    count+=len(node_arr)
                    
                if data.find('<Participant ')!=-1:
                    '''�����Ϣ'''
                    node_arr=re.findall(r'<Participant\s+[^>]+>',data)
                    for node in node_arr:
                        Bet.parse('Participant',Bet.getNodeAttribute(node))
                    flag=8
                    count+=len(node_arr)
                         
                if data.find('<Provider ')!=-1:
                    '''���ʹ�˾��Ϣ'''
                    node_arr=re.findall(r'<Provider\s+[^>]+>',data)
                    for node in node_arr:
                        Bet.parse('Provider',Bet.getNodeAttribute(node))
                    flag=16
                    count+=len(node_arr)
                    
                if data.find('<BettingOffer ')!=-1:
                    '''������Ϣ'''
                    node_arr=re.findall(r'<BettingOffer\s+[^>]+>',data)
                    for node in node_arr:
                        Bet.parse('BettingOffer',Bet.getNodeAttribute(node))
                    flag=32
                    count+=len(node_arr)
                c=time.time()
                if c-a>10:
                    self.writelog('��file:%s-parse:%s-database:%s-total:%s��'%(fname,b-a,c-b,c-a))
                Db_Betbrain().updateFileStatus(1,row['id'])
                if flag:
                    if fname.find('I_')!=-1:
                        if flag==32:
                            time.sleep(25)
                        else:
                            time.sleep(1)
                    else:
                        if count<5000:
                            time.sleep(10)
                        elif count<10000:
                            time.sleep(15)
                        elif count<15000:
                            time.sleep(20)
                        elif count<20000:
                            time.sleep(25)
                        else:
                            time.sleep(30)
                del data,row
            except:
                self.writelog('[thread:betbrain_parse]�̳߳����쳣:%s[filename:%s]'%(traceback.format_exc(),fname))