#coding:gbk
'''�����С��'''
from module.threads.base import base
from module.db.betbrain import Db_Betbrain
from module.func import betbrain as Bet
class betbrain_big(base):
    def __init__(self,type):
        super(betbrain_big,self).__init__('betbrain_big')
        self.type=type
        
    def do(self):
        Bet.big_action(self.type)