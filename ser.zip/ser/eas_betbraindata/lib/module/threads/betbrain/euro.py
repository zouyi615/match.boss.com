#coding:gbk
'''ŷ�����'''
from module.threads.base import base
from module.db.betbrain import Db_Betbrain
from module.func import betbrain as Bet
class betbrain_euro(base):
    def __init__(self,type):
        super(betbrain_euro,self).__init__('betbrain_euro')
        self.type=type
        
    def do(self):
        Bet.euro_action(self.type)