#coding:gbk
'''ƥ�乫˾����'''
from module.threads.base import base
from module.db.betbrain import Db_Betbrain
class betbrain_company(base):
    def __init__(self):
        super(betbrain_company,self).__init__('betbrain_company')
        
    def do(self):
        db=Db_Betbrain()
        list=db.getProviderPipeiList()
        for row in list:
            tmp=db.get500CompanyInfoByName(row['name'])
            if tmp:
                source_betbrain = 1 if tmp['source_betbrain']==1 else 0
                
                source_betbrain_a = 1 if tmp['source_betbrain_a']==1 else 0
                               
                if tmp['id']!=row['companyid_500'] or source_betbrain!=row['source_betbrain'] or source_betbrain_a!=row['source_betbrain_a']:
                    db.updateProviderPipeiInfo(row['id'],{'companyid_500':tmp['id'],'companyname_500':tmp['companyname'],'source_betbrain':source_betbrain,'source_betbrain_a':source_betbrain_a})
            
            else:
                if row['companyid_500'] or row['source_betbrain'] or row['source_betbrain_a']:
                    db.updateProviderPipeiInfo(row['id'],{'companyid_500':0,'companyname_500':None,'source_betbrain':0,'source_betbrain_a':0})