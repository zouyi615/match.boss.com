#coding:gbk
'''����������Ϣ'''
from module.threads.base import base
from module.db.betbrain import Db_Betbrain
from module.func import betbrain as Bet
class betbrain_match(base):
    def __init__(self,type):
        super(betbrain_match,self).__init__('betbrain_match')
        self.type=type
    def do(self):
        if self.type==16:
            #���籭
            Bet.pipeiSpecialMatchList(self.type,186674428,2918)
        elif self.type==17:
            #ŷ��
            Bet.pipeiSpecialMatchList(self.type,206730175,2793)
        else:
            Bet.pipeiMatchList(self.type)