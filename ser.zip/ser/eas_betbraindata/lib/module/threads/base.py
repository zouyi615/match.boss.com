#coding:gbk
'''�����̻߳���'''
from threading import Thread
import module.func.common as func
import time,traceback
class base(Thread):
    def __init__(self,thread_name):
        Thread.__init__(self)
        self.isRun=True
        self.thread_name=thread_name
        self.getSleepTime()
    
    '''�߳����в���'''
    def run(self):
        self.writelog('%s thread start'%self.thread_name)
        while self.isRun:
            try:
                self.do()
            except:
                self.writelog('[thread:%s]�̳߳����쳣:%s'%(self.thread_name,traceback.format_exc()))
            time.sleep(self.sleep_time)
            
    '''�߳�ֹͣ����'''
    def stop(self):
        self.writelog('%s thread stop'%self.thread_name)
        self.isRun=False
    
    '''��ȡ�߳�˯��ʱ��'''
    def getSleepTime(self):
        self.sleep_time=func.getThreadSleep(self.thread_name)
    
    '''д��־����'''
    def writelog(self,msg):
        func.write_log(msg)
    
    '''��ȡ·��������Ϣ'''    
    def getConfigPath(self,key):
        return func.getPath(key)
    
    '''��ҳ��'''
    def fopen(self,path,data={}):
        return func.fopen(path,data,'[threads:%s]'%self.thread_name)
    
    '''����xml'''
    def parsexml(self,string):
        return func.parseString(string)