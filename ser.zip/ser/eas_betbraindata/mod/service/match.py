#coding:gbk
import EasClient
import Eas.Extend
import Eas.Function
import time
import module.func.common as func
from module.threads.betbrain.match import betbrain_match
class match(Eas.Extend.Common): 
    def __init__(self):
        self.thread_status={'betbrain_match':'0'}
        self.threads={}
        for key in self.thread_status:
            time.sleep(3) #����������ʱ��
            self.start(key)
    
    '''����'''       
    def start(self,key):
        if self.thread_status.has_key(key) and self.thread_status[key]=='0':
            if key=='betbrain_match':
                self.threads[key]=[]
                for i in func.getPath('day_range'):
                    p=betbrain_match(i)
                    p.setDaemon(True)
                    p.start()
                    self.threads[key].append(p)
                self.thread_status[key]='1'
        return self._result({},[])  
    
    '''ֹͣ'''  
    def stop(self,key):
        if self.thread_status.has_key(key) and self.thread_status[key]=='1':
            if key=='betbrain_match':
                for th in self.threads[key]:
                    th.stop()
                self.thread_status[key]='0'
        return self._result({},[])
    
    '''����״̬'''
    def setstatus(self,type,statusid):
        if statusid=='1':
            self.start(type)
        else:
            self.stop(type)
        return self._result({},[])
    
    '''��ȡ״̬'''
    def getstatus(self,type):
        if self.thread_status.has_key(type):
            return self._result({'status':self.thread_status[type]},[])
        else:
            return self._result({'status':0},[])
    
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''    
    p =match()
    return Eas.Function.get_method_dict(p,prefix+'/')