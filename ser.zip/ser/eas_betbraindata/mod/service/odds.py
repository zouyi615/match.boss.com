#coding:gbk
import EasClient
import Eas.Extend
import Eas.Function
import JsonUtil
#import other.mm as mm
import time
import module.func.common as func
from module.threads.betbrain.parse import betbrain_parse
from module.threads.betbrain.asian import betbrain_asian
from module.threads.betbrain.euro import betbrain_euro
from module.threads.betbrain.big import betbrain_big
from module.threads.betbrain.clear import betbrain_clear
from module.threads.betbrain.company import betbrain_company
'''�������'''
class odds(Eas.Extend.Common):
    def __init__(self):
        self.threads={}
        self.thread_status={}
        self.init_betbrain()
        for key in self.threads:
            time.sleep(1)
            self.thread_status[key]='1'
            self.threads[key].setDaemon(True)
            self.threads[key].start()
        
    def init_betbrain(self):
        self.threads['betbrain_parse']=betbrain_parse()
        self.threads['betbrain_clear']=betbrain_clear()
        self.threads['betbrain_company']=betbrain_company()
        for i in func.getPath('match_file_range'):
            self.threads['betbrain_euro_%s'%i]=betbrain_euro(i)
            self.threads['betbrain_asian_%s'%i]=betbrain_asian(i)
            self.threads['betbrain_big_%s'%i]=betbrain_big(i)
        
#    #����״̬    
#    def setstatus(self,params):
#        if params:
#            tmp=JsonUtil.read(params)
#            for key in tmp:
#                if tmp[key]:
#                    self.start(key)
#                else:
#                    self.stop(key)
#        return self._result({},[])
#    
#    #��ȡ״̬
#    def getstatus(self):
#        return self._result({},[mm.read(self.thread_status)])
        
    def start(self,key):
        if self.thread_status.has_key(key) and self.thread_status[key]=='0':
            self.threads[key]=globals()[key]()
            self.threads[key].setDaemon(True)
            self.threads[key].start()
            self.thread_status[key]='1'
    def stop(self,key):
        if self.thread_status.has_key(key) and self.thread_status[key]=='1':
            self.threads[key].stop()
            self.threads[key]=None
            self.thread_status[key]='0'
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''    
    p =odds()
    return Eas.Function.get_method_dict(p,prefix+'/')