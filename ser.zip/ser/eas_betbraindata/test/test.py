#coding=gbk
import sys, os
import time
#import json
import threading
import logging
import traceback
import signal

if not os.environ.has_key('_BASIC_PATH_'):
    _BASIC_PATH_ = os.path.abspath(__file__)
    _BASIC_PATH_ = _BASIC_PATH_[:_BASIC_PATH_.rfind('/test/')]
    os.environ['_BASIC_PATH_'] = _BASIC_PATH_
if sys.path.count(os.environ['_BASIC_PATH_'] + '/lib') == 0:
    sys.path.append(os.environ['_BASIC_PATH_'] + '/mod')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib/common')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs/pypi')

import XmlConfig
XmlConfig.setEncoding('gbk')
XmlConfig.loadFile(_BASIC_PATH_ + '/etc/service.xml')
XmlConfig.loadFile(_BASIC_PATH_ + '/etc/config.xml')
XmlConfig.loadFile(_BASIC_PATH_ + '/etc/db.xml')


#_APP_ID_ = sys.argv[1]
#print _BASIC_PATH_

import Ice
Ice.loadSlice(_BASIC_PATH_+'/etc/EAS.ice')


import gzip


import EasClient
import JsonUtil,XmlUtil,urllib2,urllib
import re
import Db.Mysql
from module.threads.betbrain.match import betbrain_match
from module.threads.betbrain.asian import betbrain_asian
from module.threads.betbrain.euro import betbrain_euro
from module.threads.betbrain.big import betbrain_big
if __name__ == '__main__':
    betbrain_match(1).do()