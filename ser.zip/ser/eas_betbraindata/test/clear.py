#coding=gbk
import sys, os
import time
import json
import logging
import traceback
import signal

if not os.environ.has_key('_BASIC_PATH_'):
    _BASIC_PATH_ = os.path.abspath(__file__)
    _BASIC_PATH_ = _BASIC_PATH_[:_BASIC_PATH_.rfind('/test/')]
    os.environ['_BASIC_PATH_'] = _BASIC_PATH_
if sys.path.count(os.environ['_BASIC_PATH_'] + '/lib') == 0:
    sys.path.append(os.environ['_BASIC_PATH_'] + '/mod')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib/common')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs/pypi')


import XmlConfig
XmlConfig.setEncoding('gbk')
XmlConfig.loadFile(_BASIC_PATH_ + '/etc/service.xml')
XmlConfig.loadFile(_BASIC_PATH_ + '/etc/config.xml')
XmlConfig.loadFile(_BASIC_PATH_ + '/etc/db.xml')

import Ice
Ice.loadSlice(_BASIC_PATH_+'/etc/EAS.ice')

if __name__ == '__main__':
    import Db.Mysql
    
    table_config=[
        't_zq_event',
        't_zq_eventparticipantrelation',
        't_zq_outcome',
        't_zq_participant',
        't_zq_provider',
        't_zq_live_odds',
        't_zq_bettingoffer_live_bak',
        't_zq_odds_change_bak',
        't_zq_bettingoffer',
        't_zq_eventrelation_500wan',
        
        't_zq_downloadfile',
        't_zq_downloadfile_bak'
    ]
    for i in range(0,100):
        table_config.append('t_zq_bettingoffer_live_%s'%i)
        table_config.append('t_zq_odds_change_%s'%i)
        
    db=Db.Mysql.get('BetbrainMaster')
    for table in table_config:
        db.execute('TRUNCATE TABLE %s'%table)