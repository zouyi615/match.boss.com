#coding=utf-8
import logging
DE_LOCALS = {}
LOCAL_V = locals()
def dede():
    ''' 对该py文件中的 变量 反向查找 解码 '''
    global DE_LOCALS
    for i in LOCAL_V.items():
        if type(i[1]) == str or type(i[1]) == int:
            DE_LOCALS[i[1]] = str(i[0])
            DE_LOCALS[str(i[0])] = str(i[1])
def getde(key):
    ''' 获取value对应的key'''
    return DE_LOCALS.get(key, key)

def read( obj ):
    if type(obj) == dict:
        result = dict()
        for k, v in obj.items():            
            v = read(v)
            result[ getde(k) ] = v

    elif type(obj) == list:
        result = list()
        for v in obj:
            v = read( v )
            result.append(v)

    elif type(obj) == tuple:
        result = list()        
        for v in obj:
            v = read( v )
            result.append(v)
    else:
        result = str(obj)
    return result

dede()




