#coding:gbk
import Db.Mysql
class Db_Odds:
    def __init__(self):
        pass
    def getballbycompany(self,companyname):
        sql="select id,source_ball365,source_ball365_a,source_ball365_oth,istosohu from t_odds_company where ball365=%s limit 1"
        args=[companyname]
        return Db.Mysql.get('SoccerSlave').queryOne(sql,args)
    def getcompanybybet(self,companyname):
        sql="select id,source_bet007,istosohu from t_odds_company where bet007=%s LIMIT 1"
        args=[companyname]
        return Db.Mysql.get('SoccerSlave').queryOne(sql,args)
    
    def add_odds(self,fixtureid,companyid,win,draw,lost):
        db=Db.Mysql.get('SoccerMaster')
        result=-1
        sql='set @odds_result=-1;call p_s_updateodds_europe(%s,%s,%s,%s,%s,@odds_result)'
        args=[fixtureid,companyid,win,draw,lost]
        db.query(sql,args)
        sql='select @odds_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    def gethandicaplineid(self,handicaplinename):
        sql='SELECT handicaplineid FROM t_s_odds_handicapline where handicaplinename=%s LIMIT 1'
        args=[handicaplinename]
        ret=Db.Mysql.get('SoccerSlave').queryOne(sql,args)
        if ret:
            return ret['handicaplineid']
        else:
            return 0
    def add_asian(self,fixtureid,companyid,sp,handicaplineid,xp):
        result=-1
        db=Db.Mysql.get('SoccerMaster')
        sql='set @asian_result=-1;call p_s_updateodds_asian(%s,%s,%s,%s,%s,@asian_result)'
        args=[fixtureid,companyid,sp,handicaplineid,xp]
        db.query(sql,args)
        sql='select @asian_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        
        #���̿ڴ���
        self.add_secondary_asian(fixtureid,companyid,sp,handicaplineid,xp)
        return result
    
    def add_secondary_asian(self,fixtureid,companyid,sp,handicaplineid,xp,lastchangedtime=None):
        result=-1
        db=Db.Mysql.get('SoccerMaster')
        sql='set @secondary_asian_result=-1;call p_s_updateodds_secondary_asian(%s,%s,%s,%s,%s,%s,@secondary_asian_result)'
        args=[fixtureid,companyid,sp,handicaplineid,xp,lastchangedtime]
        db.query(sql,args)
        sql='select @secondary_asian_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    def add_bigsmall(self,fixtureid,companyid,big,name,small):
        result=-1
        db=Db.Mysql.get('SoccerMaster')
        sql='set @big_result=-1;call p_s_updateodds_big(%s,%s,%s,%s,%s,@big_result)'
        args=[fixtureid,companyid,big,name,small]
        db.query(sql,args)
        sql='select @big_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
            
        #���̿ڴ���
        self.add_secondary_bigsmall(fixtureid, companyid, big, name, small);        
        return result
    
    def add_secondary_bigsmall(self,fixtureid,companyid,big,name,small,lastchangedtime=None):
        result=-1
        db=Db.Mysql.get('SoccerMaster')
        sql='set @secondary_big_result=-1;call p_s_updateodds_secondary_big(%s,%s,%s,%s,%s,%s,@secondary_big_result)'
        args=[fixtureid,companyid,big,name,small,lastchangedtime]
        db.query(sql,args)
        sql='select @secondary_big_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    '''���ӵ�˫������Ϣ'''
    def add_ds(self,fixtureid,companyid,d,s):
        result=-1
        sql='set @ds_result=-1;call p_s_updateodds_dss(%s,%s,%s,%s,@ds_result)'
        args=[fixtureid,companyid,d,s]
        Db.Mysql.get('SoccerMaster').query(sql,args)
        sql='select @ds_result as rs'
        ret=Db.Mysql.get('SoccerMaster').queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    '''��������Ϣ'''
    def add_jqs(self,fixtureid,companyid,b01,b23,b46,b7):
        result=-1
        db=Db.Mysql.get('SoccerMaster')
        sql='set @jqs_result=-1;call p_s_updateodds_jqs(%s,%s,%s,%s,%s,%s,@jqs_result)'
        args=[fixtureid,companyid,b01,b23,b46,b7]
        db.query(sql,args)
        sql='select @jqs_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    '''���Ӳ�����Ϣ'''
    def add_bd(self,fixtureid,companyid,a10,b10,a20,b20,a21,b21,a30,b30,a31,b31,a32,b32,a40,b40,a41,b41,a42,b42,a43,b43,c00,c11,c22,c33,c44,a5,b5):
        result=-1
        sql='set @bd_result=-1;call p_s_updateodds_bd(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,@bd_result)'
        args=[fixtureid,companyid,a10,b10,a20,b20,a21,b21,a30,b30,a31,b31,a32,b32,a40,b40,a41,b41,a42,b42,a43,b43,c00,c11,c22,c33,c44,a5,b5]
        Db.Mysql.get('SoccerMaster').query(sql,args)
        sql='select @bd_result as rs'
        ret=Db.Mysql.get('SoccerMaster').queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    '''���Ӱ�ȫ����Ϣ'''
    def add_bqc(self,fixtureid,companyid,aa,ac,ab,ca,cc,cb,ba,bc,bb):
        result=-1
        sql='set @bqc_result=-1;call p_s_updateodds_bqc(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,@bqc_result)'
        args=[fixtureid,companyid,aa,ac,ab,ca,cc,cb,ba,bc,bb]
        Db.Mysql.get('SoccerMaster').query(sql,args)
        sql='select @bqc_result as rs'
        ret=Db.Mysql.get('SoccerMaster').queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    '''������ӽ�����'''
    def add_teamjqs(self,fixtureid,companyid,a0,a1,a2,a3,a4,a5,b0,b1,b2,b3,b4,b5):
        result=-1
        db=Db.Mysql.get('SoccerMaster')
        sql='set @teamjqs_result=-1;call p_s_updateodds_teamjqs(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,@teamjqs_result)'
        args=[fixtureid,companyid,a0,a1,a2,a3,a4,a5,b0,b1,b2,b3,b4,b5]
        db.query(sql,args)
        sql='select @teamjqs_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    '''��ȡ���̹�˾��Ϣ'''
    def getAsianInfoByCompany(self,companyname):
        sql="select id,source_bet007,source_bet007_a,istosohu from t_odds_company where bet007_asian=%s limit 1"
        args=[companyname]
        return Db.Mysql.get('SoccerSlave').queryOne(sql,args)
    
    '''��ȡbetexplore��˾��Ϣ'''
    def getbetexpbycompany(self,companyname):
        sql='select id,source_betexplorer,istosohu from t_odds_company where betexplorer=%s limit 1'
        args=[companyname]
        return Db.Mysql.get('SoccerSlave').queryOne(sql,args)
    
    def getballfixture(self,begintime,endtime):
        sql="select a.fixtureid,a.ball365_1,a.ball365_2,a.home,a.away,a.vsdate as matchdatetime,a.ball365_eur_1,a.ball365_eur_2,a.islottyle,a.isbeidan,b.sourcelimit,b.sourceoddslimit from v_getfixturepipei as a left join t_s_fixture_ext as b on a.fixtureid=b.fixtureid where a.vsdate>=%s and a.matchdate<%s"
        args=[begintime,endtime]
        return Db.Mysql.get('SoccerSlave').query(sql,args)
    
    def getfixture(self,begintime,endtime):
        sql="select a.fixtureid,a.bet007_1,a.bet007_2,a.bet007_e1,a.bet007_e2,a.vsdate as matchdatetime,a.home,a.away,a.islottyle,a.isbeidan,b.sourcelimit,b.sourceoddslimit from v_getfixturepipei as a left join t_s_fixture_ext as b on a.fixtureid=b.fixtureid where a.vsdate between %s and %s order by a.vsdate"
        args=[begintime,endtime]
        return Db.Mysql.get('SoccerSlave').query(sql,args)
    def getbetexplorefixture(self,begintime,endtime):
        sql="select a.fixtureid,a.home,a.bexplorer_1,a.away,a.bexplorer_2,concat(a.matchdate,' ',a.matchtime) as matchdatetime,a.bexplorercs_1,a.bexplorercs_2,a.islottyle,b.ismain,a.isbeidan from v_getfixturepipei as a inner join t_s_match as b on a.matchid=b.matchid where a.vsdate>=%s and a.vsdate<=%s order by a.vsdate"
        args=[begintime,endtime]
        return Db.Mysql.get('SoccerSlave').query(sql,args)
    
    '''��ȡ������Ϣ'''
    def getLqMatch(self,homename,awayname,matchtime):
        sql="select FixtureID,VSDate,HomeGBName,AwayGBName,HomeID,AwayID,HomeName_AM,AwayName_AM from v_b_fixturemate where ((HomeName_AM=%s and AwayName_AM=%s) or (HomeName_AM=%s and AwayName_AM=%s)) and statusid = 1 and datediff(%s,VSDate) between -1 and 1 limit 1"
        args=[homename,awayname,awayname,homename,matchtime]
        return Db.Mysql.get('MatchSlave').queryOne(sql,args)
    '''��ȡ������Ϣ'''
    def getZqMatch(self,homename,awayname,matchtime):
        sql='select fixtureid,vsdate,home,away,hometeamid,awayteamid,gbk_1,gbk_2,islottyle,isbeidan from v_getfixturepipei where ((gbk_1=%s and gbk_2=%s) or (gbk_1=%s and gbk_2=%s)) and datediff(%s,VSDate) between -1 and 1 limit 1'
        args=[homename,awayname,awayname,homename,matchtime]
        return Db.Mysql.get('SoccerSlave').queryOne(sql,args)
    '''����tv��Ϣ'''
    def addAomenTv(self,fixtureid,tv):
        db=Db.Mysql.get('SoccerMaster')
        sql='select fixtureid from t_s_fixture_ext where fixtureid=%s'
        args=[fixtureid]
        ret=db.queryOne(sql,args)
        if not ret:
            sql='insert into t_s_fixture_ext(fixtureid,tv)values(%s,%s)'
            args=[fixtureid,tv]
            db.insert(sql,args)
        else:
            sql='update t_s_fixture_ext set tv=%s where fixtureid=%s'
            args=[tv,fixtureid]
            db.execute(sql,args)
    
    '''������ˮ��Ϣ'''
    def addNews(self,fixtureid,classid,title,content,keywords=None,relatekey=None,type=1):
        db=Db.Mysql.get('SoccerMaster')
        sql="select id,title,content from t_news_news where fixtureid=%s and classid=%s"
        args=[fixtureid,classid]
        ret=db.queryOne(sql,args)
        if not ret:
            if type==2:
                sql="insert into t_news_news(classid,title,content,keywords,relate_key,fixtureid)values(%s,%s,%s,%s,%s,%s)"
                args=[classid,title,content,keywords,relatekey,fixtureid]
            else:
                sql="insert into t_news_news(classid,title,content,fixtureid)values(%s,%s,%s,%s)"
                args=[classid,title,content,fixtureid]
            db.insert(sql,args)
        else:
            if type==2:
                sql='update t_news_news set title=%s,content=%s,keywords=%s,relate_key=%s where id=%s'
                args=[title,content,keywords,relatekey,ret['id']]
            else:
                sql="update t_news_news set title=%s,content=%s where id=%s"
                args=[title,content,ret['id']]
            db.execute(sql,args)
            
    '''���Ӱ볡ŷ��'''
    def add_halfodds(self,fixtureid,companyid,win,draw,lost):
        db=Db.Mysql.get('SoccerMaster')
        result=-1
        sql='set @halfodds_result=-1;call p_s_updateodds_europe_half(%s,%s,%s,%s,%s,@halfodds_result)'
        args=[fixtureid,companyid,win,draw,lost]
        db.query(sql,args)
        sql='select @halfodds_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    '''��ȡgooooal����'''
    def getgooooalfixture(self,begintime,endtime):
        sql="select a.fixtureid,a.home,a.away,a.vsdate as matchdatetime,a.gooooal_1,a.gooooal_2,a.islottyle,a.isbeidan,b.sourcelimit,b.sourceoddslimit from v_getfixturepipei as a left join t_s_fixture_ext as b on a.fixtureid=b.fixtureid where a.vsdate between %s and %s"
        args=[begintime,endtime]
        return Db.Mysql.get('SoccerSlave').query(sql,args)
    
        '''��ȡ��˾gooooal��Ϣ'''
    def getGooooalInfoByCompany(self,companyname):
        sql="select id,source_gooooal_a,source_gooooal,istosohu from t_odds_company where gooooal=%s limit 1"
        args=[companyname]
        return Db.Mysql.get('SoccerSlave').queryOne(sql,args)
    
    def getAomenCompanyInfo(self):
        sql='select source_aomen,source_aomen_a from t_odds_company where id=5'
        return Db.Mysql.get('SoccerSlave').queryOne(sql)

    def getLastParseFile(self):
        '''��ȡδ������update�ļ�'''
        sql='select updatetime from t_zq_downloadfile where status in(-1,1) order by id desc limit 1'
        return Db.Mysql.get('BetbrainSlave').queryOne(sql)
    
    #��ȡ���������Դƥ�������
    def getSeasonInfoBySeasonMacauName(self,seasonname):
        sql='select * from t_s_season where seasonmacauname=%s'
        args=[seasonname]
        return Db.Mysql.get('SoccerSlave').queryOne(sql,args)
    
    #��ȡ���������Դƥ������
    def getTeamInfoByMacauName(self,teamname):
        if type(teamname)==list:
            if len(teamname):
                sql='select teamid,teamname_gbk as teamname from t_s_teambyname where teamname_gbk in("'+('","'.join(teamname))+'")'
                return Db.Mysql.get('SoccerSlave').query(sql)
            else:
                return []
        else:
            sql='select teamid,teamname_macau from t_s_season where teamname_macau=%s'
            args=[teamname]
            return Db.Mysql.get('SoccerSlave').queryOne(sql,args)
        
    def saveWinnerOdds(self,seasonid,teamid,companyid,odds,lastchangedtime=None):
        sql='set @winnerOddsResult=-1;call p_s_updateodds_winner(%s,%s,%s,%s,%s,@winnerOddsResult)'
        args=[seasonid,teamid,companyid,odds,lastchangedtime]
        Db.Mysql.get('SoccerMaster').query(sql,args)
        sql='select @winnerOddsResult as rs'
        ret=Db.Mysql.get('SoccerMaster').queryOne(sql)
        if ret:
            result=ret['rs']
        return result