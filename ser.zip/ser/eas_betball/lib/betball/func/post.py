#coding:gbk
import betball.func.common as fc
import time
'''ŷ�����ͽӿ�'''
def upload_odds_xml(list,type=1):
    if type==2:
        path=fc.getPath('interface')+fc.getPath('update_live_xml')
    else:
        path=fc.getPath('interface')+fc.getPath('upload_odds_xml')
    for row in list:
        url=path%(row['fixtureid'],row['companyid'],'%s,%s,%s'%(row['win'],row['draw'],row['lost']),2)
        content=fc.fopen(url,type='[FUNC:upload_odds_xml]')
        if content.lower()!='ok':
            fc.write_log('[upload_odds_xml]����%s�ӿڲ���ʧ��!'%url)
            
'''�������ͽӿ�'''
def upload_asian_xml(list,type=1):
    if type==2:
        path=fc.getPath('interface')+fc.getPath('update_live_xml')
    else:
        path=fc.getPath('interface')+fc.getPath('upload_odds_xml')
    for row in list:
        url=path%(row['fixtureid'],row['companyid'],'%s,%s,%s'%(row['sw1'],row['handicaplinename'],row['sw2']),1)
        content=fc.fopen(url,type='[FUNC:upload_asian_xml]')
        if content.lower()!='ok':
            fc.write_log('[upload_aisan_xml]����%s�ӿڲ���ʧ��!'%url)

'''��С�������ͽӿ�'''
def post_big_xml(list):
    path=fc.getPath('interface')+fc.getPath('update_live_xml')
    for row in list:
        url=path%(row['fixtureid'],row['companyid'],'%s,%s,%s'%(row['big'],row['handiname'],row['small']),5)
        content=fc.fopen(url,type='[FUNC:post_big_xml]')
        if content.lower()!='ok':
            fc.write_log('[post_big_xml]����%s�ӿڲ���ʧ��!'%url)
        

'''�����������Ѻ��ӿ�'''
def post_sohu_data(type,list):
    flag=False
    if not list:
        return flag
    for row in list:
        string='<xml><type>1</type><action>1</action>'
        string='%s<oddsshortname>%s</oddsshortname>'%(string,type)
        string='%s<fields><field name="FixtureID" value="%s" iscon="1"/>'%(string,row['fixtureid'])
        string='%s<fields><field name="CompanyID" value="%s" iscon="1"/>'%(string,row['companyid'])
        if type=='asian':
            string='%s<field name="HomeMoneyLine" value="%s"/>'%(string,row['sw1'])
            string='%s<field name="HandicapLineID" value="%s"/>'%(string,row['handicaplineid'])
            string='%s<field name="AwayMoneyLine" value="%s"/>'%(string,row['sw2'])
        elif type=='europe':
            string='%s<field name="Win" value="%s"/>'%(string,row['win'])
            string='%s<field name="Draw" value="%s"/>'%(string,row['draw'])
            string='%s<field name="Lost" value="%s"/>'%(string,row['lost'])
        string='%s<field name="CreateTime" value="%s"/>'%(string,time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
        string='%s</fields></xml>'%string
        postsohu(string)
        
def post_asian_xml(list):
    path=fc.getPath('interface')+fc.getPath('update_asian_xml')
    for row in list:
        url=path%(row['fixtureid'],row['companyid'],'%s,%s,%s'%(row['sw1'],row['handicaplinename'],row['sw2']),time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
        content=fc.fopen(url,type='[FUNC:post_asian_xml]')
        if content.lower()!='ok':
            fc.write_log('[post_asian_xml]����%s�ӿڲ���ʧ��!'%url)

            
def postsohu(string):
#     url='http://61.135.179.88/esunmanage/Odds/index.php/Interface/'
    url='http://lottery.sports.sohu.com/esunmanage/Odds/index.php/Interface/'
    data={'key':"ADDECE29311D3B2956D3018015787864",'requestpack':string}
    fc.fopen(url,data,'[FUNC:postsohu]')
    
def post_365xml(data):
    flag=True
    try:
        xml_str='''<?xml version="1.0" encoding="gb2312"?>\n<odds updatetime="%s">\n'''%(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
        for k in data:
            xml_str='''%s<m IsLotType="%s" IsBeiDan="%s" Limit1="%s" Limit2="%s" Limit3="%s">\n'''%(xml_str,data[k]['islottype'],data[k]['isbeidan'],data[k]['limit1'],data[k]['limit2'],data[k]['limit3'])
            xml_str="%s<MatchID>%s</MatchID><Ball365_MatchID>%s</Ball365_MatchID>\n"%(xml_str,data[k]['fixtureid'],data[k]['ball365_matchid'])
            xml_str="%s<HomeName>%s,%s</HomeName>\n"%(xml_str,data[k]['hometeam'],data[k]['hometeam_tmp'])
            xml_str="%s<AwayName>%s,%s</AwayName>\n"%(xml_str,data[k]['awayteam'],data[k]['awayteam_tmp'])
            xml_str="%s<MatchDate>%s</MatchDate>\n"%(xml_str,data[k]['matchdate'])
            xml_str="%s<IsReverse>%s</IsReverse>\n</m>\n"%(xml_str,data[k]['isreverse'])
        xml_str='%s</odds>'%xml_str
        flag=post_500wan_xml(fc.getPath('create_ball365_xml_path'),xml_str)
    except Exception,e:
        flag=False
        fc.write_log('[post_365xml]���������쳣:%s!'%e)
    return flag
'''����today.xml�ļ�'''
def post_bet007todayxml(data):
    flag=True
    try:
        xml_str='''<?xml version="1.0" encoding="utf-8"?>\n<odds updatetime="%s">\n'''%(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
        for k in data:
            xml_str='''%s<m IsLotType="%s" IsBeiDan="%s" Limit1="%s" Limit2="%s" Limit3="%s">\n'''%(xml_str,data[k]['islottype'],data[k]['isbeidan'],data[k]['limit1'],data[k]['limit2'],data[k]['limit3'])
            xml_str="%s<MatchID>%s</MatchID>\n<Bet007_MatchID>%s</Bet007_MatchID>\n"%(xml_str,data[k]['fixtureid'],data[k]['ball007_matchid'])
            xml_str="%s<HomeName>%s,%s</HomeName>\n"%(xml_str,data[k]['hometeam'],data[k]['hometeam_tmp'])
            xml_str="%s<AwayName>%s,%s</AwayName>\n"%(xml_str,data[k]['awayteam'],data[k]['awayteam_tmp'])
            xml_str="%s<MatchDate>%s</MatchDate>\n"%(xml_str,data[k]['matchdate'])
            xml_str="%s<IsReverse>%s</IsReverse>\n</m>\n"%(xml_str,data[k]['isreverse'])  
        xml_str="%s</odds>"%xml_str
        flag=post_500wan_xml(fc.getPath('create_bet007_today_xml_path'),xml_str.decode('gbk').encode('utf-8'))
    except Exception,e:
        flag=False
        fc.write_log('[post_bet007todayxml]���������쳣:%s!'%e)
    return flag

'''����future.xml�ļ�'''
def post_bet007futurexml(data):
    flag=True
    try:
        xml_str='''<?xml version="1.0" encoding="utf-8"?>\n<odds updatetime="%s">\n'''%(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
        for k in data:
            xml_str='''%s<m IsLotType="%s" IsBeiDan="%s" Limit1="%s" Limit2="%s" Limit3="%s">\n'''%(xml_str,data[k]['islottype'],data[k]['isbeidan'],data[k]['limit1'],data[k]['limit2'],data[k]['limit3'])
            xml_str="%s<MatchID>%s</MatchID>\n<Bet007_MatchID>%s</Bet007_MatchID>\n"%(xml_str,data[k]['fixtureid'],data[k]['ball007_matchid'])
            xml_str="%s<HomeName>%s,%s</HomeName>\n"%(xml_str,data[k]['hometeam'],data[k]['hometeam_tmp'])
            xml_str="%s<AwayName>%s,%s</AwayName>\n"%(xml_str,data[k]['awayteam'],data[k]['awayteam_tmp'])
            xml_str="%s<MatchDate>%s</MatchDate>\n"%(xml_str,data[k]['matchdate'])
            xml_str="%s<IsReverse>%s</IsReverse>\n</m>\n"%(xml_str,data[k]['isreverse'])  
        xml_str="%s</odds>"%xml_str
        flag=post_500wan_xml(fc.getPath('create_bet007_future_xml_path'),xml_str.decode('gbk').encode('utf-8'))
    except Exception,e:
        flag=False
        fc.write_log('[post_bet007futurexml]���������쳣:%s!'%e)
    return flag

'''����betexplorer.xml'''
def post_betexplorerxml(data):
    flag=True
    try:
        xml_str='''<?xml version="1.0" encoding="gb2312"?>\n<odds updatetime="%s">\n'''%(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
        for k in data:
            xml_str='''%s<m ISLotType="%s" IsMain="%s" IsBeiDan="%s">\n'''%(xml_str,data[k]['islottype'],data[k]['ismain'],data[k]['isbeidan'])
            xml_str="%s<MatchID>%s</MatchID>\n"%(xml_str,data[k]['fixtureid'])
            xml_str="%s<MatchDate>%s</MatchDate>\n"%(xml_str,data[k]['matchdate'])
            xml_str="%s<MatchTeam>%s VS %s</MatchTeam>\n"%(xml_str,data[k]['hometeam'],data[k]['awayteam'])
            xml_str="%s<MatchUrl>%s</MatchUrl>\n"%(xml_str,data[k]['url'])
            xml_str="%s<IsReverse>%s</IsReverse>\n"%(xml_str,data[k]['isreverse'])
            xml_str="%s</m>"%xml_str
        xml_str='%s</odds>'%xml_str
        flag=post_500wan_xml(fc.getPath('create_betexplore_xml_path'),xml_str)
    except Exception,e:
        flag=False
        fc.write_log('[post_betexplorerxml]���������쳣:%s!'%e)
    return flag
'''����ball365.xml today.xml, future.xml�ļ�'''
def post_500wan_xml(path,content):
    flag=True
    url=fc.getPath('500wanxml_interface_url')
    content=fc.fopen(url,{'url':path,'content':content},'[POST:post_500wan_xml]')
    if content.lower()!='ok':
        flag=False
        fc.write_log('[post_500wan_xml]����%s�ӿ�����%s�ļ�ʧ��!'%(url,path))
    return flag

'''���ɰ���NBAƥ��xml�ļ�'''
def post_aomen_match_lq(data):
    try:
        xml_str='''<?xml version="1.0" encoding="GB2312"?>\n<NewDataSet updatetime="%s">\n'''%(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
        for r in data:
            xml_str="%s<Table>\n"%xml_str
            xml_str="%s<FixtureID>%s</FixtureID>\n"%(xml_str,r['fixtureid'])
            xml_str="%s<MacauID>%s</MacauID>\n"%(xml_str,r['matchid'])
            xml_str="%s<MatchDate>%s</MatchDate>\n"%(xml_str,r['matchdate'])
            xml_str="%s<VSTeam>%s VS %s</VSTeam>\n"%(xml_str,r['homename'],r['awayname'])
            xml_str="%s<HomeTeamID>%s</HomeTeamID>\n"%(xml_str,r['homeid'])
            xml_str="%s<AwayTeamID>%s</AwayTeamID>\n"%(xml_str,r['awayid'])
            xml_str="%s<IsResver>%s</IsResver>\n"%(xml_str,r['isresver'])
            xml_str="%s</Table>\n"%xml_str
        xml_str="%s</NewDataSet>"%xml_str
        post_500wan_xml(fc.getPath('create_nba_xml'),xml_str)
    except Exception,e:
        fc.write_log('[post_aomen_match_lq]���������쳣:%s!'%e)
        

'''���ɰ�������ƥ��xml�ļ�'''
def post_aomen_match_zq(data):
    try:
        xml_str='''<?xml version="1.0" encoding="utf-8"?>\n<NewDataSet updatetime="%s">\n'''%(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
        for r in data:
            xml_str="%s<Table>\n"%xml_str
            xml_str="%s<FixtureID>%s</FixtureID>\n"%(xml_str,r['fixtureid'])
            xml_str="%s<MacauID>%s</MacauID>\n"%(xml_str,r['matchid'])
            xml_str="%s<MatchDate>%s</MatchDate>\n"%(xml_str,r['matchdate'])
            xml_str="%s<VSTeam>%s VS %s</VSTeam>\n"%(xml_str,r['homename'],r['awayname'])
            xml_str="%s<HomeTeamID>%s</HomeTeamID>\n"%(xml_str,r['homeid'])
            xml_str="%s<AwayTeamID>%s</AwayTeamID>\n"%(xml_str,r['awayid'])
            xml_str="%s<IsResver>%s</IsResver>\n"%(xml_str,r['isresver'])
            xml_str="%s<IsLotTyle>%s</IsLotTyle>\n"%(xml_str,r['islottyle'])
            xml_str="%s<IsBeiDan>%s</IsBeiDan>\n"%(xml_str,r['isbeidan'])
            xml_str="%s</Table>\n"%xml_str
        xml_str="%s</NewDataSet>"%xml_str
        post_500wan_xml(fc.getPath('create_zq_xml'),xml_str.decode('gbk').encode('utf-8'))
    except Exception,e:
        fc.write_log('[post_aomen_match_zq]���������쳣:%s!'%e)

'''���ɰ�������fixtures.xml�ļ�'''
def post_aomen_fixture_zq(string):
    try:
        post_500wan_xml(fc.getPath('create_fixture_zq_xml'),string)
    except Exception,e:
        fc.write_log('[post_aomen_fixture_zq]���������쳣:%s!'%e)
        
'''������־�ļ�'''
def post_log(type,list):
    try:
        if not list:
            return
        timestamp=time.time()
        path=fc.getPath('%s_log_txt'%type)%time.strftime('%Y%m%d',time.localtime(timestamp))
        url=fc.getPath('create_interface_url')+path
        content=fc.fopen(url)
        if len(content)>1 and content.find('<title>404 Not Found</title>')==-1:
            sp="\n"
        else:
            content=sp=''
        time_tmp=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
        company_tmp=[] 
        for r in list:
            #��ͬ����Դ��ͬ���������ʣ�ÿ��ץȡ��ʱ��ÿ�ҹ�˾ֻ��ʾһ��δƥ���¼
            if r['companyname'] in company_tmp:
                continue
            company_tmp.append(r['companyname'])
            content='%s%s[%s]companyname:%s;url:%s'%(content,sp,time_tmp,r['companyname'],r['url'])
            sp="\n"
        post_500wan_xml(path,content)
        company_tmp=None
    except Exception,e:
        fc.write_log('[post_log]���������쳣:%s[url:%s]!'%(e,url))

'''����ball365��־'''
def post_ball365_log(list):
    post_log('ball365',list)
    
'''����bet007��־'''
def post_bet007_log(list):
    post_log('bet007',list)
    
'''����betexplore��־'''
def post_betexplore_log(list):
    post_log('betexplore',list)

'''����gooooal��־'''
def post_gooooal_log(list):
    post_log('gooooal',list) 
    
'''����gooooal.xml'''
def post_gooooal_xml(data,type='today'):
    try:
        flag=True
        if type=='future':
            path=fc.getPath('create_gooooal_future_xml_path')
        else:
            path=fc.getPath('create_gooooal_today_xml_path')
        xml_str='''<?xml version="1.0" encoding="utf-8"?>\n<odds updatetime="%s">\n'''%(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
        for k in data:
            xml_str='''%s<m islottype="%s" isbeidan="%s" limit1="%s" limit2="%s" limit3="%s">\n'''%(xml_str,data[k]['islottype'],data[k]['isbeidan'],data[k]['limit1'],data[k]['limit2'],data[k]['limit3'])
            xml_str="%s<fixtureid>%s</fixtureid>\n<gooooal_id>%s</gooooal_id>\n"%(xml_str,data[k]['fixtureid'],data[k]['gooooal_id'])
            xml_str="%s<homename>%s</homename>\n"%(xml_str,data[k]['hometeam'])
            xml_str="%s<awayname>%s</awayname>\n"%(xml_str,data[k]['awayteam'])
            xml_str="%s<matchdate>%s</matchdate>\n"%(xml_str,data[k]['matchdate'])
            xml_str="%s<isreverse>%s</isreverse>\n</m>\n"%(xml_str,data[k]['isreverse'])  
        xml_str="%s</odds>"%xml_str
        flag=post_500wan_xml(path,xml_str.decode('gbk').encode('utf-8'))
    except Exception,e:
        flag=False
        fc.write_log('[post_gooooal_today_xml]���ɱ�������path:%s���������쳣:%s!'%(path,e))
    return flag


def post_betbrain_txt(data,type):
    try:
        flag=False
#        if type=='future':
#            url=fc.getPath('create_betbrain_future_txt_path')
#        else:
#            url=fc.getPath('create_betbrain_today_txt_path')
        url=fc.getPath('create_betbrain_day_txt_path')%type
        txt='{"updatetime":"%s","data":['%time.strftime("%Y-%m-%d %H:%M:%S")
        sp=''
        for k in data:
            t=k
            txt+=sp+'[%s,%s,"%s","%s","%s","%s",%s,%s,"%s",%s]'%(t['fixtureid'],t['matchid'],t['home_500'],t['away_500'],t['home_source'],t['away_source'],t['homeid_source'],t['awayid_source'],t['matchdate'],t['isreverse'])
            sp=','
        txt+=']}'
        flag=post_500wan_xml(url,txt)
    except Exception,e:
        fc.write_log('[betbrain:post_gooooal_txt]���������쳣:%s!'%e)
    return flag