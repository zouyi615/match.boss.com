#coding:gbk
from betball.threads.base import base
from betball.func import common as Func
from betball.db.odds import Db_Odds
from betball.func import post as Post
import re
'''δ�������߳�'''
class ball365_future_asian(base):
    def __init__(self):
        super(ball365_future_asian,self).__init__('ball365_future_asian')
    
    def do(self):
        try:
            #����Դ����
            team_pattern=re.compile(r"var xn='([^']*)';\nvar yn='([^']*)';")
            company_pattern=re.compile(r"com\[\d+\]=\[\"([^']*)\",\"[^,]*\",\"([^,]*)\"\];\nda\[\d+\]\s*=\s*\[\];(\nda\[\d+\]\[\d+\]\s*=\s*\[([^\']+),[^\]]+\];)+")
            
            #���ͽӿ�����
            odds_arr=[]
            live_arr=[]
            sohu_arr=[]#ͬ�����Ѻ�
            log_arr=[] #��¼δƥ��Ĺ�˾��
            
            list=Func.get_ball565xml_data('future_asian')
            for row in list:
                #��������Դҳ��
                url=self.getConfigPath('ball365_asian')%row['ball365_matchid']
                ct_tmp=self.fopen(url)
#                pn_arr=team_pattern.findall(ct_tmp)
#                if pn_arr:
#                    if pn_arr[0][1]==row['hometeam_ball365'] and pn_arr[0][0]==row['awayteam_ball365']:
#                        row['isreverse']=1
#                    elif pn_arr[0][0]==row['hometeam_ball365'] and pn_arr[0][1]==row['awayteam_ball365']:
#                        row['isreverse']=0 
                company_arr=company_pattern.findall(ct_tmp)
                for r in company_arr:
                    companyname=r[0].strip()
                    companyaddr=r[1].strip()
                    if companyaddr:
                        companyname='%s(%s)'%(companyname,companyaddr)
#                    if companyname=='����(�й�����)':
#                        continue
                    companyid=0
                    istosohu=-1
                    tmp=Db_Odds().getballbycompany(companyname)
                    if tmp and tmp['source_ball365_a']==1:
                        companyid=int(tmp['id'])
                        istosohu=int(tmp['istosohu'])
                        odd_tmp=r[3].split(',')
                        sw1=odd_tmp[0].strip()
                        pk=int(odd_tmp[1].strip())
                        sw2=odd_tmp[2].strip()
                        handicaplinename=Func.get_asian_pka(pk)
                        if row['isreverse']==1:
                            if handicaplinename!='ƽ��':
                                if handicaplinename.find('��')!=-1:
                                    handicaplinename=handicaplinename[2:]
                                else:
                                    handicaplinename='��'+handicaplinename
                        handicaplineid=Db_Odds().gethandicaplineid(handicaplinename)
                        result=Db_Odds().add_asian(row['fixtureid'],companyid,sw1,handicaplineid,sw2)
                        if result==1:
                            if companyid in [2,3,5,6,9,16,277,280]:
                                odds_arr.append({'fixtureid':row['fixtureid'],'companyid':companyid,'sw1':sw1,'handicaplinename':handicaplinename,'sw2':sw2})
                            if companyid in [2,3,5,6,9,16,276,277,280]:
                                live_arr.append({'fixtureid':row['fixtureid'],'companyid':companyid,'sw1':sw1,'handicaplinename':handicaplinename,'sw2':sw2})
                            if (row['islottype']==1 or row['isbeidan']==1) and istosohu==1:
                                sohu_arr.append({'fixtureid':row['fixtureid'],'companyid':companyid,'sw1':sw1,'handicaplineid':handicaplineid,'sw2':sw2})
                        elif result==-1:
                            self.writelog('[thread:ball365_future_asian]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,companyname,companyid))
                    elif not tmp:
                        log_arr.append({'url':url,'companyname':companyname})
            #��ӿ���������
            Post.upload_asian_xml(odds_arr)
            Post.upload_asian_xml(live_arr,2)
            Post.post_sohu_data('asian',sohu_arr)
            Post.post_ball365_log(log_arr)
            odds_arr=None
            live_arr=None
            sohu_arr=None
            log_arr=None
            list=None
        except Exception,e:
            self.writelog('[thread:ball365_future_asian]�̳߳����쳣:%s'%e)