#coding:gbk
from betball.threads.base import base
from betball.func import common as Func
from betball.db.odds import Db_Odds
from betball.func import post as Post
import re
'''��ȫ���߳�'''
class ball365_bqcodds(base):
    def __init__(self):
       super(ball365_bqcodds,self).__init__('ball365_bqcodds')
    
    def do(self):
        try:
            #��¼δƥ��Ĺ�˾��
            log_arr=[]
            
            #����Դ����
            cp_pattern=re.compile(r"com\[\d+\]=\[\"([^\"]+)\",\"([^\"]*)\"\];(\n[\w]+\[\d+\]\s+=\s+\[([^']+),'[^\]]+'\];)+")
            list=Func.get_ball565xml_data('bqcodds')
            for row in list:
                url=self.getConfigPath('ball365_bqcodds')%row['ball365_matchid']
                ct_tmp=self.fopen(url)
                company_arr=cp_pattern.findall(ct_tmp)
                for r in company_arr:
                    cp_name=r[0]
                    companyaddr=r[1]
                    if companyaddr:
                        cp_name='%s(%s)'%(cp_name,companyaddr)
                    tmp=r[3].split(',')
                    aa=tmp[0]
                    ac=tmp[1]
                    ab=tmp[2]
                    ca=tmp[3]
                    cc=tmp[4]
                    cb=tmp[5]
                    ba=tmp[6]
                    bc=tmp[7]
                    bb=tmp[8]
                    
                    companyid=0
                    info=Db_Odds().getballbycompany(cp_name)
                    if info:
                        companyid=int(info['id'])
                    flag=float(aa)!=0 and float(ac)!=0 and float(ab)!=0 and float(ca)!=0 and float(cc)!=0 and float(cb)!=0 and float(ba)!=0 and float(bc)!=0 and float(bb)!=0
                    if companyid>0 and companyid!=5 and info['source_ball365_oth']==1 and flag:
                        if row['isreverse']==0:
                            result=Db_Odds().add_bqc(row['fixtureid'],companyid,aa,ac,ab,ca,cc,cb,ba,bc,bb)
                        else:
                            result=Db_Odds().add_bqc(row['fixtureid'],companyid,bb,bc,ba,cb,cc,ca,ab,ac,aa)
                        if result==-1:
                            self.writelog('[thread:ball365_bqcodds]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,cp_name,companyid)) 
                    elif companyid==0:
                        log_arr.append({'url':url,'companyname':cp_name})
            Post.post_ball365_log(log_arr)
        except Exception,e:
            self.writelog('[thread:ball365_bqcodds]�̳߳����쳣:%s'%e)
