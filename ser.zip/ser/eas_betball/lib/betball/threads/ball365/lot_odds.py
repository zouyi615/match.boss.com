#coding:gbk
import re
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
class ball365_lot_odds(base):
    def __init__(self):
        super(ball365_lot_odds,self).__init__('ball365_lot_odds')
    
    def do(self):
        try:
            #����Դ����
            team_pattern=re.compile(r"var xn='([^']*)';\nvar yn='([^']*)';")
            company_pattern=re.compile(r"com\[\d+\]=\[\"([^']*)\",\"[^,]*\",\"([^,]*)\"\];\nde\[\d+\]\s*=\s*\[\];(\nde\[\d+\]\[\d+\]\s*=\s*\[([^']+),[^\]]+\];)+")
            
            #���ͽӿ�����
            odds_arr=[]
            live_arr=[]
            sohu_arr=[]#�Ѻ��ӿ�
            log_arr=[] #��¼δƥ��Ĺ�˾��
            
            list=Func.get_ball565xml_data('lot_odds')
            for row in list:
                url=self.getConfigPath('ball365_lot')%row['ball365_matchid']
                ct_tmp=self.fopen(url)
                pn_arr=team_pattern.findall(ct_tmp)
                if pn_arr:
                    if pn_arr[0][0]==row['awayteam_ball365'] and pn_arr[0][1]==row['hometeam_ball365']:
                        row['isreverse']=1
                    elif pn_arr[0][0]==row['hometeam_ball365'] and pn_arr[0][1]==row['awayteam_ball365']:
                        row['isreverse']=0
                tmp_arr=company_pattern.findall(ct_tmp)
                for r in tmp_arr:
                    cp_name=r[0].strip()
                    cp_addr=r[1].strip()
                    if cp_addr:
                        cp_name='%s(%s)'%(cp_name,cp_addr)
                    odd_tmp=r[3].split(',')
                    if row['isreverse']==0:
                        win=odd_tmp[0]
                        draw=odd_tmp[1]
                        lost=odd_tmp[2]
                    else:
                        lost=odd_tmp[0]
                        draw=odd_tmp[1]
                        win=odd_tmp[2]
                    try:
                        win='%.2f'%float(win)
                        draw='%.2f'%float(draw)
                        lost='%.2f'%float(lost)
                        if win=='0.00' or draw=='0.00' or lost=='0.00':
                            self.writelog('[thread:ball365_lot_odds]��ȡ���ʳ����쳣:win:%s,draw:%s,lost:%s;[url:%s]'%(win,draw,lost,url))
                            continue
                    except Exception,e:
                        self.writelog('[thread:ball365_lot_odds]��ȡ���ʳ����쳣:win:%s,draw:%s,lost:%s;[url:%s]'%(win,draw,lost,url))
                        continue
                    companyinfo=Db_Odds().getballbycompany(cp_name)
                    if companyinfo and int(companyinfo['source_ball365_oth'])==1:
                        companyid=int(companyinfo['id'])
                        istosohu=int(companyinfo['istosohu'])
                        result=Db_Odds().add_odds(row['fixtureid'],companyid,win,draw,lost)
                        if result==1:
                            if companyid in [2,3,4,5,6,7,8,9,10,11,15,18,280]:
                                odds_arr.append({'fixtureid':row['fixtureid'],'companyid':companyid,'win':win,'draw':draw,'lost':lost})
                            if companyid in [2,3,4,5,6,7,8,9,10,11,15,276,293]:
                                live_arr.append({'fixtureid':row['fixtureid'],'companyid':companyid,'win':win,'draw':draw,'lost':lost})
                            if istosohu==1:
                                sohu_arr.append({'fixtureid':row['fixtureid'],'companyid':companyid,'win':win,'draw':draw,'lost':lost})
                        elif result==-1:
                            self.writelog('[thread:ball365_lot_odds]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,cp_name,companyid))
                    elif not companyinfo:
                        log_arr.append({'url':url,'companyname':cp_name})
                        
            Post.upload_odds_xml(odds_arr)
            Post.upload_odds_xml(live_arr,2)
            Post.post_sohu_data('europe',sohu_arr)
            Post.post_ball365_log(log_arr)
            list=None
            odds_arr=None
            live_arr=None   
        except Exception,e:
            self.writelog('[thread:ball365_lot_odds]�̳߳����쳣:%s'%e)