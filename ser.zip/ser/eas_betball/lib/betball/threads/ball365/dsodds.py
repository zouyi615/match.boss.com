#coding:gbk
from betball.threads.base import base
from betball.func import common as Func
from betball.db.odds import Db_Odds
from betball.func import post as Post
import re
'''��˫�����߳�'''
class ball365_dsodds(base):
    def __init__(self):
        super(ball365_dsodds,self).__init__('ball365_dsodds')
    def do(self):
        try:
            #����Դ����
            cp_pattern=re.compile(r"com\[\d+\]=\[\"([^\"]+)\"\];(\n[\w]+\[\d+\]\s+=\s+\[([^']+),'[^']+'\];)+")
            
            #��¼δƥ��Ĺ�˾��
            log_arr=[] 
            
            list=Func.get_ball565xml_data('dsodds')
            for row in list:
                url=self.getConfigPath('ball365_dsodds')%row['ball365_matchid']
                ct_tmp=self.fopen(url)
                company_arr=cp_pattern.findall(ct_tmp)
                for r in company_arr:
                    cp_name=r[0]
                    tmp=r[2].split(',')
                    d=tmp[0]
                    s=tmp[1]
                    companyid=0
                    info=Db_Odds().getballbycompany(cp_name)
                    if info:
                        companyid=int(info['id'])
                    if companyid>0 and companyid!=5 and info['source_ball365_oth']==1:
                        result=Db_Odds().add_ds(row['fixtureid'],companyid,d,s)
                        if result==-1:
                           self.writelog('[thread:ball365_dsodds]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,cp_name,companyid)) 
                    elif companyid==0:
                        log_arr.append({'url':url,'companyname':cp_name})
            Post.post_ball365_log(log_arr)
        except Exception,e:
            self.writelog('[thread:ball365_dsodds]�̳߳����쳣:%s'%e)
