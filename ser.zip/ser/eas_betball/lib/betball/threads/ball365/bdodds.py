#coding:gbk
from betball.threads.base import base
from betball.func import common as Func
from betball.db.odds import Db_Odds
from betball.func import post as Post
import re
class ball365_bdodds(base):
    def __init__(self):
        super(ball365_bdodds,self).__init__('ball365_bdodds')
    def do(self):
        try:
            #��¼δƥ��Ĺ�˾��
            log_arr=[]
            
            #����Դ����
            cp_pattern=re.compile(r"com\[\d+\]=\[\"([^\"]+)\",\"([^\"]*)\"\];(\n[\w]+\[\d+\]\s+=\s+\[([^']+),'[^']+'\];)+")
            
            list=Func.get_ball565xml_data('bdodds')
            for row in list:
                url=self.getConfigPath('ball365_bdodds')%row['ball365_matchid']
                ct_tmp=self.fopen(url)
                company_arr=cp_pattern.findall(ct_tmp)
                for r in company_arr:
                    cp_name=r[0]
                    companyaddr=r[1]
                    if companyaddr:
                        cp_name='%s(%s)'%(cp_name,companyaddr)
                    tmp=r[3].split(',')
                    a10=tmp[0]
                    b10=tmp[10]
                    
                    a20=tmp[1]
                    b20=tmp[11]
                    a21=tmp[2]
                    b21=tmp[12]
                    
                    a30=tmp[3]
                    b30=tmp[13]
                    a31=tmp[4]
                    b31=tmp[14]
                    a32=tmp[5]
                    b32=tmp[15]
                    
                    a40=tmp[6]
                    b40=tmp[16]
                    a41=tmp[7]
                    b41=tmp[17]
                    a42=tmp[8]
                    b42=tmp[18]
                    a43=tmp[9]
                    b43=tmp[19]
                    
                    c00=tmp[20]
                    c11=tmp[21]
                    c22=tmp[22]
                    c33=tmp[23]
                    c44=tmp[24]
                    a5=0
                    b5=0
                    companyid=0
                    info=Db_Odds().getballbycompany(cp_name)
                    if info:
                        companyid=int(info['id'])
                    if companyid>0 and companyid!=5 and info['source_ball365_oth']==1:
                        if row['isreverse']==0:
                            result=Db_Odds().add_bd(row['fixtureid'],companyid,a10,b10,a20,b20,a21,b21,a30,b30,a31,b31,a32,b32,a40,b40,a41,b41,a42,b42,a43,b43,c00,c11,c22,c33,c44,a5,b5)
                        else:
                            result=Db_Odds().add_bd(row['fixtureid'],companyid,b10,a10,b20,a20,b21,a21,b30,a30,b31,a31,b32,a32,b40,a40,b41,a41,b42,a42,b43,a43,c00,c11,c22,c33,c44,b5,a5)
                        if result==-1:
                           self.writelog('[thread:ball365_bdodds]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,cp_name,companyid)) 
                    elif companyid==0:
                        log_arr.append({'url':url,'companyname':cp_name})
            Post.post_ball365_log(log_arr)
        except Exception,e:
            self.writelog('[thread:ball365_bdodds]�̳߳����쳣:%s'%e)