#coding:gbk
from betball.threads.base import base
from betball.func import common as Func
from betball.db.odds import Db_Odds
from betball.func import post as Post
import re
'''δ����С����'''
class ball365_future_dxodds(base):
    def __init__(self):
        super(ball365_future_dxodds,self).__init__('ball365_future_dxodds')
    
    def do(self):
        try:
            dx_arr=[]
            log_arr=[] #��¼δƥ��Ĺ�˾��
            #����Դ����
            cp_pattern=re.compile(r"com\[\d+\]=\[\"([^']*)\",\"[^,]*\",\"([^,]*)\"\];\ndb\[\d+\]\s*=\s*\[\];(\ndb\[\d+\]\[\d+\]\s*=\s*\[([^\']+),[^\]]+\];)+")
            list=Func.get_ball565xml_data('future_dxodds')
            for row in list:
                url=self.getConfigPath('ball365_dxodds')%row['ball365_matchid']
                ct_tmp=self.fopen(url)
                company_arr=cp_pattern.findall(ct_tmp)
                for r in company_arr:
                    cp_name=r[0]
                    cp_addr=r[1]
                    if cp_addr:
                        cp_name='%s(%s)'%(cp_name,cp_addr)
#                    if cp_name=='����(�й�����)':
#                        continue
                    odd_tmp=r[3].split(',')
                    big='%.2f'%float(odd_tmp[0])
                    pankou=int(odd_tmp[1])
                    small='%.2f'%float(odd_tmp[2])
                    info=Db_Odds().getballbycompany(cp_name)
                    if info:
                        if int(info['source_ball365_a'])==1:
                            companyid=int(info['id'])
                            bigsmallname=Func.get_big_pka(pankou)
                            result=Db_Odds().add_bigsmall(row['fixtureid'],companyid,big,bigsmallname,small)
                            if result==1:
                                if companyid in Func.getCompany('dx'):
                                     dx_arr.append({'fixtureid':row['fixtureid'],'companyid':companyid,'big':big,'handiname':bigsmallname,'small':small})                       
                            elif result==-1:
                                self.writelog('[thread:ball365_future_dxodds]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,cp_name,companyid))
                    else:
#                        self.writelog('[thread:ball365_future_dxodds]%s:δ��ƥ�����ball365��˾��'%cp_name)
                        log_arr.append({'url':url,'companyname':cp_name})
            Post.post_big_xml(dx_arr)
            Post.post_ball365_log(log_arr)
        except Exception,e:
            self.writelog('[thread:ball365_future_dxodds]�̳߳����쳣:%s'%e)