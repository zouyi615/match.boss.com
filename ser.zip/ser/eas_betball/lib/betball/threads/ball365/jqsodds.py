#coding:gbk
from betball.threads.base import base
from betball.func import common as Func
from betball.db.odds import Db_Odds
from betball.func import post as Post
import re
'''�������߳�'''
class ball365_jqsodds(base):
    def __init__(self):
        super(ball365_jqsodds,self).__init__('ball365_jqsodds')
    def do(self):
        try:
            #��¼δƥ��Ĺ�˾��
            log_arr=[]
            #����Դ����
            cp_pattern=re.compile(r"com\[\d+\]=\[\"([^\"]+)\",\"([^\"]*)\"\];(\n[\w]+\[\d+\]\s+=\s+\[([^']+),'[^\]]+'\];)+")
            list=Func.get_ball565xml_data('jqsodds')
            for row in list:
                url=self.getConfigPath('ball365_jqsodds')%row['ball365_matchid']
                ct_tmp=self.fopen(url)
                company_arr=cp_pattern.findall(ct_tmp)
                for r in company_arr:
                    cp_name=r[0]
                    companyaddr=r[1]
                    if companyaddr:
                        cp_name='%s(%s)'%(cp_name,companyaddr)
                    tmp=r[3].split(',')
                    b01=tmp[0]
                    b23=tmp[1]
                    b46=tmp[2]
                    b7=tmp[3]
                    companyid=0
                    info=Db_Odds().getballbycompany(cp_name)
                    if info:
                        companyid=int(info['id'])
                    if companyid>0 and companyid!=5 and info['source_ball365_oth']==1:
                        result=Db_Odds().add_jqs(row['fixtureid'],companyid,b01,b23,b46,b7)
                        if result==-1:
                            self.writelog('[thread:ball365_jqsodds]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,cp_name,companyid)) 
                    elif companyid==0:
                        log_arr.append({'url':url,'companyname':cp_name})
            Post.post_ball365_log(log_arr)   
        except Exception,e:
            self.writelog('[thread:ball365_jqsodds]�̳߳����쳣:%s'%e)