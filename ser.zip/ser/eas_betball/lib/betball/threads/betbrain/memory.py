#coding:gbk
'''��ط������ڴ�'''
import traceback,time
from betball.threads.base import base
from betball.func import common as Com
import re,commands
class betbrain_memory(base):
    def __init__(self):
        self.updatetime=None
        super(betbrain_memory,self).__init__('betbrain_memory')
    
    def do(self):
        memoryinfo=cmd_free()
        #��ǰ�������ڴ�С��50M
        if int(memoryinfo['free'])/1024<50:
            #ÿ���Сʱ�澯һ��
            timestamp=time.time()
            if not self.updatetime or (timestamp-self.updatetime)>1800:
                self.updatetime=timestamp
                Com.sendMsgInterface(self.getConfigPath('phone'),'[NOTICE]��ǰ�����ڴ�С��50M!')
                #����seo
                kill('seo')
                kill('sitemap')
                            
def cmd_free():
    out=commands.getstatusoutput('free')
    list=out[1].strip().split('\n')
    tmp=re.sub('[ ]{2,}', ' ', str(list[3])).split(' ')
    return {'total':tmp[1], 'used':tmp[2], 'free':tmp[3]}

def kill(pname):
    out=commands.getstatusoutput('ps ax | grep %s'%pname)
    list=out[1].split('\n')
    for r in list:
        tmp=re.sub('[ ]{2,}', ' ',str(r).strip()).split(' ')
        #�ҵ�������
        if tmp[2]=='Sl':
            #kill ����
            command='kill -9 %s'%int(tmp[0])
            info=commands.getstatusoutput(command)
            print '[service:%s]command:%s[result:%s]'%(pname,command,info[1])
            break