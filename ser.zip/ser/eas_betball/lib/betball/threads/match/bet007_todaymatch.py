#coding:gbk
import time,curl,re,traceback
from threading import Thread
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''bet007ƥ���������'''
class bet007_todaymatch(Thread):
    def __init__(self):
        Thread.__init__(self)
        self.isRun=True
        self.data=[]
        self.request_times=0
    def run(self):
        Func.write_log('[thread:bet007_todaymatch]�߳̿���!')
        while self.isRun:
            self.do()
            time.sleep(Func.getThreadSleep('bet007_todaymatch'))
    def stop(self):
        self.isRun=False
        Func.write_log('[thread:bet007_todaymatch]�߳�ֹͣ!')
    def getData(self):
        return self.data
    def request_once(self,url,timeout=10):
        try:
            content=''
            request=curl.Curl()
            #���ó�ʱʱ��
            request.set_timeout(timeout)
            content=request.get(url)
            request.close()
            self.request_times=0
        except Exception,e:
            if self.request_times<3:
                self.request_times+=1
                return self.request_once(url,timeout)
            else:
                self.request_times=0
                Func.write_log('[thread:bet007_todaymatch]request_once����%sҳ������쳣:%s'%(url,traceback.format_exc()))
        return content
    def do(self):
        try:
            data_arr=[]
            result={}
            url=Func.getPath('bet007_todayxml')
            content=self.request_once(url)
            xml=Func.parseString(content)      
            if xml:
                node_arr=xml.getElementsByTagName('m')
            else:
                node_arr=[]
            sp_time=str(time.strftime('%Y%m%d%H%M',time.localtime()))
            for node in node_arr:
                matchdate=str(node.getElementsByTagName('MatchDate')[0].firstChild.nodeValue)

                if matchdate<sp_time:
                    continue
                fixtureid=int(node.getElementsByTagName('MatchID')[0].firstChild.nodeValue)   
                ball007_matchid=int(node.getElementsByTagName('Bet007_MatchID')[0].firstChild.nodeValue)
                home_tmp=node.getElementsByTagName('HomeName')[0].firstChild.nodeValue.encode('gbk').split(',')
                hometeam=home_tmp[0]
                hometeam_tmp=home_tmp[1]
                away_tmp=node.getElementsByTagName('AwayName')[0].firstChild.nodeValue.encode('gbk').split(',')
                awayteam=away_tmp[0]
                awayteam_tmp=away_tmp[1]                 
                isreverse=int(node.getElementsByTagName('IsReverse')[0].firstChild.nodeValue)
                islottype=int(node.getAttribute('IsLotType'))
                isbeidan=int(node.getAttribute('IsBeiDan'))
                limit1=int(node.getAttribute('Limit1'))
                limit2=int(node.getAttribute('Limit2'))
                limit3=int(node.getAttribute('Limit3'))
                
                result[fixtureid]={}
                result[fixtureid]['matchdate']=matchdate
                result[fixtureid]['fixtureid']=fixtureid
                result[fixtureid]['ball007_matchid']=ball007_matchid
                result[fixtureid]['hometeam']=hometeam
                result[fixtureid]['hometeam_tmp']=hometeam_tmp
                result[fixtureid]['awayteam']=awayteam
                result[fixtureid]['awayteam_tmp']=awayteam_tmp
                result[fixtureid]['isreverse']=isreverse
                result[fixtureid]['islottype']=islottype
                result[fixtureid]['isbeidan']=isbeidan
                result[fixtureid]['limit1']=limit1
                result[fixtureid]['limit2']=limit2
                result[fixtureid]['limit3']=limit3
        except Exception,e:
            Func.write_log('[thread:bet007_todaymatch]����%sҳ������쳣:%s'%(url,e))
        
        try:
            url=Func.getPath('bet007_todaymatch')
            content=self.request_once(url,20).replace("\r\n",'').replace("\t",'')
    #            pattern=re.compile(r"<tr[^>]*><td[^>]*><input[^>]*></td><td[^>]*>(.*?)</td><td[^>]*>([^>]*)<br>([^<]*)</td><td[^>]*><a[^>]+>(.*?)</a></td>.*?(?=<a\s*?href)[^>]*>(.*?)</a></td><td[^>]*><a\D*?/(\d+)[^>]*?>�鿴</a>[^<]*?</td></tr>")
            pattern=re.compile(r'<tr align="center"[^>]*><td rowspan="2"><input[^>]*></td><td[^>]*>(.*?)</td><td[^>]*>([^>]*)<br>([^<]*)</td><td rowspan="2" class="team"><a[^>]+>(.*?)</a>\s*</td>.+?<td rowspan="2" class="team"><a[^>]+>(.*?)</a></td><td[^>]*><a\D*?/(\d+)[^>]*>�鿴</a>[^<]*</td>')
            tmp_arr=pattern.findall(content)
            if tmp_arr:
                timestamp=time.time()
                list=Db_Odds().getfixture(time.strftime('%Y-%m-%d %H:%M:00',time.localtime(timestamp)),time.strftime('%Y-%m-%d 12:00:00',time.localtime(timestamp+24*3600)))
                for r in tmp_arr:
                    try:
                        matchname=r[0]
                        if matchname.find('<')!=-1:
                            matchname,rp_count=re.subn(r'<[^>]+>','',matchname)
                        matchname=matchname.strip()
                        matchtime='20%s %s:00'%(r[1].strip(),r[2].strip())
                        home=r[3]
                        if home.find('<')!=-1 or home.find('[')!=-1:
                            home,rp_count=re.subn(r'<[^>]+>','',home)
                            home,rp_count=re.subn(r'\[[^\]]*\]','',home)
                        away=r[4]
                        if away.find('<')!=-1 or away.find('[')!=-1:
                            away,rp_count=re.subn(r'<[^>]+>','',away)
                            away,rp_count=re.subn(r'\[[^\]]*\]','',away)
                        home=home.split('(')[0].strip()
                        away=away.split('(')[0].strip()
                        ball007_matchid=int(r[5].strip())
                        isexists=0
                        for t in list:
                            fixtureid=t['fixtureid']
                            matchdate=t['matchdatetime']
                            limit1=0
                            limit2=0
                            limit3=0
                            if t['sourcelimit'] and int(t['sourcelimit'])==1 and t['sourceoddslimit']:
                                source_arr=t['sourceoddslimit'].split(',')
                                for v in source_arr:
                                    if v=='1':
                                        limit1=1
                                    elif v=='2':
                                        limit2=1
                                    elif v=='3':
                                        limit3=1
                            islottype=int(t['islottyle'])
                            isbeidan=int(t['isbeidan'])
                            if  home and away and (t['bet007_1'] or t['bet007_e1']) and (t['bet007_2'] or t['bet007_e2']): 
                                flag1=(home.lower()==t['bet007_1'].lower() or home.lower()==t['bet007_e1'].lower()) and (away.lower()==t['bet007_2'].lower() or away.lower()==t['bet007_e2'].lower())
                                flag2=(home.lower()==t['bet007_2'].lower() or home.lower()==t['bet007_e2'].lower()) and (away.lower()==t['bet007_1'].lower() or away.lower()==t['bet007_e1'].lower())
                            else:
                                flag1=flag2=False
                            flag3=Func.check_day_diff(matchtime,matchdate)
                            if (flag1 or flag2) and flag3:
                                isexists=1
                                if flag1:
                                    home_tmp=home
                                    away_tmp=away
                                    isreverse=0
                                else:
                                    home_tmp=away
                                    away_tmp=home
                                    isreverse=1
                                result[fixtureid]={}
                                result[fixtureid]['fixtureid']=fixtureid                               
                                result[fixtureid]['isreverse']=isreverse
                                result[fixtureid]['islottype']=islottype
                                result[fixtureid]['isbeidan']=isbeidan
                                result[fixtureid]['limit1']=limit1
                                result[fixtureid]['limit2']=limit2
                                result[fixtureid]['limit3']=limit3
                                result[fixtureid]['ball007_matchid']=ball007_matchid
                                result[fixtureid]['hometeam']=t['bet007_e1']
                                result[fixtureid]['hometeam_tmp']=home_tmp
                                result[fixtureid]['awayteam']=t['bet007_e2']
                                result[fixtureid]['awayteam_tmp']=away_tmp
                                #result[fixtureid]['matchdate']=str(time.strftime('%Y%m%d%H%M',time.strptime(matchdate,'%Y-%m-%d %H:%M:%S')))
                                result[fixtureid]['matchdate']=re.sub(r"\s|\-|\:","",str(matchdate))[0:12]
                                data_arr.append({'matchname':matchname,'fixtureid':fixtureid,'homename':home,'awayname':away,'matchdate':matchdate,'url':Func.getPath('bet007_odds')%ball007_matchid,'ismatch':1,'istoday':1})
                                break
                        if isexists==0:
                            data_arr.append({'matchname':matchname,'fixtureid':'','homename':home,'awayname':away,'matchdate':matchtime,'url':Func.getPath('bet007_odds')%ball007_matchid,'ismatch':0,'istoday':1})
                    except:
                        Func.write_log('[thread:bet007_todaymatch]����%sҳ�����ݳ����쳣:%s'%(url,traceback.format_exc()))
            if Post.post_bet007todayxml(result):
                self.data=data_arr
            data_arr=None
            result=None
        except Exception,e:
            Func.write_log('[thread:bet007_todaymatch]����%sҳ������쳣:%s'%(url,traceback.format_exc()))