#coding:gbk
import re,time,curl
from threading import Thread
from betball.func import common as Func
from betball.db.odds import Db_Odds
from betball.func import post as Post
class betexplore_match(Thread):
    def __init__(self):
        Thread.__init__(self)
        self.isRun=True
        self.data=[]
    def stop(self):
        self.isRun=False
        Func.write_log('[thread:betexplore_match]�߳�ֹͣ!')
    def run(self):
        Func.write_log('[thread:betexplore_match]�߳̿���!')
        while self.isRun:
            self.do()
            time.sleep(Func.getThreadSleep('betexplore_match'))
    def getData(self):
        return self.data
    def request_once(self,url,timeout=10):
        try:
            content=''
            request=curl.Curl()
            #���ó�ʱʱ��
            request.set_timeout(timeout)
            content=request.get(url)
            request.close()
            self.request_times=0
        except Exception,e:
            if self.request_times<3:
                self.request_times+=1
                return self.request_once(url,timeout)
            else:
                self.request_times=0
                Func.write_log('[thread:betexplore_match]request_once����%sҳ������쳣:%s'%(url,e))
        return content
    def do(self):
        data_arr=[]   
        result_arr={}
        try:
            url=Func.getPath('betexplore_xml')
#            content=self.request_once(url)
            content=self.request_once(url)
            content=content.replace('encoding="gb2312"','encoding="gbk"')
            xml=Func.parseString(content)
            pattern=re.compile(r'<tr[^>]*><td[^>]*>([^>]*)</td><td[^>]*><a\s+href=\"/soccer([^\"]*)\"[^>]*>([^<]*)\s*-\s*([^<]*)</a></td>')
            if xml:
                node_arr=xml.getElementsByTagName('m')
            else:
                node_arr=[]
            sp_time=str(time.strftime('%Y%m%d1200',time.localtime()))
            for node in node_arr:
                matchdate=str(node.getElementsByTagName('MatchDate')[0].firstChild.nodeValue)
                if matchdate<sp_time:
                    continue
                fixtureid=int(node.getElementsByTagName('MatchID')[0].firstChild.nodeValue)
                isbeidan=int(node.getAttribute('IsBeiDan'))
                isreverse=int(node.getElementsByTagName('IsReverse')[0].firstChild.nodeValue)
                url=node.getElementsByTagName('MatchUrl')[0].firstChild.nodeValue.encode('gbk')
                team_str=node.getElementsByTagName('MatchTeam')[0].firstChild.nodeValue.encode('gbk')
                islottype=int(node.getAttribute('ISLotType'))
                ismain=int(node.getAttribute('IsMain'))
                team_arr=team_str.split('VS')
                if isreverse==0:
                    hometeam=team_arr[0].strip()
                    awayteam=team_arr[1].strip()
                else:
                    hometeam=team_arr[1].strip()
                    awayteam=team_arr[0].strip()
                row={'islottype':islottype,'ismain':ismain,'isbeidan':isbeidan,'fixtureid':fixtureid,'matchdate':matchdate,'isreverse':isreverse,'url':url,'hometeam':hometeam,'awayteam':awayteam}
                result_arr[fixtureid]=row
            for i in range(0,15):
                list=Db_Odds().getbetexplorefixture(time.strftime('%Y-%m-%d 00:00:00',time.localtime(time.time()+i*24*3600)),time.strftime('%Y-%m-%d 00:00:00',time.localtime(time.time()+(i+2)*24*3600)))
                if not list:
                    continue
                timestamp=time.time()+i*24*3600-6*3600
                y=time.strftime('%Y',time.localtime(timestamp))
                m=time.strftime('%m',time.localtime(timestamp))
                d=time.strftime('%d',time.localtime(timestamp))
                url=Func.getPath('betexplore_url')%(y,int(m),int(d))
                content=self.request_once(url,15)
                tmp_arr=pattern.findall(content)
                
                for r in tmp_arr:
                    if r[0]!='&nbsp;':
                        matchtime=r[0].replace('.',':')
                    else:
                        matchtime='00:00:00'
                    matchdatetime='%s-%s-%s %s:00'%(y,m,d,matchtime)
                    url=r[1].replace("'",'').replace('"','')
                    tmp=url.split('/')
                    if len(tmp)>1:
                        leaguename=tmp[1]
                    else:
                        leaguename=''
                    pattern_tmp=re.compile(r'matchid=(\d+)')
                    tmp=pattern_tmp.findall(url)
                    if tmp:
                        matchid=int(tmp[0])
                    else:
                        matchid=0
                    home=r[2].replace("'",'').strip()
                    away=r[3].replace("'",'').strip()
                    isexists=0
                    for t in list:
                        fixtureid=int(t['fixtureid'])
                        home_db=t['home']
                        away_db=t['away']
                        homebet_db=t['bexplorer_1']
                        awaybet_db=t['bexplorer_2']
                        homebetcs_db=t['bexplorercs_1']
                        awaybetcs_db=t['bexplorercs_2']
                        matchdate=str(t['matchdatetime'])
                        islottype=int(t['islottyle'])
                        ismain=int(t['ismain'])
                        isbeidan=int(t['isbeidan'])
                        flag1=(home.lower()==homebet_db.lower() or home.lower()==homebetcs_db.lower()) and (away.lower()==awaybet_db.lower() or away.lower()==awaybetcs_db.lower())
                        flag2=(home.lower()==awaybet_db.lower() or home.lower()==awaybetcs_db.lower()) and (away.lower()==homebet_db.lower() or away.lower()==homebetcs_db.lower())
                        flag3=Func.check_day_diff(matchdatetime,matchdate)
                        if (flag1 or flag2) and flag3:
                            isexists=1
                            if flag2:
                                isreverse=1
                            else:
                                isreverse=0
                            result_arr[fixtureid]={}
                            result_arr[fixtureid]['islottype']=islottype
                            result_arr[fixtureid]['ismain']=ismain
                            result_arr[fixtureid]['isbeidan']=isbeidan 
                            result_arr[fixtureid]['fixtureid']=fixtureid  
                            
                            #result_arr[fixtureid]['matchdate']=str(time.strftime('%Y%m%d%H%M',time.strptime(matchdate,'%Y-%m-%d %H:%M:%S')))
                            result_arr[fixtureid]['matchdate']=re.sub(r"\s|\-|\:","",str(matchdate))[0:12]

                            result_arr[fixtureid]['isreverse']=isreverse   
                            result_arr[fixtureid]['url']=url
                            result_arr[fixtureid]['hometeam']=home_db
                            result_arr[fixtureid]['awayteam']=away_db
                            if isreverse==0:
                                data_arr.append({'matchname':leaguename,'fixtureid':fixtureid,'homename':'%s(%s)'%(home_db,home),'awayname':'%s(%s)'%(away_db,away),'matchdate':matchdate,'url':Func.getPath('betexplore_oddsurl')%url,'ismatch':1})
                            else:
                                data_arr.append({'matchname':leaguename,'fixtureid':fixtureid,'homename':'%s(%s)'%(home_db,away),'awayname':'%s(%s)'%(away_db,home),'matchdate':matchdate,'url':Func.getPath('betexplore_oddsurl')%url,'ismatch':1})
                            break
                    if isexists==0:
                        data_arr.append({'matchname':leaguename,'fixtureid':'','homename':home,'awayname':away,'matchdate':matchdatetime,'url':Func.getPath('betexplore_oddsurl')%url,'ismatch':0})
            if Post.post_betexplorerxml(result_arr):
                self.data=data_arr
        except Exception,e:
            Func.write_log('[thread:betexplore_match]�̳߳����쳣:%s'%e)