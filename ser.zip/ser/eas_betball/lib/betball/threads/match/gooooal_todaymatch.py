#coding:gbk
import time,curl,traceback
from threading import Thread
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''ѩԵ����������ץȡ'''
class gooooal_todaymatch(Thread):
    def __init__(self):
        Thread.__init__(self)
        self.isRun=True
        self.data=[]
        self.request_times=0
    def run(self):
        Func.write_log('[thread:gooooal_todaymatch]�߳̿���!')
        while self.isRun:
            self.do()
            time.sleep(Func.getThreadSleep('gooooal_todaymatch'))
    def stop(self):
        self.isRun=False
        Func.write_log('[thread:gooooal_todaymatch]�߳�ֹͣ!')
    def getData(self):
        return self.data
    
    '''��ȡҳ������'''
    def request_once(self,url,timeout=10):
        try:
            content=''
            request=curl.Curl()
            #���ó�ʱʱ��
            request.set_timeout(timeout)
            content=request.get(url)
            request.close()
            self.request_times=0
        except Exception,e:
            if self.request_times<3:
                self.request_times+=1
                return self.request_once(url,timeout)
            else:
                self.request_times=0
                Func.write_log('[thread:gooooal_todaymatch]request_once����%sҳ������쳣:%s'%(url,traceback.format_exc()))
        return content
    
    def do(self):
        try:
            data_arr=[]
            result={}
            
            #-------------��ȡ����Դ����������Ϣ-----------------#
            url=Func.getPath('gooooal_todaymatch')
            content=self.request_once(url).decode('utf-8','ignore').encode('gbk')
            #����ҳ������
            ct_tmp=content.split('$')
            if len(ct_tmp)>=3:
                #------------��ȡ���ݿ⵱������------#
                timestamp=time.time()
                list=Db_Odds().getgooooalfixture(time.strftime('%Y-%m-%d %H:%M:00',time.localtime(timestamp)),time.strftime('%Y-%m-%d 12:00:00',time.localtime(timestamp+24*3600)))
                
                #------------��ȡ��������id----------#
                league_arr={}
                lg_tmp=ct_tmp[1].split('~')
                for v in lg_tmp:
                    try:
                        tmp=v.split('^')
                        if len(tmp)==7:
                            lid=int(tmp[0])
                            league_arr[lid]=tmp[2]
                    except Exception,e:
                        Func.write_log('[thread:gooooal_todaymatch]����������Ϣ�����쳣:%s'%traceback.format_exc())
                
                #------------��ȡ������Ϣ----------#    
                match_tmp=ct_tmp[2].split('~')
                for v in match_tmp:
                    try:
                        tmp=v.split('^')
                        if len(tmp)==43:
                            matchid=int(tmp[0])#����id
                            lid=int(tmp[4])#����id
                            if league_arr.has_key(lid):
                                leaguename=league_arr[lid]
                            else:
                                leaguename=''   
                            matchtime=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(int(tmp[2])))#����ʱ��
                            homename=tmp[7]#������
                            awayname=tmp[13]#�Ͷ���
                            isexists=0#Ĭ�����ò�����
                            for t in list:
                                
                                #-----������Դ�����Ͷ���������ʱ�������ݿ���жԱ�-----#
                                if t['gooooal_1'] and t['gooooal_2']:
                                    flag1=homename.lower()==t['gooooal_1'].lower() and awayname.lower()==t['gooooal_2'].lower()
                                    flag2=homename.lower()==t['gooooal_2'].lower() and awayname.lower()==t['gooooal_1'].lower()
                                else:
                                    flag1=flag2=False
                                flag3=Func.check_day_diff(matchtime,t['matchdatetime'])
                                if (flag1 or flag2) and flag3:
                                    limit1=limit2=limit3=0
                                    if t['sourcelimit'] and int(t['sourcelimit'])==1 and t['sourceoddslimit']:
                                        source_arr=t['sourceoddslimit'].split(',')
                                        for v in source_arr:
                                            if v=='1':
                                                limit1=1
                                            elif v=='2':
                                                limit2=1
                                            elif v=='3':
                                                limit3=1
                                    #ƥ��ɹ���־
                                    isexists=1
                                    if flag1:
                                        isreverse=0
                                    else:
                                        isreverse=1                            
                                    row={'fixtureid':t['fixtureid'],
                                        'isreverse':isreverse,
                                        'islottype':int(t['islottyle']),
                                        'isbeidan':int(t['isbeidan']),
                                        'limit1':limit1,
                                        'limit2':limit2,
                                        'limit3':limit3,
                                        'gooooal_id':matchid,
                                        'hometeam':t['gooooal_1'],
                                        'awayteam':t['gooooal_2'],
                                        'matchdate':t['matchdatetime']
                                    }
                                    result[t['fixtureid']]=row
                                    data_arr.append({'matchname':leaguename,'fixtureid':t['fixtureid'],'homename':homename,'awayname':awayname,'matchdate':matchtime,'url':Func.getPath('gooooal_url')%matchid,'ismatch':1,'istoday':1})
                                    break
                            if isexists==0:
                                data_arr.append({'matchname':leaguename,'fixtureid':'','homename':homename,'awayname':awayname,'matchdate':matchtime,'url':Func.getPath('gooooal_url')%matchid,'ismatch':0,'istoday':1})
                    except Exception,e:
                        Func.write_log('[thread:gooooal_todaymatch]����ҳ������쳣:%s'%traceback.format_exc())
            #�����ݱ��浽xml��
            if Post.post_gooooal_xml(result):
                self.data=data_arr
        except Exception,e:
            Func.write_log('[thread:gooooal_todaymatch]����%sҳ������쳣:%s'%(url,traceback.format_exc()))