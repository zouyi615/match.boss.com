#coding:gbk
import time,curl,traceback,re
from threading import Thread
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''ѩԵ��δ������ץȡ'''
class gooooal_futurematch(Thread):
    def __init__(self):
        Thread.__init__(self)
        self.isRun=True
        self.data=[]
        self.request_times=0
    def run(self):
        Func.write_log('[thread:gooooal_futurematch]�߳̿���!')
        while self.isRun:
            self.do()
            time.sleep(Func.getThreadSleep('gooooal_futurematch'))
    def stop(self):
        self.isRun=False
        Func.write_log('[thread:gooooal_futurematch]�߳�ֹͣ!')
    def getData(self):
        return self.data
    
    '''��ȡҳ������'''
    def request_once(self,url,timeout=10):
        try:
            content=''
            request=curl.Curl()
            #���ó�ʱʱ��
            request.set_timeout(timeout)
            content=request.get(url)
            request.close()
            self.request_times=0
        except Exception,e:
            if self.request_times<3:
                self.request_times+=1
                return self.request_once(url,timeout)
            else:
                self.request_times=0
                Func.write_log('[thread:gooooal_futurematch]request_once����%sҳ������쳣:%s'%(url,traceback.format_exc()))
        return content
    
    def do(self):
        try:
            data_arr=[]
            result={}
            #--------------��ȡ����Դ����------------#
            url=Func.getPath('gooooal_futurematch')
            content=self.request_once(url,30).decode('utf-8','ignore').encode('gbk')
            pattern='<tr\s*lid="[\d]+"[^>]+>[^<>]*<td[^>]+><span><a[^>]+>([^>]+)</a></span></td>[^<>]*<td>([^>]+)</td>[^<>]*<td>[^>]+</td>[^<>]*<td[^>]+>[\s\S]+?<a[^>]+>([^>]+)</a>[^<>]*</td>[^<>]*<td[^>]+>[^<>]+<a[^>]+>VS</a>[^<>]*</td>[^<>]*<td[^>]+>[^<>]*<a[^>]+>([^<>]+)</a>[\s\S]+?</td>[^<>]*<td>[^>]+<a\s*href="javascript:toHot\(([\d]+)\)"[^>]+>'
            ct_tmp=re.findall(r'%s'%pattern,content)
            timestamp=time.time()
            if len(ct_tmp)>0:
                list=Db_Odds().getgooooalfixture(time.strftime('%Y-%m-%d %H:%M:00',time.localtime(timestamp)),time.strftime('%Y-%m-%d 12:00:00',time.localtime(timestamp+7*24*3600)))
                for v in ct_tmp:
                    try:
                        leaguename=v[0].replace("\n\t",'').strip()#������
                        matchtime_tmp=v[1].replace("\n\t",'').strip()#����ʱ��
                        homename=v[2].replace("\n\t",'').strip()#������
                        awayname=v[3].replace("\n\t",'').strip()#�Ͷ���
                        matchid=int(v[4].replace("\n\t",'').strip())#����id
                        month=int(matchtime_tmp.split('-')[0])
                        if month<int(time.strftime('%m',time.localtime(timestamp))):
                            year=int(time.strftime('%Y',time.localtime(timestamp)))+1
                        else:
                            year=int(time.strftime('%Y',time.localtime(timestamp)))
                        _t=time.mktime(time.strptime('%s-%s'%(year,matchtime_tmp),'%Y-%m-%d %H:%M'))
                        matchtime=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(_t))
                        isexists=0#Ĭ�����ò�����
                        for t in list:
                            #-----������Դ�����Ͷ���������ʱ�������ݿ���жԱ�-----#
                            if t['gooooal_1'] and t['gooooal_2']:
                                flag1=homename.lower()==t['gooooal_1'].lower() and awayname.lower()==t['gooooal_2'].lower()
                                flag2=homename.lower()==t['gooooal_2'].lower() and awayname.lower()==t['gooooal_1'].lower()
                            else:
                                flag1=flag2=False
#                             flag1=str(homename).lower()==str(t['gooooal_1']).lower() and str(awayname).lower()==str(t['gooooal_2']).lower()
#                             flag2=str(homename).lower()==str(t['gooooal_2']).lower() and str(awayname).lower()==str(t['gooooal_1']).lower()
                            flag3=Func.check_day_diff(matchtime,t['matchdatetime'])
                            if (flag1 or flag2) and flag3:
                                limit1=limit2=limit3=0
                                if t['sourcelimit'] and int(t['sourcelimit'])==1 and t['sourceoddslimit']:
                                    source_arr=t['sourceoddslimit'].split(',')
                                    for v in source_arr:
                                        if v=='1':
                                            limit1=1
                                        elif v=='2':
                                            limit2=1
                                        elif v=='3':
                                            limit3=1
                                #ƥ��ɹ���־
                                isexists=1
                                if flag1:
                                    isreverse=0
                                else:
                                    isreverse=1
                                row={'fixtureid':t['fixtureid'],
                                    'isreverse':isreverse,
                                    'islottype':int(t['islottyle']),
                                    'isbeidan':int(t['isbeidan']),
                                    'limit1':limit1,
                                    'limit2':limit2,
                                    'limit3':limit3,
                                    'gooooal_id':matchid,
                                    'hometeam':t['gooooal_1'],
                                    'awayteam':t['gooooal_2'],
                                    'matchdate':t['matchdatetime']
                                }
                                result[t['fixtureid']]=row
                                data_arr.append({'matchname':leaguename,'fixtureid':t['fixtureid'],'homename':homename,'awayname':awayname,'matchdate':matchtime,'url':Func.getPath('gooooal_url')%matchid,'ismatch':1,'istoday':0})
                                break
                        if isexists==0:
                            data_arr.append({'matchname':leaguename,'fixtureid':'','homename':homename,'awayname':awayname,'matchdate':matchtime,'url':Func.getPath('gooooal_url')%matchid,'ismatch':0,'istoday':0})
                    except Exception,e:
                        Func.write_log('[thread:gooooal_futurematch]����ҳ������쳣:%s'%(traceback.format_exc()))
            #�����ݱ��浽xml��
            if Post.post_gooooal_xml(result,'future'):
                self.data=data_arr
            data_arr=None
            result=None
        except Exception,e:
            Func.write_log('[thread:gooooal_futurematch]����%sҳ������쳣:%s'%(url,traceback.format_exc()))