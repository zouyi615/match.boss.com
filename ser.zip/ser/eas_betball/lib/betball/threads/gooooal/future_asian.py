#coding:gbk
from betball.threads.base import base
from betball.func import post as Post
from betball.func import common as Func
from betball.db.odds import Db_Odds
import time,re,traceback
'''��ȡδ��ŷ����Ϣ'''
class gooooal_future_asian(base):
    def __init__(self):
        super(gooooal_future_asian,self).__init__('gooooal_future_asian')
    
    def do(self):
        try:
            content=self.fopen(self.getConfigPath('gooooal_futurexml'))
            if content:
                 #����xml����
                xml=self.parsexml(content)
                #��ȡxml m�ڵ�
                if xml:
                    node_arr=xml.getElementsByTagName('m')
                else:
                    node_arr=[]
                
                sp_time=str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
                
                #���ͽӿ�����
                odds_arr=[]
                live_arr=[]
                sohu_arr=[]#�Ѻ��ӿ�
                
                log_arr=[]#��¼δƥ��Ĺ�˾��
                log_companyname=[]
                for node in node_arr:
                    try:
                        matchdate=node.getElementsByTagName('matchdate')[0].firstChild.nodeValue
                        if node.getAttribute('limit2')!='0' or matchdate<=sp_time:
                            continue
                        fixtureid=int(node.getElementsByTagName('fixtureid')[0].firstChild.nodeValue)
                        gooooal_id=int(node.getElementsByTagName('gooooal_id')[0].firstChild.nodeValue)
                        isreverse=int(node.getElementsByTagName('isreverse')[0].firstChild.nodeValue)
                        isbeidan=int(node.getAttribute('isbeidan'))
                        islottype=int(node.getAttribute('islottype'))
                        
                        #---------��ȡ����Դ������Ϣ---------#
                        url=self.getConfigPath('gooooal_asian')%(str(gooooal_id)[0:-3],gooooal_id,time.time())
                        ct_tmp=self.fopen(url).decode('utf-8','ignore').encode('gbk').strip().split('$')
                        if len(ct_tmp)==3:
                            #------��ȡ���ʹ�˾��Ϣ-------#
                            company_arr={}
                            company_tmp=ct_tmp[1].split('~')
                            for c in company_tmp:
                                try:
                                    info=c.split('^')
                                    if len(info)==7:
                                        cid=int(info[0])
                                        company_arr[cid]=info[2].strip()
                                except:
                                    self.writelog('[thread:gooooal_future_asian]����%sҳ�湫˾���ݳ����쳣:%s'%(url,traceback.format_exc()))
                                    
                            #-----��ȡ�������-------#
                            odds_tmp=ct_tmp[2].split('~')
                            list={}
                            for o in odds_tmp:
                                try:
                                    info=o.split('^')
                                    if len(info)==8 and int(info[1])==1 and int(info[7])==0:
                                        #��˾id
                                        cid=int(info[0])                 
                                        #����ʱ���
                                        timestamp=int(info[2])
                                        #��������
                                        sp=float(info[3].strip())-1
                                        sp_f='%.3f'%sp
                                        #�Ͷ�����
                                        xp=float(info[5].strip())-1
                                        xp_f='%.3f'%xp
                                        
                                        #���˷Ƿ���¼�����������Ϣ
#                                        flag=not company_arr.has_key(cid) or company_arr[cid]=='����'
                                        flag=not company_arr.has_key(cid)
                                        #����������ϢΪ�յ�����
                                        flag=flag or sp_f=='0.000' or xp_f=='0.000' or sp<0 or xp<0
                                        #�����������ݣ�ֻ��ȡ����һ������
                                        flag=flag or (list.has_key(cid) and timestamp<=list[cid]['time'])
                                        if flag:
                                            continue
                                        #�жϹ�˾���Ƿ����
                                        companyname=company_arr[cid]
                                        cp_info=Db_Odds().getGooooalInfoByCompany(companyname)
                                        if cp_info and int(cp_info['source_gooooal_a'])==1:
                                            companyid=int(cp_info['id'])#���ݿ⹫˾id                                            
                                            istosohu=int(cp_info['istosohu'])#�Ƿ�ͬ�����Ѻ�                                            
                                            #����
                                            handi_tmp=int(info[4])
                                            handiname=Func.get_gooooal_handi(handi_tmp,isreverse)
                                            handicaplineid=0
                                            if handiname!='':
                                                handicaplineid=Db_Odds().gethandicaplineid(handiname)
                                            if handicaplineid!=0:
                                                list[cid]={
                                                    'sp':sp,
                                                    'handicaplineid':handicaplineid,
                                                    'handicaplinename':handiname,
                                                    'xp':xp,
                                                    'time':timestamp,
                                                    'companyid':companyid,
                                                    'istosohu':istosohu,
                                                    'companyname':companyname
                                                }
                                        elif not cp_info and companyname not in log_companyname:
                                            log_companyname.append(companyname)
                                            log_arr.append({'url':url,'companyname':companyname})
                                except:
                                    self.writelog('[thread:gooooal_future_asian]����%sҳ���������ݳ����쳣:%s'%(url,traceback.format_exc())) 
                            
                            #-------����������Ϣ-------#
                            for t in list:
                                sp=list[t]['sp']
                                handicaplineid=list[t]['handicaplineid']
                                xp=list[t]['xp']
                                pk=list[t]['handicaplinename']
                                companyid=list[t]['companyid']
                                companyname=list[t]['companyname']
                                istosohu=list[t]['istosohu']
                                result=Db_Odds().add_asian(fixtureid,companyid,sp,handicaplineid,xp)
                                if result==1:
                                    if companyid in [2,3,5,6,9,16,277,280]:
                                        odds_arr.append({'fixtureid':fixtureid,'companyid':companyid,'sw1':'%.3f'%float(sp),'handicaplinename':pk,'sw2':'%.3f'%float(xp)})
                                    if companyid in [2,3,5,6,9,16,276,277,280]:
                                        live_arr.append({'fixtureid':fixtureid,'companyid':companyid,'sw1':'%.3f'%float(sp),'handicaplinename':pk,'sw2':'%.3f'%float(xp)})
                                    if (islottype==1 or isbeidan==1) and istosohu==1:
                                        sohu_arr.append({'fixtureid':fixtureid,'companyid':companyid,'sw1':sp,'handicaplineid':handicaplineid,'sw2':xp})
                                elif result==-1:
                                    self.writelog('[thread:gooooal_future_asian]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,companyname,companyid))
                    except:
                        self.writelog('[thread:gooooal_future_asian]�������ݳ����쳣:%s'%traceback.format_exc())
                #��ӿ���������
                Post.upload_asian_xml(odds_arr)
                Post.upload_asian_xml(live_arr,2)
                Post.post_sohu_data('asian',sohu_arr)
                Post.post_gooooal_log(log_arr)
                odds_arr=live_arr=sohu_arr=list=None
        except Exception,e:
            self.writelog('[thread:gooooal_future_asian]�̳߳����쳣:%s'%traceback.format_exc())