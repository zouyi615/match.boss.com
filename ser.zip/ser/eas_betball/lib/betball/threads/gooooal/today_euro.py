#coding:gbk
from betball.threads.base import base
from betball.func import post as Post
from betball.func import common as Func
from betball.db.odds import Db_Odds
import time,re,traceback
'''ץȡ����ŷ����Ϣ'''
class gooooal_today_euro(base):
    def __init__(self):
        super(gooooal_today_euro,self).__init__('gooooal_today_euro')
    
    def do(self):
        try:
            content=self.fopen(self.getConfigPath('gooooal_todayxml'))
            if content:
                 #����xml����
                xml=self.parsexml(content)
                #��ȡxml m�ڵ�
                if xml:
                    node_arr=xml.getElementsByTagName('m')
                else:
                    node_arr=[]
                
#                 sp_time=str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
                #���ͽӿ�����
                odds_arr=[]
                live_arr=[]
                sohu_arr=[]#�Ѻ��ӿ�
                
                log_arr=[]#��¼δƥ��Ĺ�˾��
                log_companyname=[]
                for node in node_arr:
                    try:
                        matchdate=node.getElementsByTagName('matchdate')[0].firstChild.nodeValue
                        if node.getAttribute('limit2')!='0' or matchdate<=str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))):
                            continue
                        fixtureid=int(node.getElementsByTagName('fixtureid')[0].firstChild.nodeValue)
                        gooooal_id=int(node.getElementsByTagName('gooooal_id')[0].firstChild.nodeValue)
                        isreverse=int(node.getElementsByTagName('isreverse')[0].firstChild.nodeValue)
                        isbeidan=int(node.getAttribute('isbeidan'))
                        islottype=int(node.getAttribute('islottype'))
                        
                        url=self.getConfigPath('gooooal_euro')%(str(gooooal_id)[0:-3],gooooal_id,time.time())
                        ct_tmp=self.fopen(url).decode('utf-8','ignore').encode('gbk').strip().split('$')
                        is_update=False
                        if len(ct_tmp)==3:
                            #------��ȡ���ʹ�˾��Ϣ-------#
                            company_arr={}
                            company_tmp=ct_tmp[1].split('~')
                            for c in company_tmp:
                                try:
                                    info=c.split('^')
                                    if len(info)==7:
                                        cid=int(info[0])
                                        company_arr[cid]=info[2].strip()
                                except:
                                    self.writelog('[thread:gooooal_today_euro]����%sҳ�湫˾���ݳ����쳣:%s'%(url,traceback.format_exc()))
                                    
                            #-----��ȡ�������-------#
                            odds_tmp=ct_tmp[2].split('~')
                            list={}
                            for o in odds_tmp:
                                try:
                                    info=o.split('^')
                                    if len(info)==8 and int(info[1])==1 and int(info[7])==0:
                                        #��˾id
                                        cid=int(info[0])   
                                        #����ʱ���
                                        timestamp=int(info[2])
                                        if isreverse==1:
                                            #ʤ����
                                            win=info[5].strip()
                                            #ƽ����
                                            draw=info[4].strip()
                                            #������
                                            lost=info[3].strip()
                                        else:
                                            #ʤ����
                                            win=info[3].strip()
                                            #ƽ����
                                            draw=info[4].strip()
                                            #������
                                            lost=info[5].strip()
                                        #�����ϰ�ŷ�⼰������ϢΪ0������
                                        flag=not company_arr.has_key(cid) or '%.2f'%float(win)=='0.00' or '%.2f'%float(draw)=='0.00' or '%.2f'%float(lost)=='0.00'
                                        #�����������ݣ�ֻ��ȡ����һ������
                                        flag=flag or (list.has_key(cid) and timestamp<=list[cid]['time'])
                                        if flag:
                                            continue
                                        #�жϹ�˾���Ƿ����
                                        companyname=company_arr[cid]
                                        cp_info=Db_Odds().getGooooalInfoByCompany(companyname)
                                        if cp_info and int(cp_info['source_gooooal'])==1:                                         
                                            list[cid]={
                                                'time':timestamp,
                                                'companyid':int(cp_info['id']),#���ݿ⹫˾id 
                                                'istosohu':int(cp_info['istosohu']),#�Ƿ�ͬ�����Ѻ�
                                                'companyname':companyname,
                                                'win':win,
                                                'draw':draw,
                                                'lost':lost
                                            }
                                        elif not cp_info and companyname not in log_companyname:
                                            log_companyname.append(companyname)
                                            log_arr.append({'url':url,'companyname':companyname})
                                except:
                                    self.writelog('[thread:gooooal_today_euro]����%sҳ���������ݳ����쳣:%s'%(url,traceback.format_exc()))
                            #-------����������Ϣ-------#
                            for t in list:
                                companyid=list[t]['companyid']
                                companyname=list[t]['companyname']
                                win='%.2f'%float(list[t]['win'])
                                draw='%.2f'%float(list[t]['draw'])
                                lost='%.2f'%float(list[t]['lost'])
                                istosohu=list[t]['istosohu']
                                result=Db_Odds().add_odds(fixtureid,companyid,win,draw,lost)
                                if result==1:
                                    is_update=True
                                    if companyid in [2,3,4,5,6,7,8,9,10,11,15,18,280]:
                                        odds_arr.append({'fixtureid':fixtureid,'companyid':companyid,'win':win,'draw':draw,'lost':lost})
                                    if companyid in [2,3,4,5,6,7,8,9,10,11,15,276,293]:
                                        live_arr.append({'fixtureid':fixtureid,'companyid':companyid,'win':win,'draw':draw,'lost':lost})
                                    if (islottype==1 or isbeidan==1) and istosohu==1:
                                        sohu_arr.append({'fixtureid':fixtureid,'companyid':companyid,'win':win,'draw':draw,'lost':lost})
                                elif result==-1:
                                    self.writelog('[thread:gooooal_today_euro]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,companyname,companyid))                  
                        if is_update:
                            Func.Sc_Interface('euro',fixtureid)
                    except:
                        self.writelog('[thread:gooooal_today_euro]�������ݳ����쳣:%s'%traceback.format_exc())
                Post.upload_odds_xml(odds_arr)
                Post.upload_odds_xml(live_arr,2)
                Post.post_sohu_data('europe',sohu_arr)
                Post.post_gooooal_log(log_arr)
                odds_arr=live_arr=sohu_arr=list=log_companyname=None 
        except:
            self.writelog('[thread:gooooal_today_euro]�̳߳����쳣:%s'%traceback.format_exc())  