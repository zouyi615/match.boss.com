#coding:gbk
from betball.threads.base import base
from betball.func import post as Post
from betball.func import common as Func
from betball.db.odds import Db_Odds
import time,re,traceback
'''ץȡδ����С������Ϣ'''
class gooooal_future_dx(base):
    def __init__(self):
        super(gooooal_future_dx,self).__init__('gooooal_future_dx')
    
    def do(self):
        try:
            content=self.fopen(self.getConfigPath('gooooal_futurexml'))
            if content:
                 #����xml����
                xml=self.parsexml(content)
                #��ȡxml m�ڵ�
                if xml:
                    node_arr=xml.getElementsByTagName('m')
                else:
                    node_arr=[]
                
                sp_time=str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()-2*24*3600)))
                #���ͽӿ�����
                dx_arr=[]
                
                log_arr=[]#��¼δƥ��Ĺ�˾��
                log_companyname=[]
                for node in node_arr:
                    try:
                        matchdate=node.getElementsByTagName('matchdate')[0].firstChild.nodeValue
                        if node.getAttribute('limit2')!='0' or matchdate<=sp_time:
                            continue
                        fixtureid=int(node.getElementsByTagName('fixtureid')[0].firstChild.nodeValue)
                        gooooal_id=int(node.getElementsByTagName('gooooal_id')[0].firstChild.nodeValue)
                        isreverse=int(node.getElementsByTagName('isreverse')[0].firstChild.nodeValue)
                        isbeidan=int(node.getAttribute('isbeidan'))
                        islottype=int(node.getAttribute('islottype'))
                        
                        url=self.getConfigPath('gooooal_dx')%(str(gooooal_id)[0:-3],gooooal_id,time.time())
                        
                        ct_tmp=self.fopen(url).decode('utf-8','ignore').encode('gbk').strip().split('$')
                        if len(ct_tmp)==3:
                            #------��ȡ���ʹ�˾��Ϣ-------#
                            company_arr={}
                            company_tmp=ct_tmp[1].split('~')
                            for c in company_tmp:
                                try:
                                    info=c.split('^')
                                    if len(info)==7:
                                        cid=int(info[0])
                                        company_arr[cid]=info[2].strip()
                                except:
                                    self.writelog('[thread:gooooal_future_dx]����%sҳ�湫˾���ݳ����쳣:%s'%(url,traceback.format_exc()))
                            
                            #-----��ȡ�������-------#
                            odds_tmp=ct_tmp[2].split('~')
                            list={}
                            for o in odds_tmp:
                                try:
                                    info=o.split('^')
                                    if len(info)==8 and int(info[1])==1 and int(info[7])==0:
                                        #��˾id
                                        cid=int(info[0])   
                                        #����ʱ���
                                        timestamp=int(info[2])
                                        #��ȡ������Ϣ
                                        pk=Func.get_gooooal_pka(int(info[4]))
                                        if isreverse==0:
                                            big=float(info[3].strip())-1
                                            small=float(info[5].strip())-1
                                        else:
                                            big=float(info[5].strip())-1
                                            small=float(info[3].strip())-1
                                            if pk.find('/')!=-1:
                                                tmp=pk.split('/')
                                                pk='%s/%s'%(tmp[1],tmp[0])
                                        #����������ϢΪ�յ�����
                                        flag=not company_arr.has_key(cid) or pk=='' or '%.2f'%float(big)=='0.00' or '%.2f'%float(small)=='0.00'
                                        #�����������ݣ�ֻ��ȡ����һ������
                                        flag=flag or (list.has_key(cid) and timestamp<=list[cid]['time'])
                                        if flag:
                                            continue
                                        #�жϹ�˾���Ƿ����
                                        companyname=company_arr[cid]
                                        cp_info=Db_Odds().getGooooalInfoByCompany(companyname)
                                        if cp_info and int(cp_info['source_gooooal_a'])==1:      
                                            list[cid]={
                                                'time':timestamp,
                                                'companyid':int(cp_info['id']),#���ݿ⹫˾id 
                                                'companyname':companyname,
                                                'big':big,
                                                'pk':pk,
                                                'small':small
                                            }
                                        elif not cp_info and companyname not in log_companyname:
                                            log_companyname.append(companyname)
                                            log_arr.append({'url':url,'companyname':companyname})
                                except:
                                    self.writelog('[thread:gooooal_future_dx]����%sҳ���������ݳ����쳣:%s'%(url,traceback.format_exc()))
                            #-------����������Ϣ-------#
                            for t in list:
                                companyid=list[t]['companyid']
                                companyname=list[t]['companyname']
                                big='%.2f'%float(list[t]['big'])
                                pk=list[t]['pk']
                                small='%.2f'%float(list[t]['small'])
                                result=Db_Odds().add_bigsmall(fixtureid,companyid,big,pk,small)
                                if result==1 and companyid in Func.getCompany('dx'):
                                    dx_arr.append({'fixtureid':fixtureid,'companyid':companyid,'big':big,'handiname':pk,'small':small})
                                elif result==-1:
                                    self.writelog('[thread:gooooal_future_dx]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,companyname,companyid))
                    except:
                        self.writelog('[thread:gooooal_future_dx]�������ݳ����쳣:%s'%traceback.format_exc())
                #��ӿ���������
                Post.post_big_xml(dx_arr)
                Post.post_gooooal_log(log_arr)
                dx_arr=log_arr=log_companyname=list=None
        except:
            self.writelog('[thread:gooooal_future_dx]�̳߳����쳣:%s'%traceback.format_exc())