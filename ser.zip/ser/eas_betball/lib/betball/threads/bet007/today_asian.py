#coding:gbk
from betball.threads.base import base
from betball.func import post as Post
from betball.db.odds import Db_Odds
from betball.func import common as Func
import time,re
class bet007_today_asian(base):
    def __init__(self):
        super(bet007_today_asian,self).__init__('bet007_today_asian')
    
    def do(self):
        try:
            content=self.fopen(self.getConfigPath('bet007_todayxml'))
            if content:
                 #����xml����
                xml=self.parsexml(content)
                #��ȡxml m�ڵ�
                if xml:
                    node_arr=xml.getElementsByTagName('m')
                else:
                    node_arr=[]
#                 sp_time=str(time.strftime('%Y%m%d%H%M',time.localtime()))
                
                #�������ʽ
                team_pattern=re.compile(r"(?i)&team1=([^&]+)&team2=([^']+)")
                cp_pattern=re.compile(r"(?i)<tr align=center bgColor='[^']+'><td height='[^']+'>(.+?)</td><td[^>]*>[^<]*</td><td[^>]*>[^<]*</td><td[^>]*>[^<]*</td><td[^>]*>(.*?)</td><td[^>]*>(.*?)</td><td[^>]*>(.*?)</td>")
                
                #���ͽӿ�����
                odds_arr=[]
                live_arr=[]
                sohu_arr=[]#�Ѻ��ӿ�
                
                #��¼δƥ��Ĺ�˾��
                log_arr=[]
                
                for node in node_arr:
                    matchdate=node.getElementsByTagName('MatchDate')[0].firstChild.nodeValue
                    if node.getAttribute('Limit2')!='0' or matchdate<=str(time.strftime('%Y%m%d%H%M',time.localtime())):
                        continue
                    fixtureid=int(node.getElementsByTagName('MatchID')[0].firstChild.nodeValue)
                    bet007_matchid=int(node.getElementsByTagName('Bet007_MatchID')[0].firstChild.nodeValue)
                    isreverse=int(node.getElementsByTagName('IsReverse')[0].firstChild.nodeValue)
                    isbeidan=int(node.getAttribute('IsBeiDan'))
                    islottype=int(node.getAttribute('IsLotType'))
                    
                    hometeam_bet007=node.getElementsByTagName('HomeName')[0].firstChild.nodeValue.split(',')[1].encode('gbk')
                    awayteam_bet007=node.getElementsByTagName('AwayName')[0].firstChild.nodeValue.split(',')[1].encode('gbk')
                    
                    url=self.getConfigPath('bet007_asian')%bet007_matchid
                    ct_tmp=self.fopen(url)
                                        
                    #ƥ�������
                    tmp=team_pattern.findall(ct_tmp)
                    if tmp:
                        home_str=tmp[0][0].split('(')[0]
                        away_str=tmp[0][1].split('(')[0]
                        if hometeam_bet007==home_str and awayteam_bet007==away_str:
                            isreverse=0
                        elif hometeam_bet007==away_str and awayteam_bet007==home_str:
                            isreverse=1
                    cp_tmp=cp_pattern.findall(ct_tmp)
                    is_update=False
                    for r in cp_tmp:
                        cp_name=r[0].split('<span')[0].split('/')[0].strip()
#                        if cp_name=='����':
#                            continue
                        info=Db_Odds().getAsianInfoByCompany(cp_name)
                        if info and int(info['source_bet007_a'])==1:
                            companyid=int(info['id'])
                            istosohu=int(info['istosohu'])
                            if isreverse==0:
                                sp=r[1]
                                xp=r[3]
                            else:
                                sp=r[3]
                                xp=r[1]
                            if sp.find('</font>')!=-1:
                                tmp_pattern=re.compile(r'<font[^>]*?>([^<]*?)</font>')
                                tmp=tmp_pattern.findall(sp)
                                if tmp:
                                    sp=tmp[0]
                            if xp.find('</font>')!=-1:
                                tmp_pattern=re.compile(r'<font[^>]*?>([^<]*?)</font>')
                                tmp=tmp_pattern.findall(xp)
                                if tmp:
                                    xp=tmp[0]
                            pk=r[2].strip()
                            if isreverse==1 and pk!='ƽ��':
                                if pk.find('��')!=-1:
                                    pk=pk[2:]
                                else:
                                    pk='��'+pk;
                            pk=pk.replace('��','')                     
                            handicaplineid=Db_Odds().gethandicaplineid(pk)
                            if handicaplineid==0:
                                continue
                            result=Db_Odds().add_asian(fixtureid,companyid,sp,handicaplineid,xp)
                            if result==1:
                                is_update=True
                                if companyid in [2,3,5,6,9,16,277,280]:
                                    odds_arr.append({'fixtureid':fixtureid,'companyid':companyid,'sw1':'%.3f'%float(sp),'handicaplinename':pk,'sw2':'%.3f'%float(xp)})
                                if companyid in [2,3,5,6,9,16,276,277,280]:
                                    live_arr.append({'fixtureid':fixtureid,'companyid':companyid,'sw1':'%.3f'%float(sp),'handicaplinename':pk,'sw2':'%.3f'%float(xp)})
                                if (islottype==1 or isbeidan==1) and istosohu==1:
                                    sohu_arr.append({'fixtureid':fixtureid,'companyid':companyid,'sw1':sp,'handicaplineid':handicaplineid,'sw2':xp})
                            elif result==-1:
                                self.writelog('[thread:bet007_today_asian]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,cp_name,companyid))
                        elif not info:
#                            self.writelog('[thread:bet007_today_asian]%s:δ��ƥ�����ball365��˾��[url:%s]'%(cp_name,url)) 
                            log_arr.append({'url':url,'companyname':cp_name})
                    
                    if is_update:
                        Func.Sc_Interface('asian',fixtureid)
                             
                #��ӿ���������
                Post.upload_asian_xml(odds_arr)
                Post.upload_asian_xml(live_arr,2)
                Post.post_sohu_data('asian',sohu_arr)
                Post.post_bet007_log(log_arr)
                odds_arr=None
                live_arr=None
                sohu_arr=None
                list=None
        except Exception,e:
            self.writelog('[thread:bet007_today_asian]�̳߳����쳣:%s'%e)