#coding:gbk
from betball.threads.base import base
from betball.db.odds import Db_Odds
from betball.func import post as Post
from betball.func import common as Func
import re,time
#��̽δ����С�����߳�
class bet007_future_dxodds(base):
    def __init__(self):
        super(bet007_future_dxodds,self).__init__('bet007_future_dxodds')
        
    def do(self):
        try:
            content=self.fopen(self.getConfigPath('bet007_futurexml'))
            if content:
                dx_arr=[]
                #��¼δƥ��Ĺ�˾��
                log_arr=[]
                
                 #����xml����
                xml=self.parsexml(content)
                #��ȡxml m�ڵ�
                if xml:
                    node_arr=xml.getElementsByTagName('m')
                else:
                    node_arr=[]
                sp_time=str(time.strftime('%Y%m%d%H%M',time.localtime()))
                
                #�������ʽ
                team_pattern=re.compile(r"<td[^>]*>([^v]*?)vs([^<]*)<a[^>]*>����</a></td>")
                cp_pattern=re.compile(r"(?i)<tr align=center bgColor='[^']+'><td height='[^']+'>(.+?)</td><td[^>]*>[^<]*</td><td[^>]*>[^<]*</td><td[^>]*>[^<]*</td><td[^>]*>(.*?)</td><td[^>]*>(.*?)</td><td[^>]*>(.*?)</td>")
                for node in node_arr:
                    matchdate=node.getElementsByTagName('MatchDate')[0].firstChild.nodeValue
                    if node.getAttribute('Limit2')!='0' or matchdate<=sp_time:
                        continue
                    fixtureid=int(node.getElementsByTagName('MatchID')[0].firstChild.nodeValue)
                    bet007_matchid=int(node.getElementsByTagName('Bet007_MatchID')[0].firstChild.nodeValue)
                    isreverse=int(node.getElementsByTagName('IsReverse')[0].firstChild.nodeValue)
                    
                    hometeam_bet007=node.getElementsByTagName('HomeName')[0].firstChild.nodeValue.split(',')[1].encode('gbk')
                    awayteam_bet007=node.getElementsByTagName('AwayName')[0].firstChild.nodeValue.split(',')[1].encode('gbk')
                    url=self.getConfigPath('bet007_bigsmall')%bet007_matchid
                    ct_tmp=self.fopen(url)
                    team_tmp=team_pattern.findall(ct_tmp)
                    if team_tmp:
                        home_str=team_tmp[0][0].replace('&nbsp;','').strip()
                        away_str=team_tmp[0][1].replace('&nbsp;','').strip()
                        if hometeam_bet007==home_str and awayteam_bet007==away_str:
                            isreverse=0
                        elif hometeam_bet007==away_str and awayteam_bet007==home_str:
                            isreverse=1
                    cp_arr=cp_pattern.findall(ct_tmp)
                    for r in cp_arr:
                        cp_name=r[0].split('<span')[0].split('/')[0].strip()
#                        if cp_name in ['����','���ֵ','��Сֵ']:
                        if cp_name in ['���ֵ','��Сֵ']:
                            continue
                        info=Db_Odds().getAsianInfoByCompany(cp_name)
                        if info and int(info['source_bet007_a'])==1:
                            companyid=int(info['id'])
                            istosohu=int(info['istosohu'])
                            if isreverse==0:
                                big=r[1]
                                small=r[3]
                            else:
                                big=r[3]
                                small=r[1]
                            if big.find('</font>')!=-1:
                                tmp_pattern=re.compile(r'<font[^>]*?>([^<]*?)</font>')
                                tmp=tmp_pattern.findall(big)
                                if tmp:
                                    big=tmp[0]
                            if small.find('</font>')!=-1:
                                tmp_pattern=re.compile(r'<font[^>]*?>([^<]*?)</font>')
                                tmp=tmp_pattern.findall(small)
                                if tmp:
                                    small=tmp[0]
                            pk=r[2].strip()
                            if isreverse==1 and pk.find('/')!=-1:
                                tmp=pk.split('/')
                                pk='%s/%s'%(tmp[1],tmp[0])
                            if len(pk)==0:
                                continue
                            result=Db_Odds().add_bigsmall(fixtureid,companyid,big,pk,small)
                            if result==-1:
                                self.writelog('[thread:bet007_future_dxodds]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,cp_name,companyid))
                            elif result==1:
                                if companyid in Func.getCompany('dx'):
                                    dx_arr.append({'fixtureid':fixtureid,'companyid':companyid,'big':big,'handiname':pk,'small':small})                       
                        elif not info:
                            log_arr.append({'url':url,'companyname':cp_name})
                Post.post_big_xml(dx_arr)
                Post.post_bet007_log(log_arr)
        except Exception,e:
            self.writelog('[thread:bet007_future_dxodds]�̳߳����쳣:%s'%e)