#coding:gbk
from betball.threads.base import base
from betball.db.odds import Db_Odds
from betball.func import post as Post
from betball.func import common as Func
import time,re
'''��̽����ŷ���߳�'''
class bet007_today_odds(base):
    def __init__(self):
        super(bet007_today_odds,self).__init__('bet007_today_odds')
        
    def do(self):
        try:
            content=self.fopen(self.getConfigPath('bet007_todayxml'))
            if content:
                #����xml����
                xml=self.parsexml(content)
                #��ȡxml m�ڵ�
                if xml:
                    node_arr=xml.getElementsByTagName('m')
                else:
                    node_arr=[]                
#                 pre_day=str(time.strftime('%Y%m%d%H%M',time.localtime(time.time()-2*24*3600)))   
#                 sp_time=str(time.strftime('%Y%m%d%H%M',time.localtime()))
                
                #���ͽӿ�����
                odds_arr=[]
                live_arr=[]
                sohu_arr=[]#�Ѻ��ӿ�
                
                #��¼δƥ��Ĺ�˾��
                log_arr=[]
                
                #��������
                pattern=re.compile(r'(?i)game=Array(.+?);')
                for node in node_arr:
                    matchdate=node.getElementsByTagName('MatchDate')[0].firstChild.nodeValue
                    if node.getAttribute('Limit2')!='0' or matchdate<=str(time.strftime('%Y%m%d%H%M',time.localtime())):
                        continue
                    fixtureid=int(node.getElementsByTagName('MatchID')[0].firstChild.nodeValue)
                    bet007_matchid=int(node.getElementsByTagName('Bet007_MatchID')[0].firstChild.nodeValue)
                    isreverse=int(node.getElementsByTagName('IsReverse')[0].firstChild.nodeValue)
                    isbeidan=int(node.getAttribute('IsBeiDan'))
                    islottype=int(node.getAttribute('IsLotType'))
                    
                    url=self.getConfigPath('bet007_odds')%bet007_matchid
                    if url.find('?')!=-1:
                        url+='&_%s'%(time.time())
                    else:
                        url+='?_%s'%(time.time())
                    ct_tmp=self.fopen(url)
                    
                    ct_tmp_arr=pattern.findall(ct_tmp)
                    #δƥ�䵽
                    if not ct_tmp_arr:
                        continue
                    
                    is_update=False
                    info=ct_tmp_arr[0].decode('utf-8').encode('gbk').replace('("','').replace('")','').split('","')
                    for r in info:
                        tmp=r.split('|')
                        #���ʹ�˾����
                        cp_name=tmp[21].split('(')[0]
                        #������Ϣ
                        if tmp[10]:
                            if isreverse==0:
                                win=tmp[10]
                                draw=tmp[11]
                                lost=tmp[12]
                            else:
                                win=tmp[12]
                                draw=tmp[11]
                                lost=tmp[10]
                        else:
                            if isreverse==0:
                                win=tmp[3]
                                draw=tmp[4]
                                lost=tmp[5]
                            else:
                                win=tmp[5]
                                draw=tmp[4]
                                lost=tmp[3]
                        try:
                            win='%.2f'%float(win)
                            draw='%.2f'%float(draw)
                            lost='%.2f'%float(lost)
                            if win=='0.00' or draw=='0.00' or lost=='0.00':
                                self.writelog('[thread:bet007_today_odds]��ȡ���ʳ����쳣:win:%s,draw:%s,lost:%s;[url:%s]'%(win,draw,lost,url))
                                continue
                        except Exception,e:
                            self.writelog('[thread:bet007_today_odds]��ȡ���ʳ����쳣:win:%s,draw:%s,lost:%s;[url:%s]'%(win,draw,lost,url))
                            continue
                        cp_info=Db_Odds().getcompanybybet(cp_name)
                        if cp_info and int(cp_info['source_bet007'])==1  and win!=0 and draw!=0 and lost!=0:
#                            if int(cp_info['source_bet007'])!=1:
#                                continue
                            companyid=int(cp_info['id'])
                            istosohu=int(cp_info['istosohu'])
                            result=Db_Odds().add_odds(fixtureid,companyid,win,draw,lost)
                            if result==1:
                                is_update=True
                                if companyid in [2,3,4,5,6,7,8,9,10,11,15,18,280]:
                                    odds_arr.append({'fixtureid':fixtureid,'companyid':companyid,'win':win,'draw':draw,'lost':lost})
                                if companyid in [2,3,4,5,6,7,8,9,10,11,15,276,293]:
                                    live_arr.append({'fixtureid':fixtureid,'companyid':companyid,'win':win,'draw':draw,'lost':lost})
                                if (islottype==1 or isbeidan==1) and istosohu==1:
                                    sohu_arr.append({'fixtureid':fixtureid,'companyid':companyid,'win':win,'draw':draw,'lost':lost})
                            elif result==-1:
                                self.writelog('[thread:bet007_today_odds]�������ݿ�����쳣url:%s;companyname:%s;companyid:%s'%(url,cp_name,companyid))
                        elif not cp_info:
                            log_arr.append({'url':url,'companyname':cp_name})
                            
                    if is_update:
                        Func.Sc_Interface('euro',fixtureid)
                        
                Post.upload_odds_xml(odds_arr)
                Post.upload_odds_xml(live_arr,2)
                Post.post_sohu_data('europe',sohu_arr)
                Post.post_bet007_log(log_arr)
            else:
                self.writelog('[thread:bet007_today_odds]��ȡxml����ʧ��!')
        except Exception,e:
            self.writelog('[thread:bet007_today_odds]�̳߳����쳣:%s'%e)