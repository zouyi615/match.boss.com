#coding:gbk
from betball.threads.base import base
from betball.func import common as Func
from betball.db.odds import Db_Odds
'''����TV'''
class aomen_match_tv(base):
    def __init__(self):
        super(aomen_match_tv,self).__init__('aomen_match_tv')
    
    def do(self):
        try:
            #��fixtures.xml��ȡ��macauid��tv��Ϣ
            url=self.getConfigPath('create_interface_url')+self.getConfigPath('create_fixture_zq_xml')
            content=self.fopen(url)
            xml=self.parsexml(content)
            if not xml:
                return
            #��ȡÿ��������tv id
            mid_arr={}
            node_arr=xml.getElementsByTagName('Fixture')
            for node in node_arr:
                tv=str(node.getAttribute('tv'))
                if tv and len(tv)>1:
                    id=int(node.getAttribute('id'))
                    mid_arr[id]=tv
            #����TV�ڵ�,��ȡid��Ӧ��TV����
            tv_arr={}
            node_arr=xml.getElementsByTagName('TV')
            for node in node_arr:
                id=str(node.getAttribute('id'))
                st=str(node.getAttribute('st').encode('gbk','ignore'))
                tv_arr[id]=st
                
            if mid_arr:
                #��macauid��ȡmacauid��fixtureid���������Ϣ����ƥ��
                url=self.getConfigPath('create_interface_url')+self.getConfigPath('create_zq_xml')
                content=self.fopen(url)
                xml=self.parsexml(content)
                if xml:
                    m_node_arr=xml.getElementsByTagName('Table')
                else:
                    m_node_arr=[]
                for node in m_node_arr:
                    fixtureid=int(node.getElementsByTagName('FixtureID')[0].firstChild.nodeValue)
                    mid=int(node.getElementsByTagName('MacauID')[0].firstChild.nodeValue)
                    if mid_arr.has_key(mid):
                        sp=''
                        string=''
                        for t in mid_arr[mid].split(','):
                            if tv_arr.has_key(t):
                                string='%s%s%s'%(string,sp,tv_arr[t])
                                sp="\r\n"
                        #����TV��Ϣ
                        Db_Odds().addAomenTv(fixtureid,string)
                m_node_arr=None
            mid_arr=None
            tv_arr=None                   
        except Exception,e:
            self.writelog('[thread:aomen_match_tv]�̳߳����쳣:%s'%e)   
    