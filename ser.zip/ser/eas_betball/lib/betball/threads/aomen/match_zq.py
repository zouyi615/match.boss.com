#coding:gbk
import time
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''ƥ������'''
class aomen_match_zq(base):
    def __init__(self):
        super(aomen_match_zq,self).__init__('aomen_match_zq')
        self.data=[]
    
    def getData(self):
        return self.data
    
    def do(self):
        try:
            data_tmp_arr=[]
            url=self.getConfigPath('aome_sourceurl')
            content=self.fopen(url)
            xml=self.parsexml(content)
            if xml:
                node_arr=xml.getElementsByTagName('Fixture')
            else:
                node_arr=[]
            sp_time=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())
            result_arr=[]
            for node in node_arr:
                date_tmp=str(node.getAttribute('gt'))
                vsdate='%s-%s-%s %s:00'%(date_tmp[0:4],date_tmp[4:6],date_tmp[6:8],date_tmp[9:])
                if vsdate>sp_time:
                    id=int(node.getAttribute('id'))
                    home_am=node.getAttribute('th').encode('gbk').strip()
                    away_am=node.getAttribute('ta').encode('gbk').strip()
                    tmp=Db_Odds().getZqMatch(home_am,away_am,vsdate)
                    if tmp:
                        fixtureid=int(tmp['fixtureid'])
                        vsdate=str(tmp['vsdate'])
                        home=tmp['home']
                        away=tmp['away']
                        hometeamid=int(tmp['hometeamid'])
                        awayteamid=int(tmp['awayteamid'])
                        gbk_1=tmp['gbk_1']
                        gbk_2=tmp['gbk_2']
                        if gbk_1==away_am and gbk_2==home_am:
                            isresver=1
                        else:
                            isresver=0
                        islottyle=int(tmp['islottyle'])
                        isbeidan=int(tmp['isbeidan'])
                        
                        row={}
                        row['fixtureid']=fixtureid
                        row['matchid']=id
                        row['matchdate']=vsdate
                        row['homename']=home
                        row['awayname']=away
                        row['homeid']=hometeamid
                        row['awayid']=awayteamid
                        row['isresver']=isresver
                        row['islottyle']=islottyle
                        row['isbeidan']=isbeidan 
                        result_arr.append(row)
                        data_tmp_arr.append({'mid':id,'home':home_am,'away':away_am,'vsdate':vsdate,'ispipei':1,'fixtureid':fixtureid})
                    else:
                        data_tmp_arr.append({'mid':id,'home':home_am,'away':away_am,'vsdate':vsdate,'ispipei':0,'fixtureid':''})
            Post.post_aomen_match_zq(result_arr)
            Post.post_aomen_fixture_zq(content)  
            self.data=data_tmp_arr
            data_tmp_arr=None
            node_arr=None
            result_arr=None
            content=None
        except Exception,e:
            self.writelog('[thread:aomen_match_zq]�̳߳����쳣:%s'%e)