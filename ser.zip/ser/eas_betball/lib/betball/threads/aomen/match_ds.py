#coding:gbk
import time
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''��˫�߳�'''
class aomen_match_ds(base):
    def __init__(self):
        super(aomen_match_ds,self).__init__('aomen_match_ds')
        self.ct=''
    
    def do(self):
        try:
            url=self.getConfigPath('oddevenurl')
            am_content=self.fopen(url)
            if self.ct==am_content:
                return
            
            #��ȡ���ذ�������xml����
            mid_arr=Func.getMacauZqXml('match_ds')
            
            #��������Դ����
            xml=self.parsexml(am_content)
            if xml:
                node_arr=xml.getElementsByTagName('Fixture')
            else:
                node_arr=[]
            for node in node_arr:
                mid=int(node.getAttribute('id'))
                if mid_arr.has_key(mid) and str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))<=mid_arr[mid]['matchdate']:
                    d='%.2f'%float(node.getAttribute('oo'))
                    s='%.2f'%float(node.getAttribute('eo'))
                    result=Db_Odds().add_ds(mid_arr[mid]['fixtureid'],5,d,s)
                    if result==-1:
                        self.writelog('[thread:aomen_match_ds]�������ݿ�����쳣;fixtureid:%s;companyid:%s;d:%s;s:%s;'%(mid_arr[mid]['fixtureid'],5,d,s))
            mid_arr=None
            node_arr=None
            self.ct=am_content
        except Exception,e:
            self.writelog('[thread:aomen_match_ds]�̳߳����쳣:%s'%e)