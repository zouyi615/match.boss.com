#coding:gbk
import time
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''�ϰ볡ŷ����Ϣ'''
class aomen_match_halfeuro(base):
    def __init__(self):
        super(aomen_match_halfeuro,self).__init__('aomen_match_halfeuro')
        self.ct=''
    
    def do(self):
        try:
            url=self.getConfigPath('windrawwinfirsthalfurl')
            am_content=self.fopen(url)
            if self.ct==am_content:
                return
            #��ȡ���ذ�������xml����
            mid_arr=Func.getMacauZqXml('match_halfeuro')
            
            #��������Դ����
            xml=self.parsexml(am_content)
            if xml:
                node_arr=xml.getElementsByTagName('Fixture')
            else:
                node_arr=[]
            for node in node_arr:
                mid=int(node.getAttribute('id'))
                if mid_arr.has_key(mid) and str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))<=mid_arr[mid]['matchdate']:
                    if mid_arr[mid]['isresver']==0:
                        win=node.getAttribute('ho')
                        draw=node.getAttribute('do')
                        lost=node.getAttribute('ao')
                    else:
                        win=node.getAttribute('ao')
                        draw=node.getAttribute('do')
                        lost=node.getAttribute('ho')
                    win='%.2f'%float(win)
                    draw='%.2f'%float(draw)
                    lost='%.2f'%float(lost)
                    result=Db_Odds().add_halfodds(mid_arr[mid]['fixtureid'],5,win,draw,lost)
                    if result==-1:
                        self.writelog('[thread:aomen_match_halfeuro]�������ݿ�����쳣;fixtureid:%s;companyid:%s;win:%s;draw:%s;lost:%s'%(mid_arr[mid]['fixtureid'],5,win,draw,lost))
            mid_arr=None
            node_arr=None
            self.ct=am_content
        except Exception,e:
            self.writelog('[thread:aomen_match_halfeuro]�̳߳����쳣:%s'%e)