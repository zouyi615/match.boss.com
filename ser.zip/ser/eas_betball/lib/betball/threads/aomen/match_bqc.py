#coding:gbk
import time
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''���Ű�ȫ���߳�'''
class aomen_match_bqc(base):
    def __init__(self):
        super(aomen_match_bqc,self).__init__('aomen_match_bqc')
        self.ct=''
    
    def do(self):
        try:
            url=self.getConfigPath('halffullurl')
            am_content=self.fopen(url)
            if self.ct==am_content:
                return
            #��ȡ���ذ�������xml����
            mid_arr=Func.getMacauZqXml('match_bqc')
            
            #��������Դ����
            xml=self.parsexml(am_content)
            if xml:
                node_arr=xml.getElementsByTagName('Fixture')
            else:
                node_arr=[]
            for node in node_arr:
                mid=int(node.getAttribute('id'))
                if mid_arr.has_key(mid) and str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))<=mid_arr[mid]['matchdate']:
                    if mid_arr[mid]['isresver']==0:
                        aa=float(node.getAttribute('hh'))
                        ac=float(node.getAttribute('hd'))
                        ab=float(node.getAttribute('ha'))
                        ca=float(node.getAttribute('dh'))
                        cc=float(node.getAttribute('dd'))
                        cb=float(node.getAttribute('da'))
                        ba=float(node.getAttribute('ah'))
                        bc=float(node.getAttribute('ad'))
                        bb=float(node.getAttribute('aa'))
                    else:
                        aa=float(node.getAttribute('aa'))
                        ac=float(node.getAttribute('ad'))
                        ab=float(node.getAttribute('ah'))
                        ca=float(node.getAttribute('da'))
                        cc=float(node.getAttribute('dd'))
                        cb=float(node.getAttribute('dh'))
                        ba=float(node.getAttribute('ha'))
                        bc=float(node.getAttribute('hd'))
                        bb=float(node.getAttribute('hh'))
                    result=Db_Odds().add_bqc(mid_arr[mid]['fixtureid'],5,aa,ac,ab,ca,cc,cb,ba,bc,bb)
                    if result==-1:
                        self.writelog('[thread:aomen_match_bqc]�������ݿ�����쳣;fixtureid:%s;companyid:%s;params:%s,%s,%s,%s,%s,%s,%s,%s,%s'%(mid_arr[mid]['fixtureid'],5,aa,ac,ab,ca,cc,cb,ba,bc,bb))
            mid_arr=None
            node_arr=None
            self.ct=am_content       
        except Exception,e:
            self.writelog('[thread:aomen_match_bqc]�̳߳����쳣:%s'%e)