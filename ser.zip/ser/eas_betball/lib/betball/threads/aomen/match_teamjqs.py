#coding:gbk
import time
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''��ӽ�����'''
class aomen_match_teamjqs(base):
    def __init__(self):
        super(aomen_match_teamjqs,self).__init__('aomen_match_teamjqs')
        self.ct=''
    
    def do(self):
        try:
            url=self.getConfigPath('numberofgoalsurl')
            am_content=self.fopen(url)
            if self.ct==am_content:
                return
            #��ȡ���ذ�������xml����
            mid_arr=Func.getMacauZqXml('match_teamjqs')
            
            #��������Դ����
            xml=self.parsexml(am_content)
            if xml:
                node_arr=xml.getElementsByTagName('Fixture')
            else:
                node_arr=[]
            
            for node in node_arr:
                mid=int(node.getAttribute('id'))
                if mid_arr.has_key(mid) and str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))<=mid_arr[mid]['matchdate']:
                    if mid_arr[mid]['isresver']==0:
                        a0='%.2f'%float(node.getAttribute('h1'))
                        a1='%.2f'%float(node.getAttribute('h2'))
                        a2='%.2f'%float(node.getAttribute('h3'))
                        a3='%.2f'%float(node.getAttribute('h4'))
                        a4='%.2f'%float(node.getAttribute('h5'))
                        a5='%.2f'%float(node.getAttribute('h6'))
                        b0='%.2f'%float(node.getAttribute('a1'))
                        b1='%.2f'%float(node.getAttribute('a2'))
                        b2='%.2f'%float(node.getAttribute('a3'))
                        b3='%.2f'%float(node.getAttribute('a4'))
                        b4='%.2f'%float(node.getAttribute('a5'))
                        b5='%.2f'%float(node.getAttribute('a6'))
                    else:
                        a0='%.2f'%float(node.getAttribute('a1'))
                        a1='%.2f'%float(node.getAttribute('a2'))
                        a2='%.2f'%float(node.getAttribute('a3'))
                        a3='%.2f'%float(node.getAttribute('a4'))
                        a4='%.2f'%float(node.getAttribute('a5'))
                        a5='%.2f'%float(node.getAttribute('a6'))
                        b0='%.2f'%float(node.getAttribute('h1'))
                        b1='%.2f'%float(node.getAttribute('h2'))
                        b2='%.2f'%float(node.getAttribute('h3'))
                        b3='%.2f'%float(node.getAttribute('h4'))
                        b4='%.2f'%float(node.getAttribute('h5'))
                        b5='%.2f'%float(node.getAttribute('h6'))
                    result=Db_Odds().add_teamjqs(mid_arr[mid]['fixtureid'],5,a0,a1,a2,a3,a4,a5,b0,b1,b2,b3,b4,b5)
                    if result==-1:
                        self.writelog('[thread:aomen_match_teamjqs]�������ݿ�����쳣;fixtureid:%s;companyid:%s;param:%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s;'%(mid_arr[mid]['fixtureid'],5,a0,a1,a2,a3,a4,a5,b0,b1,b2,b3,b4,b5))
        except Exception,e:
            self.writelog('[thread:aomen_match_teamjqs]�̳߳����쳣:%s'%e)