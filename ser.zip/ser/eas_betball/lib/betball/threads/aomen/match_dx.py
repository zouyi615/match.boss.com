#coding:gbk
import time
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''��С����'''
class aomen_match_dx(base):
    def __init__(self):
        super(aomen_match_dx,self).__init__('aomen_match_dx')
        self.ct=''
    def do(self):
        try:
            tmp=Db_Odds().getAomenCompanyInfo()
            if not tmp['source_aomen_a']:
                return
            url=self.getConfigPath('overunderurl')
            am_content=self.fopen(url)
#            if self.ct==am_content:
#                return
            
            #��ȡ���ذ�������xml����
            mid_arr=Func.getMacauZqXml('match_dx')
            
            xml=self.parsexml(am_content)
            if xml:
                node_arr=xml.getElementsByTagName('Fixture')
            else:
                node_arr=[]
            for node in node_arr:
                mid=int(node.getAttribute('id'))
                if mid_arr.has_key(mid) and str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))<=mid_arr[mid]['matchdate']:
                    up=Func.checkData(node.getAttribute('oo'))
                    down=Func.checkData(node.getAttribute('uo'))
                    handicap=Func.getDxhandicap(int(node.getAttribute('li')))   
                    companyid=5 
                    result=Db_Odds().add_bigsmall(mid_arr[mid]['fixtureid'],companyid,up,handicap,down) 
                    if result==-1:
                        self.writelog('[thread:aomen_match_dx]�������ݿ�����쳣;fixtureid:%s;companyid:%s;up:%.2f;handicap:%s;down:%.2f'%(mid_arr[mid]['fixtureid'],companyid,up,handicap,down))
            self.ct=am_content
        except Exception,e:
            self.writelog('[thread:aomen_match_dx]�̳߳����쳣:%s'%e)