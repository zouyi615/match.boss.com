#coding:gbk
import time
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''������'''
class aomen_match_jqs(base):
    def __init__(self):
        super(aomen_match_jqs,self).__init__('aomen_match_jqs')
        self.ct=''
    
    def do(self):
        try:
            url=self.getConfigPath('totalgoalsurl')
            am_content=self.fopen(url)
            if self.ct==am_content:
                return
            
            #��ȡ���ذ�������xml����
            mid_arr=Func.getMacauZqXml('match_jqs')
            
            #��������Դ����
            xml=self.parsexml(am_content)
            if xml:
                node_arr=xml.getElementsByTagName('Fixture')
            else:
                node_arr=[]
            for node in node_arr:
                mid=int(node.getAttribute('id'))
                if mid_arr.has_key(mid) and str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))<=mid_arr[mid]['matchdate']:
                    b01='%.2f'%float(node.getAttribute('o0'))
                    b23='%.2f'%float(node.getAttribute('o2'))
                    b46='%.2f'%float(node.getAttribute('o4'))
                    b7='%.2f'%float(node.getAttribute('o7'))
                    result=Db_Odds().add_jqs(mid_arr[mid]['fixtureid'],5,b01,b23,b46,b7)
                    if result==-1:
                        self.writelog('[thread:aomen_match_jqs]�������ݿ�����쳣;fixtureid:%s;companyid:%s;param:%s,%s,%s,%s;'%(mid_arr[mid]['fixtureid'],5,b01,b23,b46,b7))
            self.ct=am_content
        except Exception,e:
            self.writelog('[thread:aomen_match_jqs]�̳߳����쳣:%s'%e)