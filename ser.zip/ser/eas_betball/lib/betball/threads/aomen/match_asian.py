#coding:gbk
import time
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''ƥ������'''
class aomen_match_asian(base):
    def __init__(self):
        super(aomen_match_asian,self).__init__('aomen_match_asian')
        self.ct=''
    
    def do(self):
        try:
            tmp=Db_Odds().getAomenCompanyInfo()
            if not tmp['source_aomen_a']:
                return
            url=self.getConfigPath('winoddsurl')
            am_content=self.fopen(url)            
#            if self.ct==am_content:
#                return
            
            #���ͽӿ�����
            odds_arr=[]
            live_arr=[]
            sohu_arr=[]#ͬ�����Ѻ�
#            asian_arr=[]

            #��ȡ���ذ�������xml����
            mid_arr=Func.getMacauZqXml('match_asian')
                
            
            xml=self.parsexml(am_content)
            if xml:
                node_arr=xml.getElementsByTagName('Fixture')
            else:
                node_arr=[]
            for node in node_arr:
                mid=int(node.getAttribute('id'))
                if node.getAttribute('g')=='H':
                    homeismain=1
                else:
                    homeismain=0
                gg=int(node.getAttribute('gg'))
                if gg>0 and mid_arr.has_key(mid):
                    if str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))<=mid_arr[mid]['matchdate']:
                        if mid_arr[mid]['isresver']==0:
                            homeline=node.getAttribute('ho')
                            awayline=node.getAttribute('ao')
                            handicaplinename=Func.getHandicapName(gg,homeismain)
                            handicap=Func.getHandicap(handicaplinename)
                        else:
                            if homeismain==0:
                                homeismain=1
                            else:
                                homeismain=0
                            homeline=node.getAttribute('ao')
                            awayline=node.getAttribute('ho')
                            handicaplinename=Func.getHandicapName(gg,homeismain)  
                            handicap=Func.getHandicap(handicaplinename)
                        
                        homeline=Func.checkData(homeline)
                        awayline=Func.checkData(awayline)
                        
                        result=Db_Odds().add_asian(mid_arr[mid]['fixtureid'],5,homeline,handicap,awayline)
                        if result==1:
                            row={'fixtureid':mid_arr[mid]['fixtureid'],'companyid':5,'sw1':'%.3f'%homeline,'handicaplinename':handicaplinename,'sw2':'%.3f'%awayline}
                            odds_arr.append(row)
                            live_arr.append(row)
#                            asian_arr.append(row)
                            if mid_arr[mid]['isbeidan']==1 or mid_arr[mid]['islottyle']==1:
                                sohu_arr.append({'fixtureid':mid_arr[mid]['fixtureid'],'companyid':5,'sw1':'%.3f'%homeline,'handicaplineid':handicap,'sw2':'%.3f'%awayline})
                        elif result==-1:
                            self.writelog('[thread:aomen_match_asian]�������ݿ�����쳣;fixtureid:%s;companyid:%s;sw1:%.3f;handicaplinename:%s;sw2:%.3f'%(mid_arr[mid]['fixtureid'],5,homeline,handicaplinename,awayline))
                            
            Post.upload_asian_xml(odds_arr)
            Post.upload_asian_xml(live_arr,2)
#            Post.post_asian_xml(asian_arr)
            Post.post_sohu_data('asian',sohu_arr)
            odds_arr=None
            live_arr=None
            sohu_arr=None
            list=None
            node_arr=None
            self.ct=am_content
        except Exception,e:
            self.writelog('[thread:aomen_match_asian]�̳߳����쳣:%s'%e)