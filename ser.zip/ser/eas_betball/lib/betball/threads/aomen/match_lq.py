#coding:gbk
import time,traceback
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''ƥ������'''
class aomen_match_lq(base):
    def __init__(self):
        super(aomen_match_lq,self).__init__('aomen_match_lq')
        self.data=[]
    
    def getData(self):
        return self.data
    
    def do(self):
        try:
            data_tmp_arr=[]
            url=self.getConfigPath('aomen_fixtureurl')
            content=self.fopen(url)
            xml=self.parsexml(content)
            if xml:
                node_arr=xml.getElementsByTagName('Fixture')
            else:
                node_arr=[]
            sp_time=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())
            result_arr=[]
            for node in node_arr:
                date_tmp=str(node.getAttribute('gt'))
                vsdate='%s-%s-%s %s:00'%(date_tmp[0:4],date_tmp[4:6],date_tmp[6:8],date_tmp[9:])
                if vsdate>sp_time:
                    id=int(node.getAttribute('id'))
                    home_am=node.getAttribute('th').encode('gbk').strip()
                    away_am=node.getAttribute('ta').encode('gbk').strip()
                    tmp=Db_Odds().getLqMatch(home_am,away_am,vsdate)
                    if tmp:
                        if tmp['HomeName_AM']==away_am and tmp['AwayName_AM']==home_am:
                            isresver=1
                        else:
                            isresver=0
                        row={}
                        row['isresver']=isresver
                        row['fixtureid']=tmp['FixtureID']
                        row['matchid']=id
                        row['matchdate']=tmp['VSDate']
                        row['homename']=tmp['HomeGBName']
                        row['awayname']=tmp['AwayGBName']
                        row['homeid']=int(tmp['HomeID'])
                        row['awayid']=int(tmp['AwayID'])
                        result_arr.append(row)
                        data_tmp_arr.append({'mid':id,'home':home_am,'away':away_am,'vsdate':vsdate,'ispipei':1,'fixtureid':row['fixtureid']})
                    else:
                        data_tmp_arr.append({'mid':id,'home':home_am,'away':away_am,'vsdate':vsdate,'ispipei':0,'fixtureid':''})
            Post.post_aomen_match_lq(result_arr)
            self.data=data_tmp_arr
            data_tmp_arr=None
        except Exception,e:
            self.writelog('[thread:aomen_match_lq]�̳߳����쳣:%s'%traceback.format_exc())