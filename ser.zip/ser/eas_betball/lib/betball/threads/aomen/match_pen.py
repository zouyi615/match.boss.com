#coding:gbk
import re
from betball.threads.base import base
from betball.func import common as Func
from betball.db.odds import Db_Odds
'''������ˮ'''
class aomen_match_pen(base):
    def __init__(self):
        super(aomen_match_pen,self).__init__('aomen_match_pen')
    
    def do(self):
        try:
            url=self.getConfigPath('create_interface_url')+self.getConfigPath('create_zq_xml')
            content=self.fopen(url)
            xml=self.parsexml(content)
            if xml:
                m_node_arr=xml.getElementsByTagName('Table')
            else:
                m_node_arr=[]
            mid_arr={}
            for node in m_node_arr:
                fixtureid=int(node.getElementsByTagName('FixtureID')[0].firstChild.nodeValue)
                mid=int(node.getElementsByTagName('MacauID')[0].firstChild.nodeValue)
                title=node.getElementsByTagName('VSTeam')[0].firstChild.nodeValue.encode('gbk','ignore')
                mid_arr[mid]={'fixtureid':fixtureid,'title':title}
            m_node_arr=None
            if not mid_arr:
                return
            
            content=self.fopen(self.getConfigPath('predictions_url'))
            xml=self.parsexml(content.replace('encoding = ','encoding='))
            if xml:
                node_arr=xml.getElementsByTagName('PREDICTIONS')
            else:
                node_arr=[]
            for node in node_arr:
                mid=int(node.getElementsByTagName('PREDICTION_ID')[0].firstChild.nodeValue)
                
                tournament=node.getElementsByTagName('TOURNAMENT')[0].firstChild.nodeValue.encode('gbk','ignore')
                home=node.getElementsByTagName('HOME')[0].firstChild.nodeValue.encode('gbk','ignore')
                home_recent=node.getElementsByTagName('HOME_RECENT')[0].firstChild.nodeValue.encode('gbk')
                home_handicap=node.getElementsByTagName('HOME_HANDICAP')[0].firstChild.nodeValue.encode('gbk')
                recommend=node.getElementsByTagName('RECOMMEND')[0].firstChild.nodeValue.encode('gbk')
                away=node.getElementsByTagName('AWAY')[0].firstChild.nodeValue.encode('gbk','ignore')
                away_recent=node.getElementsByTagName('AWAY_RECENT')[0].firstChild.nodeValue.encode('gbk')
                away_handicap=node.getElementsByTagName('AWAY_HANDICAP')[0].firstChild.nodeValue.encode('gbk')
                
                confidence=int(node.getElementsByTagName('CONFIDENCE')[0].firstChild.nodeValue)
                recent_matchup=str(node.getElementsByTagName('RECENT_MATCHUP')[0].firstChild.nodeValue.encode('gbk','ignore'))
                content=node.getElementsByTagName('CONTENT')[0].firstChild.nodeValue.encode('gbk','ignore')
                content=re.sub(r'<[^>]+>','',content)
                rt_tmp=node.getElementsByTagName('RECOMMEND_TEXT')
                if rt_tmp:
                    recommend_text=rt_tmp[0].firstChild.nodeValue.encode('gbk','ignore')
                else:
                    recommend_text=''
                stadium=int(node.getElementsByTagName('STADIUM')[0].firstChild.nodeValue)
                if stadium:
                    stadium_str='��'
                else:
                    stadium_str='��'
                if mid_arr.has_key(mid) and mid_arr[mid]['fixtureid']!=0:
                    string='<table width="100%" border="0" cellpadding="5" cellspacing="1" bgcolor="#CDCDCD" style="font-family:����;font-size: 13px;"><tr bgcolor="#94A5DB"><td colspan="3" align="center" style="font-size:16px;color:white;">'+tournament+'</td></tr>'
                    string+='<tr bgcolor="#F2F2FE"><td width="33%">&nbsp;'+home+' ('+stadium_str+')</td>'
                    string+='<td width="33%">&nbsp;�������� - '+Func.addColor(home_recent)+'</td>'
                    string+='<td width="33%">&nbsp;��·Ӯ�� - '+Func.addColor(home_handicap)+'</td></tr>'
                    string+='<tr bgcolor="#F2F2FE"><td width="33%">&nbsp;'+away+'</td>'
                    string+='<td width="33%">&nbsp;�������� - '+Func.addColor(away_recent)+'</td>'
                    string+='<td width="33%">&nbsp;��·Ӯ�� - '+Func.addColor(away_handicap)+'</td></tr>'
                    string+='<tr bgcolor="#F2F2FE"><td colspan="3" align=center>����ָ�� - <font color="6666FF">'+Func.genRecommend(recommend,recommend_text,home,away)+'</font> '+Func.genConfidence(confidence)+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�����ɼ� - '+home+' '+recent_matchup+'</td></tr>'
                    string+='<tr><td colspan="3" bgcolor="#FFFFFF">����'+content+'</td></tr>'
                    string+='<tr bgcolor=#E7E7EF><td colspan=3 align=right>ע������ָ��������Ϊ���֡�&nbsp;&nbsp;( W=ʤ��D=�͡�L=�� )</td></tr></table>'
                    string=Func.getSimplifiedChinese(string)
                    Db_Odds().addNews(mid_arr[mid]['fixtureid'],9,mid_arr[mid]['title'].replace("'","\'"),string.replace("'","\'"))                
        except Exception,e:
            self.writelog('[thread:aomen_match_pen]�̳߳����쳣:%s'%e)