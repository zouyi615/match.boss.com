#coding:gbk
import time
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''���Ų����߳�'''
class aomen_match_bd(base):
    def __init__(self):
        super(aomen_match_bd,self).__init__('aomen_match_bd')
        self.ct=''
    
    def do(self):
        try:
            url=self.getConfigPath('correctscoreurl')
            am_content=self.fopen(url)
            if self.ct==am_content:
                return
            
            #��ȡ���ذ�������xml����
            mid_arr=Func.getMacauZqXml('match_bd')
            
            #��������Դ����
            xml=self.parsexml(am_content)
            if xml:
                node_arr=xml.getElementsByTagName('Fixture')
            else:
                node_arr=[]
            
            for node in node_arr:
                mid=int(node.getAttribute('id'))
                if mid_arr.has_key(mid) and str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))<=mid_arr[mid]['matchdate']:
                    if mid_arr[mid]['isresver']==0:
                        a10=float(node.getAttribute('h1'))    
                        b10=float(node.getAttribute('a1'))   
                        a20=float(node.getAttribute('h2')) 
                        b20=float(node.getAttribute('a2'))  
                        a21=float(node.getAttribute('h3')) 
                        b21=float(node.getAttribute('a3'))
                        a30=float(node.getAttribute('h4')) 
                        b30=float(node.getAttribute('a4')) 
                        a31=float(node.getAttribute('h5')) 
                        b31=float(node.getAttribute('a5')) 
                        a32=float(node.getAttribute('h6')) 
                        b32=float(node.getAttribute('a6')) 
                        a40=float(node.getAttribute('h7')) 
                        b40=float(node.getAttribute('a7')) 
                        a41=float(node.getAttribute('h8')) 
                        b41=float(node.getAttribute('a8'))
                        a42=float(node.getAttribute('h9')) 
                        b42=float(node.getAttribute('a9')) 
                        a43=float(node.getAttribute('h10')) 
                        b43=float(node.getAttribute('a10'))
                        
                    else:
                        a10=float(node.getAttribute('a1'))    
                        b10=float(node.getAttribute('h1'))   
                        a20=float(node.getAttribute('a2')) 
                        b20=float(node.getAttribute('h2'))  
                        a21=float(node.getAttribute('a3')) 
                        b21=float(node.getAttribute('h3'))
                        a30=float(node.getAttribute('a4')) 
                        b30=float(node.getAttribute('h4')) 
                        a31=float(node.getAttribute('a5')) 
                        b31=float(node.getAttribute('h5')) 
                        a32=float(node.getAttribute('a6')) 
                        b32=float(node.getAttribute('h6')) 
                        a40=float(node.getAttribute('a7')) 
                        b40=float(node.getAttribute('h7')) 
                        a41=float(node.getAttribute('a8')) 
                        b41=float(node.getAttribute('h8'))
                        a42=float(node.getAttribute('a9')) 
                        b42=float(node.getAttribute('h9')) 
                        a43=float(node.getAttribute('a10')) 
                        b43=float(node.getAttribute('h10'))
                        
                    c00=float(node.getAttribute('o11')) 
                    c11=float(node.getAttribute('o12')) 
                    c22=float(node.getAttribute('o13')) 
                    c33=float(node.getAttribute('o14')) 
                    c44=float(node.getAttribute('o15'))
                    a5=float(node.getAttribute('o16'))
                    b5=float(node.getAttribute('o16'))
                    result=Db_Odds().add_bd(mid_arr[mid]['fixtureid'],5,a10,b10,a20,b20,a21,b21,a30,b30,a31,b31,a32,b32,a40,b40,a41,b41,a42,b42,a43,b43,c00,c11,c22,c33,c44,a5,b5)
                    if result==-1:
                        self.writelog('[thread:aomen_match_bd]�������ݿ�����쳣;fixtureid:%s;companyid:%s;params:%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s'%(mid_arr[mid]['fixtureid'],5,a10,b10,a20,b20,a21,b21,a30,b30,a31,b31,a32,b32,a40,b40,a41,b41,a42,b42,a43,b43,c00,c11,c22,c33,c44,a5,b5))
            mid_arr=None
            node_arr=None
            self.ct=am_content            
        except Exception,e:
            self.writelog('[thread:aomen_match_bd]�̳߳����쳣:%s'%e)