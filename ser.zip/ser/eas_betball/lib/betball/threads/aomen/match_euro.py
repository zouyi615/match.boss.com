#coding:gbk
import time
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''ƥ��ŷ��'''
class aomen_match_euro(base):
    def __init__(self):
        super(aomen_match_euro,self).__init__('aomen_match_euro')
        self.ct=''
    
    def do(self):
        try:
            tmp=Db_Odds().getAomenCompanyInfo()
            if not tmp['source_aomen']:
                return
            url=self.getConfigPath('windrawwinurl')
            cm_content=self.fopen(url)
#            if self.ct==cm_content:
#                return

            #���ͽӿ�����
            odds_arr=[]
            live_arr=[]

            #��ȡ���ذ�������xml����
            mid_arr=Func.getMacauZqXml('match_euro')

            xml=self.parsexml(cm_content)
            if xml:
                node_arr=xml.getElementsByTagName('Fixture')
            else:
                node_arr=[]
            for node in node_arr:
                mid=int(node.getAttribute('id'))
                if mid_arr.has_key(mid) and str(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))<=mid_arr[mid]['matchdate']:
                    if mid_arr[mid]['isresver']==0:
                        win=float(node.getAttribute('ho'))
                        draw=float(node.getAttribute('do'))
                        lost=float(node.getAttribute('ao'))
                    else:
                        win=float(node.getAttribute('ao'))
                        draw=float(node.getAttribute('do'))
                        lost=float(node.getAttribute('ho'))
                    try:
                        win='%.2f'%float(win)
                        draw='%.2f'%float(draw)
                        lost='%.2f'%float(lost)
                        if win=='0.00' or draw=='0.00' or lost=='0.00':
                            self.writelog('[thread:aomen_match_euro]��ȡ���ʳ����쳣:win:%s,draw:%s,lost:%s;matchid:%s'%(win,draw,lost,mid))
                            continue
                    except Exception,e:
                        self.writelog('[thread:aomen_match_euro]��ȡ���ʳ����쳣:win:%s,draw:%s,lost:%s;matchid:%s'%(win,draw,lost,mid))
                        continue
                    result=Db_Odds().add_odds(mid_arr[mid]['fixtureid'],5,win,draw,lost)
                    if result==1:
                        row={}
                        row={'fixtureid':mid_arr[mid]['fixtureid'],'companyid':5,'win':win,'draw':draw,'lost':lost}
                        odds_arr.append(row)
                        live_arr.append(row)
                    elif result==-1:
                        self.writelog('[thread:aomen_match_euro]�������ݿ�����쳣;fixtureid:%s;companyid:%s;win:%s;draw:%s;lost:%s'%(mid_arr[mid]['fixtureid'],5,win,draw,lost))
            Post.upload_odds_xml(odds_arr)
            Post.upload_odds_xml(live_arr,2)
            self.ct=cm_content
        except Exception,e:
            self.writelog('[thread:aomen_match_euro]�̳߳����쳣:%s'%e)