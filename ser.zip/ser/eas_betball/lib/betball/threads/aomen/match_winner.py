#coding:gbk
import hashlib
import time,traceback
from betball.threads.base import base
from betball.func import common as Func
from betball.func import post as Post
from betball.db.odds import Db_Odds
'''ƥ������'''
class aomen_match_winner(base):
    def __init__(self):
        super(aomen_match_winner,self).__init__('aomen_match_winner')
        self.ct=''
    
    def do(self):
        try:
            url=self.getConfigPath('aome_winner')%time.time()
            am_content=self.fopen(url)
            if am_content:
                xml=self.parsexml(am_content)
            else:
                xml=None
            if xml:
                node_arr=xml.getElementsByTagName('CPN')
            else:
                node_arr=[]
            list={}
            for node in node_arr:
                if node.getAttribute('o')!="-1":
                    #����id
                    seasonid=int(node.getAttribute('tid'))
                    #��������
                    seasonname=node.getAttribute('tt').encode('gbk')
                    
                    #���id
                    teamid=int(node.getAttribute('teamid'))
                    #�����
                    teamname=node.getAttribute('tte').encode('gbk')
                    #����
                    odds=float(node.getAttribute('o'))
                    
                    if not list.has_key(seasonid):
                        list[seasonid]={'seasonid':seasonid,'seasonname':seasonname,'data':[]}
                    list[seasonid]['data'].append({'teamid':teamid,'teamname':teamname,'odds':odds})
            
            for sid in list:
                #�ҵ���Ӧ��������
                result=Db_Odds().getSeasonInfoBySeasonMacauName(list[sid]['seasonname'])
                if result:
                    seasonid_500=result['seasonid']
                    teamname_tmp=[]
                    teamname_map_info={}
                    #�������
                    for row in list[sid]['data']:
                        e_k=hashlib.md5(row['teamname']).hexdigest()
                        
                        teamname_map_info[e_k]=row
                        
                        teamname_tmp.append(row['teamname'])                    
                    
                    #�����¿���Ҷ�Ӧ�����
                    list_500=Db_Odds().getTeamInfoByMacauName(teamname_tmp)
                    for row in list_500:
                        e_k=hashlib.md5(row['teamname']).hexdigest()
                        #�ҵ���Ӧ�����
                        if teamname_map_info.has_key(e_k):
                            #������������
                            Db_Odds().saveWinnerOdds(seasonid_500,row['teamid'],5,teamname_map_info[e_k]['odds'])
        except:
            self.writelog('[thread:aomen_match_winner]�̳߳����쳣:%s'%traceback.format_exc())