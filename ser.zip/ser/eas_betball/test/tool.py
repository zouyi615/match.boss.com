#coding=gbk
import sys, os
reload(sys)
sys.setdefaultencoding('gbk')
#print sys.getdefaultencoding()

import time
#import json
import threading
import logging
import traceback
import signal

if not os.environ.has_key('_BASIC_PATH_'):
	_BASIC_PATH_ = os.path.abspath(__file__)
	_BASIC_PATH_ = _BASIC_PATH_[:_BASIC_PATH_.rfind('/test/')]
	os.environ['_BASIC_PATH_'] = _BASIC_PATH_
if sys.path.count(os.environ['_BASIC_PATH_'] + '/lib') == 0:
	sys.path.append(os.environ['_BASIC_PATH_'] + '/mod')
	sys.path.append(os.environ['_BASIC_PATH_'] + '/lib')
	sys.path.append(os.environ['_BASIC_PATH_'] + '/lib/common')
	sys.path.append(os.environ['_BASIC_PATH_'] + '/libs')
	sys.path.append(os.environ['_BASIC_PATH_'] + '/libs/pypi')


import re
import XmlConfig, urllib, urllib2
import Db.Mysql
import datetime, time
import base64
from BeautifulSoup import BeautifulSoup


XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/config.xml')
XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/db.xml')



from betball.threads.match import ball365_match

obj = ball365_match.ball365_match()

obj.start()

#print obj.getData()

#obj.do()

#print obj.getData()

exit()









'''
def day_diff(datetime1,datetime2):
#    time_tmp=datetime1.split(' ')
#    time1_tmp=time_tmp[0].split('-')
#    time2_tmp=time_tmp[1].split(':')
#    time1=datetime.datetime(int(time1_tmp[0]),int(time1_tmp[1]),int(time1_tmp[2]),int(time2_tmp[0]),int(time2_tmp[1]),int(time2_tmp[2]))
#    
#    time_tmp=datetime2.split(' ')
#    time1_tmp=time_tmp[0].split('-')
#    time2_tmp=time_tmp[1].split(':')
#    time2=datetime.datetime(int(time1_tmp[0]),int(time1_tmp[1]),int(time1_tmp[2]),int(time2_tmp[0]),int(time2_tmp[1]),int(time2_tmp[2]))
#    return (time2-time1).days
    timestamp_1=time.mktime(time.strptime(str(datetime1),'%Y-%m-%d %H:%M:%S'))
    timestamp_2=time.mktime(time.strptime(str(datetime2),'%Y-%m-%d %H:%M:%S'))
    return abs(timestamp_1-timestamp_2)/86400

def check_day_diff(time1,time2):
    if day_diff(time1,time2)>=1:
        return False
    else:
        return True

url= "http://fenxi.310v.com/match_data_xml/coming_match.js"
resp = urllib2.urlopen(url)
ct_tmp = resp.read()

pattern=re.compile(r'[\w]+\[[\d]+\]="([^"]+)";')
ct_arr=pattern.findall(ct_tmp)


begin=time.strftime('%Y-%m-%d %H:%M:00',time.localtime())
end=time.strftime('%Y-%m-%d',time.localtime(time.time()+8*24*3600))

sp_time=time.strftime('%Y-%m-%d 12:00:00',time.localtime(time.time()+24*3600))

sql="select a.fixtureid,a.ball365_1,a.ball365_2,a.home,a.away,concat(a.matchdate,' ',a.matchtime) as matchdatetime,a.ball365_eur_1,a.ball365_eur_2,a.islottyle,a.isbeidan,b.sourcelimit,b.sourceoddslimit from v_getfixturepipei as a left join t_s_fixture_ext as b on a.fixtureid=b.fixtureid where concat(a.matchdate,' ',a.matchtime)>=%s and a.matchdate<%s"
args=[begin,end]

dblist = Db.Mysql.get('SoccerSlave').query(sql,args)

data_arr=[]   
result_arr={}

for r in ct_arr:
	item=r.split('')
	matchname=item[6].strip()
	matchtime=item[1].strip()
	hometeam=item[3].strip()
	awayteam=item[5].strip()
	ball365_matchid=int(item[0])
	isexists=0
	for row in dblist:
		fixtureid=row['fixtureid']
		homename=row['home']
		awayname=row['away']
		matchdate=row['matchdatetime']
		limit1=0
		limit2=0
		limit3=0
		if row['sourcelimit'] and int(row['sourcelimit'])==1 and row['sourceoddslimit']:
			source_arr=row['sourceoddslimit'].split(',')
			for v in source_arr:
				if v=='1':
					limit1=1
				elif v=='2':
					limit2=1
				elif v=='3':
					limit3=1
		islottype=int(row['islottyle'])
		isbeidan=int(row['isbeidan'])
		flag1=(hometeam==row['ball365_1'] or hometeam==row['ball365_eur_1']) and (awayteam==row['ball365_2'] or awayteam==row['ball365_eur_2'])
		flag2=(hometeam==row['ball365_2'] or hometeam==row['ball365_eur_2']) and (awayteam==row['ball365_1'] or awayteam==row['ball365_eur_1'])
		flag3=check_day_diff(matchtime,matchdate)
		if (flag1 or flag2) and flag3:
			home_tmp=''
			away_tmp=''
			isexists=1
			isreverse=0
			if flag1:
				home_tmp=hometeam
				away_tmp=awayteam
			elif flag2:
				home_tmp=awayteam  
				away_tmp=hometeam
				isreverse=1
			result_arr[fixtureid]={}
			result_arr[fixtureid]['fixtureid']=fixtureid
			result_arr[fixtureid]['islottype']=islottype
			result_arr[fixtureid]['isbeidan']=isbeidan
			result_arr[fixtureid]['isreverse']=isreverse
			result_arr[fixtureid]['limit1']=limit1
			result_arr[fixtureid]['limit2']=limit2
			result_arr[fixtureid]['limit3']=limit3
			result_arr[fixtureid]['ball365_matchid']=ball365_matchid
			result_arr[fixtureid]['hometeam']=homename
			result_arr[fixtureid]['awayteam']=awayname
			
			result_arr[fixtureid]['hometeam_tmp']=home_tmp
			result_arr[fixtureid]['awayteam_tmp']=away_tmp
			result_arr[fixtureid]['matchdate']=str(time.strftime('%Y%m%d%H%M',time.strptime(matchdate,'%Y-%m-%d %H:%M:%S')))
			if matchdate<sp_time:
				istoday=1
			else:
				istoday=0
			data_arr.append({'matchname':matchname,'fixtureid':fixtureid,'homename':homename,'awayname':awayname,'matchdate':matchdate,'url':"http://fenxi.310v.com/odds_pic/e_100.php?match_id=%s"%ball365_matchid,'ismatch':1,'istoday':istoday})
			break
	if isexists==0:
		if matchtime<sp_time:
			istoday=1
		else:
			istoday=0
		data_arr.append({'matchname':matchname,'fixtureid':'','homename':hometeam,'awayname':awayteam,'matchdate':matchtime,'url':"http://fenxi.310v.com/odds_pic/e_100.php?match_id=%s"%ball365_matchid,'ismatch':0,'istoday':istoday})
'''
print data_arr
exit()
