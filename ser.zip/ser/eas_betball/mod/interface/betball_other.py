#coding:gbk
import EasClient
import Eas.Extend
import Eas.Function
import other.mm as mm
import time
from betball.threads.match.ball365_match import ball365_match
from betball.threads.match.bet007_todaymatch import bet007_todaymatch
from betball.threads.match.bet007_futurematch import bet007_futurematch
from betball.threads.match.betexplore_match import betexplore_match
from betball.threads.match.gooooal_todaymatch import gooooal_todaymatch
from betball.threads.match.gooooal_futurematch import gooooal_futurematch
class betball_other(Eas.Extend.Common): 
    def __init__(self):
#        self.thread_status={'ball365_match':'0','bet007_todaymatch':'0','bet007_futurematch':'0','betexplore_match':'0','gooooal_todaymatch':'0','gooooal_futurematch':'0'}
        self.thread_status={'ball365_match':'0','bet007_todaymatch':'0','bet007_futurematch':'0','gooooal_todaymatch':'0','gooooal_futurematch':'0'}
        self.threads={}
        for key in self.thread_status:
            time.sleep(3) #����������ʱ��
            self.start(key)
    
    '''����'''       
    def start(self,key):
        if self.thread_status.has_key(key) and self.thread_status[key]=='0':
            if key=='ball365_match':
                self.threads[key]=ball365_match()
            elif key=='bet007_todaymatch':
                self.threads[key]=bet007_todaymatch()
            elif key=='bet007_futurematch':
                self.threads[key]=bet007_futurematch()
            elif key=='betexplore_match':
                self.threads[key]=betexplore_match()
            elif key=='gooooal_todaymatch':
                self.threads[key]=gooooal_todaymatch()
            elif key=='gooooal_futurematch':
                self.threads[key]=gooooal_futurematch()
            self.threads[key].setDaemon(True)
            self.threads[key].start()
            self.thread_status[key]='1'
        return self._result({},[])  
    
    '''ֹͣ'''  
    def stop(self,key):
        if self.thread_status.has_key(key) and self.thread_status[key]=='1':
            self.threads[key].stop()
            self.thread_status[key]='0'
        return self._result({},[])
    
    '''����״̬'''
    def setstatus(self,type,statusid):
        if statusid=='1':
            self.start(type)
        else:
            self.stop(type)
        return self._result({},[])
         
    '''��ȡ����'''
    def getdata(self,type):
        if self.thread_status.has_key(type):
            return self._result({},mm.read(self.threads[type].getData()))
        else:
            return self._result({},[])
    
    '''��ȡ״̬'''
    def getstatus(self,type):
        if self.thread_status.has_key(type):
            return self._result({'status':self.thread_status[type]},[])
        else:
            return self._result({'status':0},[])
    
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''    
    p =betball_other()
    return Eas.Function.get_method_dict(p,prefix+'/')