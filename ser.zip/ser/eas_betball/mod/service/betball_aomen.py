#coding:gbk
import EasClient
import Eas.Extend
import Eas.Function
import JsonUtil
import logging
import other.mm as mm
import time
from betball.threads.aomen.match_lq import aomen_match_lq
from betball.threads.aomen.match_zq import aomen_match_zq
from betball.threads.aomen.match_tv import aomen_match_tv
from betball.threads.aomen.match_pen import aomen_match_pen
from betball.threads.aomen.match_asian import aomen_match_asian
from betball.threads.aomen.match_euro import aomen_match_euro
from betball.threads.aomen.match_dx import aomen_match_dx
from betball.threads.aomen.match_halfeuro import aomen_match_halfeuro
from betball.threads.aomen.match_bd import aomen_match_bd
from betball.threads.aomen.match_bqc import aomen_match_bqc
from betball.threads.aomen.match_ds import aomen_match_ds
from betball.threads.aomen.match_jqs import aomen_match_jqs
from betball.threads.aomen.match_teamjqs import aomen_match_teamjqs
from betball.threads.aomen.match_lq_pen import aomen_match_lq_pen
from betball.threads.aomen.match_winner import aomen_match_winner

'''���ŷ������'''
class betball_aomen(Eas.Extend.Common):
    def __init__(self):
        self.threads={'aomen_match_lq':None,'aomen_match_zq':None,'aomen_match_tv':None,'aomen_match_pen':None,'aomen_match_asian':None,'aomen_match_euro':None,
            'aomen_match_dx':None,'aomen_match_halfeuro':None,'aomen_match_bd':None,'aomen_match_bqc':None,'aomen_match_ds':None,'aomen_match_jqs':None,
            'aomen_match_teamjqs':None,'aomen_match_lq_pen':None,'aomen_match_winner':None
        }
        #״ֻ̬������ֵ;1:��ʾ���� ,0:����ֹͣ
        self.thread_status={}
        for key in self.threads:
            time.sleep(2)
            th=globals()[key]()
            th.setDaemon(True)
            th.start()
            self.threads[key]=th
            self.thread_status[key]='1'  
    
    #����״̬    
    def setstatus(self,params):
        if params:
            tmp=JsonUtil.read(params)
            for key in tmp:
                if tmp[key]:
                    self.start(key)
                else:
                    self.stop(key)
        return self._result({},[])
    
    #��ȡ״̬
    def getstatus(self,key=None):
        if not key:
            return self._result({},[mm.read(self.thread_status)])
        else:
            return self._result({},[mm.read({'rs':self.thread_status[key]})])                    
    
    def start(self,key):
        if self.thread_status.has_key(key) and self.thread_status[key]=='0':
            self.threads[key]=globals()[key]()
            self.threads[key].setDaemon(True)
            self.threads[key].start()
            self.thread_status[key]='1'
    def stop(self,key):
        if self.thread_status.has_key(key) and self.thread_status[key]=='1':
            self.threads[key].stop()
            self.thread_status[key]='0'
    
    def getPipeiData(self,type):
        if type=='zq':
            return self._result({},mm.read(self.threads['aomen_match_zq'].getData()))
        elif type=='lq':
            return self._result({},mm.read(self.threads['aomen_match_lq'].getData()))
        
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''    
    p =betball_aomen()
    return Eas.Function.get_method_dict(p,prefix+'/')