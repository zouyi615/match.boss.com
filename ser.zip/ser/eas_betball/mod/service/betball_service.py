#coding:gbk
import EasClient
import Eas.Extend
import Eas.Function
import JsonUtil
import other.mm as mm
import time
#ball365
from betball.threads.ball365.today_odds import ball365_today_odds
from betball.threads.ball365.today_asian import ball365_today_asian
from betball.threads.ball365.today_dxodds import ball365_today_dxodds
from betball.threads.ball365.future_odds import ball365_future_odds
from betball.threads.ball365.future_asian import ball365_future_asian
from betball.threads.ball365.future_dxodds import ball365_future_dxodds
from betball.threads.ball365.lot_odds import ball365_lot_odds
from betball.threads.ball365.dsodds import ball365_dsodds
from betball.threads.ball365.jqsodds import ball365_jqsodds
from betball.threads.ball365.bdodds import ball365_bdodds
from betball.threads.ball365.bqcodds import ball365_bqcodds

#bet007
from betball.threads.bet007.today_odds import bet007_today_odds
from betball.threads.bet007.today_asian import bet007_today_asian
from betball.threads.bet007.today_dxodds import bet007_today_dxodds
from betball.threads.bet007.future_odds import bet007_future_odds
from betball.threads.bet007.future_asian import bet007_future_asian
from betball.threads.bet007.future_dxodds import bet007_future_dxodds
#betexplore
from betball.threads.betexplore.today_odds import betexplore_today_odds
from betball.threads.betexplore.lot_odds import betexplore_lot_odds
from betball.threads.betexplore.main_odds import betexplore_main_odds
from betball.threads.betexplore.unmain_odds import betexplore_unmain_odds


from betball.threads.gooooal.today_asian import gooooal_today_asian
from betball.threads.gooooal.today_euro import gooooal_today_euro
from betball.threads.gooooal.today_dx import gooooal_today_dx
from betball.threads.gooooal.future_asian import gooooal_future_asian
from betball.threads.gooooal.future_euro import gooooal_future_euro
from betball.threads.gooooal.future_dx import gooooal_future_dx


#from betball.threads.betbrain.parse import betbrain_parse
#from betball.threads.betbrain.todayeuro import betbrain_todayeuro
#from betball.threads.betbrain.futureeuro import betbrain_futureeuro
#from betball.threads.betbrain.todayasian import betbrain_todayasian
#from betball.threads.betbrain.futureasian import betbrain_futureasian
#from betball.threads.betbrain.todaybig import betbrain_todaybig
#from betball.threads.betbrain.futurebig import betbrain_futurebig
#import betball.func.common as func
#from betball.threads.betbrain.asian import betbrain_asian
#from betball.threads.betbrain.euro import betbrain_euro
#from betball.threads.betbrain.big import betbrain_big
from betball.threads.betbrain.check import betbrain_check
from betball.threads.betbrain.memory import betbrain_memory
'''�������'''
class betball_service(Eas.Extend.Common):
    def __init__(self):
        self.threads={}
        self.thread_status={}
        self.init_ball365()
        self.init_bet007()
#         self.init_betexplore()
        self.init_gooooal()
        self.init_betbrain()
        for key in self.threads:
            time.sleep(1)
            self.thread_status[key]='1'
            self.threads[key].setDaemon(True)
            self.threads[key].start()
    def init_ball365(self):
        self.threads['ball365_today_odds']=ball365_today_odds()
        self.threads['ball365_today_asian']=ball365_today_asian()
        self.threads['ball365_today_dxodds']=ball365_today_dxodds()
        
        self.threads['ball365_future_odds']=ball365_future_odds()
        self.threads['ball365_future_asian']=ball365_future_asian()
        self.threads['ball365_future_dxodds']=ball365_future_dxodds()
        
        self.threads['ball365_lot_odds']=ball365_lot_odds()
        self.threads['ball365_dsodds']=ball365_dsodds()
        self.threads['ball365_jqsodds']=ball365_jqsodds()
        self.threads['ball365_bdodds']=ball365_bdodds()       
        self.threads['ball365_bqcodds']=ball365_bqcodds()
    def init_bet007(self):
        self.threads['bet007_today_odds']=bet007_today_odds()
        self.threads['bet007_today_asian']=bet007_today_asian()
        self.threads['bet007_today_dxodds']=bet007_today_dxodds()
        
        self.threads['bet007_future_odds']=bet007_future_odds()
        self.threads['bet007_future_asian']=bet007_future_asian()
        self.threads['bet007_future_dxodds']=bet007_future_dxodds()
        
    def init_betexplore(self):
        self.threads['betexplore_today_odds']=betexplore_today_odds()
        self.threads['betexplore_lot_odds']=betexplore_lot_odds()
        self.threads['betexplore_main_odds']=betexplore_main_odds()
        self.threads['betexplore_unmain_odds']=betexplore_unmain_odds()
        
    def init_gooooal(self):
        self.threads['gooooal_today_asian']=gooooal_today_asian()
        self.threads['gooooal_today_euro']=gooooal_today_euro()
        self.threads['gooooal_today_dx']=gooooal_today_dx()
        self.threads['gooooal_future_asian']=gooooal_future_asian()
        self.threads['gooooal_future_euro']=gooooal_future_euro()
        self.threads['gooooal_future_dx']=gooooal_future_dx()
        
    def init_betbrain(self):
        self.threads['betbrain_check']=betbrain_check()
        self.threads['betbrain_memory']=betbrain_memory()        
#        self.threads['betbrain_parse']=betbrain_parse()
#        
##        self.threads['betbrain_futureasian']=betbrain_futureasian()
##        self.threads['betbrain_futurebig']=betbrain_futurebig()
##        self.threads['betbrain_futureeuro']=betbrain_futureeuro()
##        
##        self.threads['betbrain_todayasian']=betbrain_todayasian()
##        self.threads['betbrain_todaybig']=betbrain_todaybig()
##        self.threads['betbrain_todayeuro']=betbrain_todayeuro()
#        for i in func.getPath('day_range'):
#            self.threads['betbrain_euro_%s'%i]=betbrain_euro(i)
#            self.threads['betbrain_asian_%s'%i]=betbrain_asian(i)
#            self.threads['betbrain_big_%s'%i]=betbrain_big(i)
        
    #����״̬    
    def setstatus(self,params):
        if params:
            tmp=JsonUtil.read(params)
            for key in tmp:
                if tmp[key]:
                    self.start(key)
                else:
                    self.stop(key)
        return self._result({},[])
    
    #��ȡ״̬
    def getstatus(self):
        return self._result({},[mm.read(self.thread_status)])
        
    def start(self,key):
        if self.thread_status.has_key(key) and self.thread_status[key]=='0':
            self.threads[key]=globals()[key]()
            self.threads[key].setDaemon(True)
            self.threads[key].start()
            self.thread_status[key]='1'
    def stop(self,key):
        if self.thread_status.has_key(key) and self.thread_status[key]=='1':
            self.threads[key].stop()
            self.threads[key]=None
            self.thread_status[key]='0'
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''    
    p =betball_service()
    return Eas.Function.get_method_dict(p,prefix+'/')