#coding=gbk
#import curl
import urllib,urllib2
import traceback
import xml.dom.minidom
import time
import datetime
import sys, os
reload(sys)
sys.setdefaultencoding('gbk')
import re
import XmlConfig, urllib, urllib2
import XmlConfig
import Db.Mysql
import logging
import MiniXml
import base
import operator
class Aladdin_class:
    def __init__(self):
        '''���س��Ի������ļ�'''
        self.config = XmlConfig.list('/configuration/')
    def _fopen(self,path):
        
        content=''
        try:
            res = path
            resp = urllib2.urlopen(res,timeout=10)
            content = resp.read()
        except Exception,e:
            logging.info('����ҳ��%s�����쳣:%s!'%(path,e))
        return content
    
    def do_DF_GP(self,name):
        '''�ط���-��Ƶ��'''
        url  = self.config['services/'+name+'/url']
        adds = self.config['services/'+name+'/add']
        FileServerURL = self.config['settings/FileServerURL']
        
        title = '<?xml version=\"1.0\" encoding=\"GBK\"?><DOCUMENT>'
        for i in range(0,len(adds)):
            try:
                ixml = self.get_XML(adds[i]['opencodexml'], 'url')
                data = ixml.get('/xml/row')
                if  adds[i]['templetxml']=='/Templet/bdopencode.xml':
                    opentime = data['webstarttime']
                elif type(data) == dict:
                    opentime = data['opentime']
                    page = data
                elif type(data) == list:
                    opentime = data[0]['opentime']
                    page = data[0]
                if(len(opentime)>16):
                    struct_time = time.strptime(opentime,"%Y-%m-%d %H:%M:%S")
                elif(len(opentime)>12):
                    struct_time = time.strptime(opentime,"%Y-%m-%d %H:%M")
                else:
                    struct_time = time.strptime(opentime,"%Y-%m-%d")
                    
                date = datetime.datetime(struct_time[0], struct_time[1], struct_time[2]) 
                
                xml_data = date.strftime("%Y-%m-%d")
                starttime  = date.strftime("%m��%d��").replace('0','')
                end_date = date + datetime.timedelta(days=59)
                endtime = end_date.strftime("%m��%d��").replace('0','')
                
                
                fname = os.environ['_BASIC_PATH_'] +'/etc' + adds[i]['templetxml']
                ixml = self.get_XML(fname, 'local')
                t_xml = ixml.list('/DOCUMENT/item/')
                
                xml = '<item><key>'+t_xml['key']+'</key>'
                xml += '<display><url><![CDATA['+t_xml['display/url']+']]></url>'
                xml += ' <title>'+t_xml['display/title']+'</title>'
                xml += ' <showurl> <![CDATA['+t_xml['display/showurl']+']]></showurl>'
                xml += ' <pagesize>'+t_xml['display/pagesize']+'</pagesize>'
                xml += ' <date>'+xml_data+'</date>'
                xml += ' <content1>'+t_xml['display/content1']+'</content1>' 
                xml += ' <content2>'+(t_xml['display/content2'].replace('{EXPECT}',page['expect']).replace('{OPENDATE}',starttime).replace('{EXPDATE}',endtime))+'</content2>'
                
                try:
                    page['opencode'] = page['opencode'].decode('UTF-8').encode('GBK')
                except:
                    pass

                '''�㶫�òʿ������뺺��'''
                if  adds[i]['templetxml']!='/Templet/bdopencode.xml':
                    opencode = ''
                    if page.has_key('opencode'):
                        opencode = page['opencode'].split('|')
                    else:# page[0]['trycode']:
                        opencode = page['trycode']
                    if len(opencode) >1:
                        xml += '<content3>'+(t_xml['display/content3'].replace('{EXPECT}',page['expect']).replace('{OPENCODE1}',opencode[0].replace(',',' ')).replace('{OPENCODE2}',opencode[1]))+'</content3>'
                    else:
                       xml += '        <content3>'+(t_xml['display/content3'].replace('{EXPECT}',page['expect']).replace('{OPENCODE1}',opencode[0]).replace(',',' '))+'</content3>'
                else:
                    xml += '        <content3>'+t_xml['display/content3']+'</content3>'
                xml += '    </display>'
                xml += '   </item>'
                title  += xml
                
            except Exception,e:
                logging.info('do_DF_GP-xml��ȡ�쳣%s:'%e)   
        title += '</DOCUMENT>'
        try:
            atnum = base.upload(FileServerURL, url['value'], title)
        except Exception,e:
            logging.info('do_DF_GP-xmlд���쳣:'%e) 
              
    def do_WDLS(self,name):
        '''�������'''
        rs = self.get_WDLS_DB()
        
        url  =  self.config['services/service_ls/url']
        add  =  self.config['services/service_ls/add']
        tmp  =  self.config['services/service_ls/tmp']
        FileServerURL = self.config['settings/FileServerURL']
        
        XmlConfig.loadFile(os.environ['_BASIC_PATH_'] +'/etc' +tmp['value'])
        load_xml = XmlConfig.list('/DOCUMENT/item/')
      
        for r in rs:
            try:
                str_xml = ''
                '��ȡ����xml'
                path = url['value'].replace('{0}',str(r['stageid']))
                res = self._fopen(path)
                ixml = MiniXml.parseString(res)
                page = ixml.list('/database/detail/')
                
                str_xml  = '<?xml version="1.0" encoding="gbk"?><DOCUMENT><item><key>'+load_xml['key']+'</key><display>'
                str_xml += '<url><![CDATA['+load_xml['display/url'].replace('{0}',str(r['seasonid']))+']]></url><title>'+load_xml['display/title']+'</title>'
                str_xml += '<showurl><![CDATA['+load_xml['display/showurl']+']]></showurl><pagesize>'+load_xml['display/pagesize']+'</pagesize><date></date><content1></content1>'
                for i in range(0,len(page['aln'])):
                    str_xml += '<form col0="'+page['aln'][i]+'" col0link="" col1="'+page['tn'][i]+'" col1link="" col2="'+page['w'][i]+'/'+page['d'][i]+'/'+page['l'][i]+'" col2link="" col3="'+page['sc'][i]+'" col3link=""/>'
                str_xml += '<link linkurl="'+load_xml['display/link']['linkurl'].replace('{0}',str(r['seasonid']))+'" linkcontent="�����������" /></display></item></DOCUMENT>'
            except Exception,e:
                logging.info('do_WDLSƴ��xml�쳣��%s'%e)
                
            try:
                path = add['value'].replace('{0}',str(r['matchid']))
                atnum = base.upload(FileServerURL, path, str_xml.encode('gbk'))
            except Exception,e:
                logging.info('xmlд���쳣:'%e)
    def do_ZC(self):
        logging.info('do_ZC���������ݿ�ʼ')
        no_rq =[]
        rq =[]
        try:
            FileServerURL = self.config['settings/FileServerURL']
            td = datetime.date.today() #����
            od = datetime.timedelta(days=1)#ĳ��
            yd = td - od#����
            ydd = yd - od#ǰ��
            rs_new = self.getNewData(td,yd);
            rq = self.getOldData(td,od,'269',4) #����
            no_rq = self.getOldData(td, od,'354',4) #������
            
            #���� _test 
            rq_test = self.getOldData(td,od,'269',3) #����
            no_rq_test = self.getOldData(td, od,'354',3) #������
            
        except Exception,e:
            logging.info('���ݻ�ȡ�쳣%s:'%e)
        if no_rq and rq:
            xml = self.doaladinXml(rs_new,rq,no_rq)
            xml_test = self.doaladinXml(rs_new,rq_test,no_rq_test,'test')
            try:
                atnum = base.upload(FileServerURL, "/static/info/baidu/soccerdata/zucai.xml", xml.decode('gbk').encode("utf8"))
                atnum_new = base.upload(FileServerURL, "/static/info/baidu/soccerdata/new_zucai.xml", xml_test.decode('gbk').encode("utf8"))
                if atnum=='ok':
                    logging.info('��ʰ��������ɳɹ�')
                else:
                    logging.info('��ʰ���������ʧ��')
            except Exception,e:
                logging.info('xmlд���쳣:'%e)
        else:
            logging.info('����Ϊ��')
        logging.info('do_ZC���������ݽ���')
        
    def getBDMfALd(self):#�ٶ���Ѱ�����
        logging.info ('�ٶ���Ѱ�������ʼ')
        try:
            row = XmlConfig.list('/ald_data/')
            xml = '<?xml version="1.0" encoding="gbk" ?>';
            xml += '<DOCUMENT>';
            for i in row['row']:
                rs = urllib.urlopen(i['url']).read()
                title= re.compile(r'\<title\>([^<]*)<');
                content = re.compile(r'\<meta.*name="[dD]escription.*?content="([^"]*)"');
                title_str = title.findall(rs);
                content_str = content.findall(rs);
                xml +='<item>'; 
                key = i['key'];#.decode("utf-8").encode("gbk")
                cap = i['captur']
                #title=i['titleicon']
                xml +='<key>'+str(key)+'</key> '
                xml +='<display>'
                xml +='<url>'+str(i['url'])+'</url>'
                if len(title_str)>0 and len(content_str) :
                    xml +='<title>'+str(title_str[0])+'</title>'
                    xml +='<content>'+str(content_str[0])+'</content>'
                else:
                    xml +='<title></title>'
                    xml +='<content></content>'
                xml +='<showurl>www.500.com/</showurl>'
                xml +='<date>'+ datetime.datetime.now().strftime("%Y-%m-%d")+'</date>'
                xml +='<capture>'+cap+'</capture>'
                #xml +='<titleicon>'+title+'</titleicon>'
                xml += '</display></item>';
            xml +='</DOCUMENT>'
            xml =  xml.replace("&","&amp;")
            FileServerURL = self.config['settings/FileServerURL']
            path = '/static/info/baidu/soccerdata/bdmf.xml';
            
            atnum = base.upload(FileServerURL,path,xml)
            logging.info('�ٶ���Ѱ���������')
        except Exception,e:
            logging.info('�ٶ���Ѱ������쳣:%s'%e)

    def getOldXmlData(self,td,od,playid='269'):   
        data_new = []
        t_day = td
        m = 0
        while True:
            if (m)>2:
                break
            t_day = t_day - od
            t_url = 'http://www.500.com/static/500public/jczq/xml/hisdata/'+(str(t_day)[0:4])+'/'+(str(t_day)[4:])+'/hcount_'+playid+'.xml'#����
            t_url = t_url.replace("-","")
            old_d = self._fopen(t_url)
            xml_o = MiniXml.parseString(old_d)
            rs_old = xml_o.list("/xml/project/")
            if type(rs_old['row'])==dict:
                data_new.append(rs_old['row'])
                ''
            elif type(rs_old['row'])==list:
                data_new.extend(rs_old['row'])
            m = m+1
        return data_new
    def doOldData(self,data):
        tmp = []
        sorted_x = []
        if data:
            for d in data:
                id = d['id']
                c  = int(d['number_3'])+int(d['number_1'])+int(d['number_0'])
                args = {'id':id,'c':c}
                tmp.append(args)
        sorted_x = sorted(tmp, key=operator.itemgetter('c'),reverse=True)  
        return sorted_x
    
    def getOldData(self,td,od,playid='269',nc=4):
        #��ȡxml����
        data_new = self.getOldXmlData(td, od, playid)
        #����
        rs_t = self.doOldData(data_new)
        m = 0
        data = []
        for i in rs_t:
            if m >nc:
                break
            #i['id'] = 77883
            rs = self.getMatchMsgById(str(i['id']));
            if not rs: 
                continue
            if rs and rs['fixtureid']:
                #rs['fixtureid']=52990
                rs_od = self.getNamesByFixtureid(str(rs['fixtureid']))
                if not rs_od:
                    continue
                one = {}
                one['fid'] = rs['fixtureid']
                one['time'] = rs['matchtime']
                one['isright'] = rs['isright']
                one['homes'] = rs['homescore']
                one['guests'] = rs['guestscore']
                one['r'] = rs['rangqiu']
                one['resultspf'] = rs['resultspf']
                one['resultnspf'] = rs['resultnspf']
                if rs['plnspf']:
                    one['plnspf'] = rs['plnspf']
                else:
                    one['plnspf'] = ''
                one['plspf'] = rs['plspf']
                one['leg'] = rs_od['simplegbname'].decode("gbk")[0:4].encode("gbk")#��ȡ3���ַ�
                one['hname'] = rs_od['homesxname']
                one['aname'] = rs_od['awaysxname']
                data.append(one)
                m = m+1
        s_data = sorted(data, key=operator.itemgetter('time'),reverse=True) 
        return s_data
    '''��ȡ��������'''    
    def getNewData(self,td,yd):
        url_t = 'http://www.500.com/static/info/bifen/xml/livedata/jczq/'+str(td)+'IndexXml.xml';
        url_t = url_t.replace("-","")
        url_y = 'http://www.500.com/static/info/bifen/xml/livedata/jczq/'+str(yd)+'IndexXml.xml';
        url_y = url_y.replace("-","")
        data_new = []
        for i in [url_t,url_y]:
            new_d = self._fopen(i)
            xml = MiniXml.parseString(new_d)
            rs_new = xml.list("/m/")
            if type(rs_new['row'])==dict:
                data_new.append(rs_new['row'])
                ''
            elif type(rs_new['row'])==list:
                data_new.extend(rs_new['row'])
                
        data = []
        tmp = []
        n = 0
        if type(data_new)==dict:
            tmp.append(data_new)
        else:
            tmp = data_new
        for i in tmp:
            if n>2:
                break
            if i['status']>'0' and i['status']<'4':
                one = {}
                if i['isright']=='-1':
                    one['hname']=i['awaysx']
                    one['aname']=i['homesx']
                else:
                    one['hname']=i['homesx']
                    one['aname']=i['awaysx']
                d = i['d'].split(',')
                if i['pptv']!='|1|':
                    one['have'] = 0
                else:
                    one['have'] = 1
                if one['have']==0 and i['runningball_animation']=='1':
                    one['rb'] = 1
                else:
                    one['rb'] = 0
                one['fid']=d[0]
                one['leg']=d[5]
                one['r']=i['r']
                one['time']=i['StartTime']
                one['sorce']=['--']
                data.append(one)
                n = n+1
        return data
    
    def getMatchMsgById(self,id):
        sql = "select matchtime,fixtureid,isright,rangqiu,homescore,guestscore,resultspf,resultnspf,plspf,plnspf from t_jczq_matchfixture where id="+str(id)
        return Db.Mysql.get('info_web').queryOne(sql)
    def getNamesByFixtureid(self,fid):
        sql = "select simplegbname,homesxname,awaysxname from v_getfixturebaseinfo where fixtureid="+str(fid)
        return Db.Mysql.get('socodd_web').queryOne(sql)
    def get_WDLS_DB(self):  
        '''�����������'''
        sql ='''select a.stageid,a.matchid,a.seasonid from t_s_stage a inner join t_s_season b on a.seasonid=b.seasonid where a.matchid in(%s) and b.iscurrent=1 and a.iscurrent=1'''
        args=['106,92,93,58,107']
        return Db.Mysql.get('SoccerMaster').query(sql,args)
    
    def doaladinXml(self,data,rq,norq,new=''):
        list = ['���','�����Ʊ','��������','����','�ȷ�','����ȷ�','��ʱȷ�']
        xml='''<?xml version="1.0" encoding="UTF-8"?><DOCUMENT>'''
        for j in list:
            xml +='<item><key>'+j+'</key>'
            xml +="<display><url>http://live.500.com/2h1.php?0%7csiva%7cbaidu%7ca0001</url><title>���Ͷע_��������_�ȷ�ֱ��_500��Ʊ��</title>"
            xml +="<showurl>www.500.com/</showurl><date>"+str(datetime.date.today())+"</date>"
            xml +='<tab title="ʤƽ��" id="1"/><tab title="����ʤƽ��" id="2"/>'
            xml +='<tabtitle id="1" title7="�����Ϣ" title6="�ʹ�" title5="�Ͷ�" title4="�ȷ�" title3="����" title2="����" title1="����"/>'
            xml +='<tabtitle id="2" title7="�����Ϣ" title6="�ʹ�" title5="�Ͷ�" title4="�ȷ�" title3="����(����)" title2="����" title1="����"/>'
            m = 0
            for d in data:
                if d['have']:
                    xml +='<list id="1" href="http://live.500.com/tv/'+str(d['fid'])+'/2/?0%7csiva%7cbaidu%7cf0001" icoflag="1" con7="��Ƶֱ��" con6="--" con5="'+str(d['aname'])+'" con4="vs" con3="'+d['hname']+'" con2="'+d['leg']+'" con1="'+(str(d['time'])[5:10])+'"/>'
                    m = m+1
                elif d['rb']:
                    xml +='<list id="1" href="http://live.500.com/detail.php?0%7csiva%7cbaidu%7cf0001&amp;fid='+str(d['fid'])+'" icoflag="2" con7="����ֱ��" con6="--" con5="'+str(d['aname'])+'" con4="vs" con3="'+d['hname']+'" con2="'+d['leg']+'" con1="'+(str(d['time'])[5:10])+'"/>'
                    m = m+1
                if m>1:
                    break
            m_len = len(norq)
            if len(norq)>(5-m):
                m_len = 5-m
            for i in range(0,m_len):
                ico6_n_v = '--'
                ico6_n = ''
                isr_n =''
                isrq =''
                score_n = 'vs'
                if norq[i]['resultnspf']:
                    ico6_n_v = norq[i]['resultnspf']
                if str(norq[i]['homes'])!='-1':
                    score_n = str(norq[i]['homes'])+":"+str(norq[i]['guests'])
                if str(norq[i]['isright'])=='-1':
                    isr_n = '-r--1';
                if norq[i]['plnspf']:
                    ico6_n =  '('+str(norq[i]['plnspf'])+")"
                if str(norq[i]['isright']):
                    isrq = '('+str(rq[i]['r'])+")"
                xml +='<list id="1" href="http://odds.500.com/fenxi/shuju-'+str(norq[i]['fid'])+isr_n+'.shtml?0%7csiva%7cbaidu%7cf0001" con7="����" con6="'+str(ico6_n_v)+str(ico6_n)+'" con5="'+str(norq[i]['aname'])+'" con4="'+score_n+'" con3="'+norq[i]['hname']+'" con2="'+norq[i]['leg']+'" con1="'+(str(norq[i]['time'])[5:10])+'"/>'
            
            n=0
            for d in data:
                if d['have']:
                    xml +='<list id="2" href="http://live.500.com/tv/'+str(d['fid'])+'/2/?0%7csiva%7cbaidu%7cf0001" icoflag="1" con7="��Ƶֱ��" con6="--" con5="'+str(d['aname'])+'" con4="vs" con3="'+d['hname']+'" con2="'+d['leg']+'" con1="'+(str(d['time'])[5:10])+'"/>'
                    n = n+1
                elif d['rb']:
                    xml +='<list id="2" href="http://live.500.com/detail.php?0%7csiva%7cbaidu%7cf0001&amp;fid='+str(d['fid'])+'" icoflag="2" con7="����ֱ��" con6="--" con5="'+str(d['aname'])+'" con4="vs" con3="'+d['hname']+'" con2="'+d['leg']+'" con1="'+(str(d['time'])[5:10])+'"/>'
                    n = n+1
                if n>1:
                    break
            n_len = len(rq)
            if len(norq)>(5-n):
                n_len = 5-n
            for i in range(0,n_len):
                ico6_v = '--'
                ico6 = ''
                isr = ''
                isrq =''
                score = 'vs'
                if rq[i]['resultspf']:
                    ico6_v = rq[i]['resultspf']
                if str(rq[i]['homes'])!='-1':
                    score = str(rq[i]['homes'])+":"+str(rq[i]['guests'])
                if str(rq[i]['isright'])=='-1':
                    isr = '-r--1'   
                if rq[i]['plnspf']:
                    ico6  = '('+str(rq[i]['plnspf'])+")"
                if str(rq[i]['isright']):
                    isrq = '('+str(rq[i]['r'])+")"
                xml +='<list id="2" href="http://odds.500.com/fenxi/shuju-'+str(rq[i]['fid'])+isr+'.shtml?0%7csiva%7cbaidu%7cf0001"   con7="����" con6="'+str(ico6_v)+str(ico6)+'" con5="'+str(rq[i]['aname'])+'" con4="'+score+'" con3="'+rq[i]['hname']+isrq+'" con2="'+rq[i]['leg']+'" con1="'+(str(rq[i]['time'])[5:10])+'"/>'
            if m>0 or n>0:
                xml +='<more href="http://live.500.com/?0%7csiva%7cbaidu%7cb0001" tile="�鿴ȫ������>>"/> '
            else:
                xml +='<more href="http://live.500.com/2h1.php?0%7csiva%7cbaidu%7cb0001" tile="�鿴ȫ������>>"/> '
            xml +='<wanfa title="��������" id="1"/> <wanfa title="��������" id="2"/> <wanfa title="ʤ����" id="3"/> '
            strJC = self.getJCZQData()
            strDC = self.getBJDCData()
            strSFC = self.getSFCData()
            xml +='<con id="1" href="http://trade.500.com/jczq/?0%7csiva%7cbaidu%7cc0001" btn="����Ͷע" content="'+str(strJC)+'"/>'
            xml +='<con id="2" href="http://trade.500.com/bjdc/?0%7csiva%7cbaidu%7cd0001" btn="����Ͷע" content="'+str(strDC)+'"/>'
            xml +='<con id="3" href="http://trade.500.com/sfc/?0%7csiva%7cbaidu%7ce0001"  btn="����Ͷע" content="'+str(strSFC)+'"/>'
            if new:
                xml +="<tabtest>1</tabtest></display>"
            else:
                xml +="</display>"
            xml +='</item>'
        xml +="</DOCUMENT>"
        return xml
    def getSFCData(self):
        try:
            url_e = 'http://www.500.com/static/public/sfc/xml/expect/allowbuy/expect.xml'
            url_m = 'http://www.500.com/static/public/sfc/daigou/xml/{0}.xml'
            d = self._fopen(url_e)
            xml = MiniXml.parseString(d)
            xml_d = xml.list("/xml/")
            team = []
            for e in  xml_d['row']:
                if e['active']=='1':
                    url_m = url_m.replace("{0}", e['expect'])
                    d = self._fopen(url_m)
                    xml = MiniXml.parseString(d)
                    xml_m = xml.list("/xml/")
                    m = 0 
                    for i in xml_m['row']:
                        if m>1:
                            break;
                        m_str = (i['hometeam']+'VS'+i['guestteam']).decode("utf-8").encode("gbk")
                        m_str = m_str.replace("&nbsp;","").replace(" ","")
                        team.append(m_str)
                        m = m+1
            m_str = '��14����Ͷע��'+(",".join(team))+'��'   
            return     m_str
        except Exception,e:
            return '��ע��߽���5,000,000Ԫ'
            logging.info('Aladdin_Thread�쳣(%s)��%s'% (self.name ,e))
    def getBJDCData(self):
        try:
            url_e ='http://www.500.com/static/public/bjdc/xml/hcount/expect.xml'
            url_m ='http://www.500.com/static/public/bjdc/xml/process/{0}.xml'
            url_t ='http://www.500.com/static/500info/bjdc/hcount/{0}_34.xml'
            count = 0
            d = self._fopen(url_e)
            xml = MiniXml.parseString(d)
            xml_d = xml.list("/xml/")
            if len(xml_d['row'])>0:   
                url_m = url_m.replace("{0}",xml_d['row'][0]['expect'])     
                d = self._fopen(url_m)
                xml = MiniXml.parseString(d)
                xml_m = {}
                m_d = {}
                xml_m = xml.list("/xml/matchteams/")
                if  xml_m['matchteam']:
                    for m in xml_m['matchteam']:
                        if m["isdelay"] == '0':
                            count = count+1
                            t_m={}
                            t_m['hname'] = m['homesxname']
                            t_m['aname'] = m['guestsxname']
                            t_m['id'] = m['fixtureid']
                            m_d[m['fixtureid']] = t_m
                t_d = []
                url_t = url_t.replace("{0}",xml_d['row'][0]['expect'])     
                d = self._fopen(url_t)
                xml = MiniXml.parseString(d)
                xml_t = xml.list("/xml/project/")
                if xml_t['row']:
                    for t in xml_t['row']:
                        if t['fixtureid'] in m_d.keys():
                            c = int(t['number_3'])+int(t['number_1'])+int(t['number_0'])
                            args = {"c":c}
                            args = dict(args.items()+m_d[t['fixtureid']].items())
                            t_d.append(args)
                sorted_x = sorted(t_d, key=operator.itemgetter('c'),reverse=True)              
                m = 0
                team = [];
                for j in sorted_x:
                    if m>1:
                        break;
                    t_str = (j['hname']+"VS"+j['aname']).decode("utf-8").encode("gbk")
                    team.append(t_str.replace(" ",""))
                    m = m+1
                m_str = '��'+str(count)+'����Ͷע��'+(",".join(team))+'��'
                return m_str
        except Exception,e:
            return 'ÿ�����130������,���𸡶�'
            logging.info('Aladdin_Thread�쳣(%s)��%s'% (self.name ,e))
    def getJCZQData(self):
        try:
            url_d = "http://www.500.com/static//public/jczq/xml/match/match.xml"
            url_e  = "http://www.500.com/static/public/jczq/xml/endtime/match.xml"
            url_t = 'http://www.500.com/static/500public/jczq/xml/hcount/hcount_269.xml'
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            count = 0#Ϊ��������
            #��������
            d = self._fopen(url_d)
            xml = MiniXml.parseString(d)
            xml_d = xml.list("/xml/matches/matchdate/")
            d_d = {};
            for i in xml_d['match']:
                t_d = {}
                t_d['id'] = i['id']
                if i['isright']=='-1':
                    t_d['aname'] = i['homesxname']
                    t_d['hname'] = i['awaysxname']
                else:
                    t_d['aname'] = i['awaysxname']
                    t_d['hname'] = i['homesxname']
                d_d[i['id']] = t_d
            'apiendtime'
            #����ʱ������
            e_d = {}
            d = self._fopen(url_e)
            xml = MiniXml.parseString(d)
            xml_e = xml.list("/xml/")
            for e in  xml_e['row']:
                if e['apiendtime']>now and (e['infoid'] in d_d.keys()):
                    count = count+1
                    e_d[e['infoid']] = d_d[e['infoid']]
            #Ͷע����
            t_d = []
            d = self._fopen(url_t)
            xml = MiniXml.parseString(d)
            xml_t = xml.list("/xml/project/")
            for t in  xml_t['row']:
                if t['id'] in e_d.keys():
                    c = int(t['number_3'])+int(t['number_1'])+int(t['number_0'])
                    args = {"c":c}
                    args = dict(args.items()+e_d[t['id']].items())
                    t_d.append(args)
            sorted_x = sorted(t_d, key=operator.itemgetter('c'),reverse=True)   
            #��ȡ��������
            m = 0
            team = [];
            for j in sorted_x:
                if m>1:
                    break;
                t_str = (j['hname']+"VS"+j['aname']).decode("utf-8").encode("gbk")
                team.append(t_str.replace(" ",""))
                m = m+1
            m_str = '��'+str(count)+'����Ͷע��'+(",".join(team))+'��'
            return m_str
        except Exception,e:
            return '�����ʸߴ�69%�����ع̶�����'
            logging.info('Aladdin_Thread�쳣(%s)��%s'% (self.name ,e))
    def get_XML(self,path,type='local'):
        ''''''
        if type=='local':
            f = open(path, 'r')
            s = f.read()
            f.close()
            return MiniXml.parseString(s)
            
        elif type=='url':
            resp = urllib2.urlopen(path, timeout=10)
            res = resp.read()
            return MiniXml.parseString(res)
        else:
            pass
        