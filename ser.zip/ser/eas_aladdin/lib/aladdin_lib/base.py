#coding=gbk
import logging
import curl
import traceback

def write_log(msg):
    logging.info(msg)

def fopen(path,post={},msg=''):
    content=''
    try:
        request=curl.Curl()
        #���ó�ʱʱ��
        request.set_timeout(30)
        if not post:
            content=request.get(path)
        else:
            content=request.post(path,post)
        request.close()
    except Exception,e:
         write_log('%s����ҳ��%s�����쳣:%s!'%(msg,path,e))
         write_log(traceback.format_exc())
    return content

def upload(url, path, body):    
    values = {'url'   :   path, 'content'   :   body}
    res = fopen(url, values)
    return res

def alert(x,t=0):
    print x
    if t:
        exit()