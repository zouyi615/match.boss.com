#coding:gbk
import time
import threading

import logging

from aladdin_lib.aladdin_class import Aladdin_class

class Aladdin_Thread(threading.Thread):
    def __init__(self,name):
        threading.Thread.__init__(self)
        self.name = name
        self.ALC = Aladdin_class()
    
    def run(self):
        while True:
            try:
                if self.name=='service_zc':
                    self.ALC.do_ZC()
                elif self.name=='service_bdmf':
                    self.ALC.getBDMfALd()
                elif self.name!='service_ls':
                    self.ALC.do_DF_GP(self.name)
                elif self.name=='service_ls':
                    self.ALC.do_WDLS(self.name)
                else:
                   lo
                if self.name=='service_bdmf':#�ٶ����
                    second =20*7*3600
                else:
                    second = float((self.ALC.config['services/'+self.name+'/time']['value']))
                time.sleep(second)
            except Exception,e:
                logging.info('Aladdin_Thread�쳣(%s)��%s'% (self.name ,e))
                time.sleep(3600)
    