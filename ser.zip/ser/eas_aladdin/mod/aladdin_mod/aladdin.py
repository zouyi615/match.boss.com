#coding:gbk
import time
import threading

import Eas.Extend
import Eas.Function
import logging

from aladdin_lib.aladdin_class import Aladdin_class
from aladdin_lib.aladdin_thread import Aladdin_Thread


class Aladdin(Eas.Extend.Common):
    def __init__(self):
        self.arr = ['service_df','service_gp','service_ls','service_zc','service_bdmf']
        self.do_thread()
        '''�ط��ʣ���Ƶ�ʣ��������'''
    def do_thread(self):
        threads = []
        for k in self.arr:
            t = Aladdin_Thread(k)
            threads.append(t) 
            #t.setDaemon(False)
            t.start()
            
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''    
    demo =Aladdin()
    return Eas.Function.get_method_dict(demo, prefix+'/')