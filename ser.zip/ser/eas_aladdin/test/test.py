#coding=gbk
import sys, os
reload(sys)
sys.setdefaultencoding('gbk')
#print sys.getdefaultencoding()

import time
#import json
import threading
import traceback
import signal
import urllib, urllib2
import traceback
import datetime

import xml.dom.minidom
import sys, os
reload(sys)
sys.setdefaultencoding('gbk')


if not os.environ.has_key('_BASIC_PATH_'):
    _BASIC_PATH_ = os.path.abspath(__file__)
    _BASIC_PATH_ = _BASIC_PATH_[:_BASIC_PATH_.rfind('/test/')]
    os.environ['_BASIC_PATH_'] = _BASIC_PATH_
if sys.path.count(os.environ['_BASIC_PATH_'] + '/lib') == 0:
    sys.path.append(os.environ['_BASIC_PATH_'] + '/mod')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib/common')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs/pypi')

import xml.dom.minidom
import re
import XmlConfig, urllib, urllib2
import Db.Mysql
import MiniXml
from datetime import timedelta, date 
#import functions
import base64
from BeautifulSoup import BeautifulSoup
import logging
import curl
#from dlcClass import zoushi,omit
#from klsfClass import zoushi,omit

path = ''
atnum = 0
XmlConfig.setEncoding("GBK")
XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/db.xml')

XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/config.xml')
XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/AladdinConfig.xml')




#p = omit.omit()
#p = zoushi.zoushi()
atnum = ""
if 1:
    if 1:
#����ʼ#
        cofing = XmlConfig.list('/configuration/')
        rul = cofing['settings/FileServerURL']
       # for add in adds:
       #     XmlConfig.loadFile(os.environ['_BASIC_PATH_'] +'/etc' + add['templetxml'])
       #     t_xml = XmlConfig.list('/DOCUMENT/item/')
       #     #print t_xml
       #     
            #print str(t_xml['display/content2'])
            #print type(t_xml['display/content2'])
       #     print t_xml['display/content2'].replace('{EXPECT}','d')
       #    exit()
        '''�����������'''
        #ql='''select * from pre_service_meeting limt %s,1''';
        
        '''�ط���-��Ƶ��'''
        url = cofing['services/service_df/url']
        adds = cofing['services/service_df/add']
        
        title = '<?xml version=\"1.0\" encoding=\"gbk\" ?><DOCUMENT>'
        
        logging.info('start')
        for i in range(0, len(adds)):
            #try:
                resp = urllib2.urlopen(adds[i]['opencodexml'], timeout=10)
                res = resp.read()
            
                ixml = MiniXml.parseString(res)
                data = ixml.get('/xml/row')
                opentime = ''
                if  adds[i]['templetxml']=='/Templet/bdopencode.xml':
                    opentime = data['webstarttime']
                elif type(data) == dict:
                    opentime = data['opentime']
                    page = data
                elif type(data) == list:
                    opentime = data[0]['opentime']
                    page = data[0]
            
                if(len(opentime)>16):
                    struct_time = time.strptime(opentime,"%Y-%m-%d %H:%M:%S")
                elif(len(opentime)>12):
                    struct_time = time.strptime(opentime,"%Y-%m-%d %H:%M")
                else:
                    struct_time = time.strptime(opentime,"%Y-%m-%d")
                #end_datedate=datetime.datetime(struct_time[0],struct_time[1],struct_time[2])  
                #opentime = time.strptime(opentime, "%Y-%m-%d %H:%M:%S")
                date = datetime.datetime(struct_time[0], struct_time[1], struct_time[2]) 
                
                starttime  = date.strftime("%m��%d��")
                end_date = date + datetime.timedelta(days=59)
                endtime = end_date.strftime("%m��%d��")
                
                #endtime= date + datetime.timedelta(days =59)
                fname = os.environ['_BASIC_PATH_'] +'/etc' + adds[i]['templetxml']
                f = open(fname, 'r')
                s = f.read()
                f.close()
                ixml = MiniXml.parseString(s)
                
                
                t_xml = ixml.list('/DOCUMENT/item/')
                xml = '<item><key>'+t_xml['key']+'</key>'
                xml += '<display><url>'+t_xml['display/url']+'</url>'
                xml += ' <title>'+t_xml['display/title']+'</title>'
                xml += ' <showurl>'+t_xml['display/showurl']+'</showurl>'
                xml += ' <pagesize>'+t_xml['display/pagesize']+'</pagesize>'
                xml += ' <date>'+opentime+'</date>'
                xml += ' <content1>'+t_xml['display/content1']+'</content1>'
                
                xml += ' <content2>'+(t_xml['display/content2'].replace('{EXPECT}',page['expect']).replace('{OPENDATE}',starttime).replace('{EXPDATE}',endtime))+'</content2>'
                if  adds[i]['templetxml']!='/Templet/bdopencode.xml':
                    opencode = ''
                    if page.has_key('opencode'):
                        opencode = page['opencode'].split('|')
                    else:# page[0]['trycode']:
                        opencode = page['trycode']
                    if len(opencode) >1:
                        xml += '<content3>'+(t_xml['display/content3'].replace('{EXPECT}',page['expect']).replace('{OPENCODE1}',opencode[0].replace(',',' ')).replace('{OPENCODE2}',opencode[1]))+'</content3>'
                    else:
                       xml += '        <content3>'+(t_xml['display/content3'].replace('{EXPECT}',page['expect']).replace('{OPENCODE1}',opencode[0]))+'</content3>'
                
                xml += '    </display>'
                xml += '   </item>'
                title  += xml
            #except :
            #    i += 1
        title += '</DOCUMENT>'      
        print title 
        #sres = fopen(rul, title)
        content = ''
        msg = ''
        post = {'url'   :   url['value'], 'content'   :   title}
        try:
            request = curl.Curl()
            #���ó�ʱʱ��
            request.set_timeout(30)
            if not post:
                content = request.get(rul)
            else:
                content = request.post(rul, post)
            request.close()
        except Exception, e:
             print('%s����ҳ��%s�����쳣:%s!' % (msg, path, e))
             print(traceback.format_exc())
        print content
        #XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/Templet/leaguematch.xml')
        #t_xml = XmlConfig.list('/DOCUMENT/ls_item/')
        '''
        for r in rs:
            path = add['value'].replace('{0}',str(r['stageid']))
            
            resp = urllib2.urlopen(path,timeout=10)
            res = resp.read()
            #print res
            ixml = MiniXml.parseString(res)
            print type(ixml)
            print ixml.domToDict(res)
            exit()
            #page = ixml.get('/xml/row')
       '''     
           
            
                
#�������#
print path, atnum


         
