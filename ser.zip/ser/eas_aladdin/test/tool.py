#coding=gbk
import sys, os
reload(sys)
sys.setdefaultencoding('gbk')
#print sys.getdefaultencoding()

import time
#import json
import threading
import traceback
import signal
import urllib,urllib2
import traceback
import datetime

import xml.dom.minidom
import sys, os
reload(sys)
sys.setdefaultencoding('gbk')


if not os.environ.has_key('_BASIC_PATH_'):
    _BASIC_PATH_ = os.path.abspath(__file__)
    _BASIC_PATH_ = _BASIC_PATH_[:_BASIC_PATH_.rfind('/test/')]
    os.environ['_BASIC_PATH_'] = _BASIC_PATH_
if sys.path.count(os.environ['_BASIC_PATH_'] + '/lib') == 0:
    sys.path.append(os.environ['_BASIC_PATH_'] + '/mod')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib/common')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs/pypi')

import xml.dom.minidom
import re
import XmlConfig, urllib, urllib2
import Db.Mysql
import MiniXml
import datetime
#import functions
import base64
from BeautifulSoup import BeautifulSoup
import logging
#from dlcClass import zoushi,omit
#from klsfClass import zoushi,omit

path = ''
atnum = 0
XmlConfig.setEncoding("GBK")
XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/db.xml')

XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/config.xml')
XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/AladdinConfig.xml')




#p = omit.omit()
#p = zoushi.zoushi()
atnum = ""
if 1:
    if 1:
#����ʼ#
        cofing = XmlConfig.list('/configuration/')
        url  = cofing['services/service_ls/url']
        add = cofing['services/service_ls/add']
        tmp  = cofing['services/service_ls/tmp']
        time  = cofing['services/service_ls/time']
       # adds = cofing['services/service_df/add']
       # for add in adds:
       #     XmlConfig.loadFile(os.environ['_BASIC_PATH_'] +'/etc' + add['templetxml'])
       #     t_xml = XmlConfig.list('/DOCUMENT/item/')
       #     #print t_xml
       #     
            #print str(t_xml['display/content2'])
            #print type(t_xml['display/content2'])
       #     print t_xml['display/content2'].replace('{EXPECT}','d')
       #    exit()
        '''�����������'''
        #ql='''select * from pre_service_meeting limt %s,1''';
        sql ='''select a.stageid,a.matchid,a.seasonid from t_s_stage a inner join t_s_season b on a.seasonid=b.seasonid where a.matchid in(%s) and b.iscurrent=1 and a.iscurrent=1'''
        args=['106,92,93,58,107']
        rs = Db.Mysql.get('SoccerMaster').query(sql,args)
        XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/Templet/leaguematch.xml')
        t_xml = XmlConfig.list('/DOCUMENT/ls_item/')
        
        for r in rs:
            path = add['value'].replace('{0}',str(r['stageid']))
            
            resp = urllib2.urlopen(path,timeout=10)
            res = resp.read()
            #print res
            ixml = MiniXml.parseString(res)
            print type(ixml)
            print ixml.domToDict(res)
            exit()
            #page = ixml.get('/xml/row')
            
           
            
                
#�������#
print path, atnum
