#coding:gbk
import time
import Db.Mysql
from app.func import com
from app.func import globals
class db_bbs:
    def __init__(self):
        pass
    
    def getKjTimeByExpect(self,lot,expect):
        sql=''
        if lot=='sfc':
            sql='select resulttime from t_sfc_periodical where periodicalnum=%s'
        elif lot=='jq4':
            sql='select resulttime from t_jq4_periodical where periodicalnum=%s'
        elif lot=='zc6':
            sql='select resulttime from t_zc6_periodical where periodicalnum=%s'
        elif lot=='dlt':
            sql='select resulttime from t_dlt_periodical where periodicalnum=%s'
        elif lot=='pls':
            sql='select resulttime from t_pls_periodical where periodicalnum=%s'
        elif lot=='plw':
            sql='select resulttime from t_plw_periodical where periodicalnum=%s'
        elif lot=='qxc':
            sql='select resulttime from t_qxc_periodical where periodicalnum=%s'
        elif lot=='eexw':
            sql='select resulttime from t_eexw_periodical where periodicalnum=%s'
        elif lot=='ssq':
            sql='select resulttime from t_ssq_periodical where periodicalnum=%s'  
        elif lot=='qlc':
            sql='select resulttime from t_qlc_periodical where periodicalnum=%s'
        elif lot=='sd':
            sql='select resulttime from t_sd_periodical where periodicalnum=%s'
        else:
            sql=''
        if sql:
            return Db.Mysql.get('InfoSlave').queryOne(sql%expect)
        else:
            return None
    
    '''��ȡĳ������ĳ�ڿ���ʱ��֮ǰ ����20������'''
    def getKjThreadList(self,fid,dateline,ftype=''):
        sql='SELECT tid,subject,dateline FROM pre_forum_thread where displayorder>=0 and fid=%s and dateline<=%s'%(fid,dateline)
        if ftype:
            sql+=' and typeid=%s'%ftype
        sql+=' order by tid desc limit 20'
        return Db.Mysql.get('BbsSlave').query(sql)