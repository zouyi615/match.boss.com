#coding:gbk
''''ʤ����������Ϣ����'''
import traceback,time
from app.func import globals
from app.core.base import base
class create(base):
    def __init__(self):
        super(create,self).__init__('create')
            
    def _exec(self):
        content=self._fopen(self.config('datasource/lot_expect_url'))
        xml=globals.parseXml(content)
        if xml:
            node_arr=xml.getElementsByTagName('lottery')
        else:
            node_arr=[]
        lot_arr={}
        for node in node_arr:
            lotname=node.getElementsByTagName('lotshortname')[0].firstChild.nodeValue.encode('gbk')
            if lotname in ['sfc','jq4','zc6','dlt','eexw','qxc','pls','plw','ssq','qlc','sd']:
                expect=node.getElementsByTagName('periodicalnum')[0].firstChild.nodeValue.encode('gbk')
                lot_arr[lotname]=[expect]
        
        self._kj_api(lot_arr)
    
    
    '''����ҳ����������'''
    def _kj_api(self,lot_arr):
        if lot_arr:
            for lot in lot_arr:
                for expect in lot_arr[lot]:
                    try:
                        '''ͨ���ں� ��ȡ����ʱ��'''
                        info=self._callDb('db_bbs','getKjTimeByExpect',lot,expect)
                        if info and info['resulttime']:
                            ftype=self.config('datasource/bbs_ftype_map/%s'%lot)
                            dateline=int(time.mktime(time.strptime('%s'%info['resulttime'],'%Y-%m-%d %H:%M:%S')))
                            list=self._callDb('db_bbs','getKjThreadList',self.config('datasource/bbs_form_maps/%s'%lot),dateline,ftype)
                            if list:
                                globals.post(list,self.config('datasource/kaijiang_bbs_thread_url')%(lot,expect))                   
                    except:
                        self._log('[thread:%s]���ɿ���������Ϣ�����쳣:%s'%(self.tname,traceback.format_exc()))