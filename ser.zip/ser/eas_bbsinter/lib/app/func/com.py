#coding:gbk
import logging
import urllib,urllib2,curl
import app.config.config_common as cf
'''��ȡ������Ϣ'''
def config(key):
    result=None
    if key.find('/')!=-1:
        p=key.split('/')
    else:
        p=[key]
    l=len(p)
    if l==1 and cf.config.has_key(l):
        result=cf.config[p[0]]
    elif l==2 and cf.config[p[0]].has_key(p[1]):
        result=cf.config[p[0]][p[1]]
    elif l==3 and cf.config[p[0]][p[1]].has_key(p[2]):
        result=cf.config[p[0]][p[1]][p[2]]
    elif l==4 and cf.config[p[0]][p[1]][p[2]].has_key(p[3]):
        result=cf.config[p[0]][p[1]][p[2]][p[3]]
    return result

'''
        ��ȡurlҳ������
   url:ҳ��url
   param:����
   msg:��ʾ��Ϣ
'''
def fopen(url,param={},msg=''):
    try:
        request=curl.Curl()
        #���ó�ʱʱ��
        request.set_timeout(30)
        if not param:
            content=request.get(url)
        else:
            content=request.post(url,param)
        request.close()
    except Exception,e:
         log('%s����ҳ��%s�����쳣:%s!'%(msg,url,e))
    return content
'''��־���'''
def log(msg):
    logging.info(msg)