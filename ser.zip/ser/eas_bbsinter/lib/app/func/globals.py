#coding:gbk
import traceback
import app.func.com as com
import XmlUtil,time,re
def parseXml(html):
    '''����xml'''
    if html and html.find('<?xml ')!=-1:
        dom=XmlUtil.parseString(html)
    else:
        dom=None
    return dom

def data_format(list):
    str="["
    sp=''
    for row in list:
        str+=sp+'["%s","%s","%s","%s"]'%(row['tid'],row['subject'],row['dateline'],com.config('datasource/thread_format_url')%row['tid'])
        sp=","
    str+="]"
    return str

def post(list,path):
    content=data_format(list)
    content=com.fopen(com.config('datasource/interface_url'),{'url':path,'content':content})
    if content!='ok':
        com.log('[post]����%s��̬�ļ�����ʧ��!'%path)
    