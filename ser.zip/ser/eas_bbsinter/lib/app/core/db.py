#coding:gbk
__MATCHINFODB__={}
'''����ģʽ'''
def getInstance(k):
    if not __MATCHINFODB__.has_key(k):
        __MATCHINFODB__[k]=factory(k)
    return __MATCHINFODB__[k]

'''����ģʽ����db����'''
def factory(k,*args):
    path='app.%s'%(k.replace('_','.'))
    moudle=__import__(path,False,locals(),'*')
    return getattr(moudle,k)(*args)

def call(object,func,*args):
    return getattr(object,func)(*args)

def _call(clas,func,*args):
    return call(getInstance(clas),func,*args)