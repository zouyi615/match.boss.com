#coding:gbk
import time,logging
import EasClient
import Eas.Extend
import Eas.Function
import JsonUtil
from app.thread.create import create
class info(Eas.Extend.Common):
    def __init__(self):
       p=create()
       p.setDaemon(True)
       p.start()
        
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''    
    p=info()
    return Eas.Function.get_method_dict(p, prefix+'/')