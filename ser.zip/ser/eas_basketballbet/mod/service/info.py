#coding:gbk
import time,logging
import EasClient
import Eas.Extend
import Eas.Function
import JsonUtil
class info(Eas.Extend.Common):
    def __init__(self):
        self.threads_status={
            'match_stat':'0','match_score':'0','match_sc_today':'0','match_sc_fixture':'0','match_zr':'0','match_tj':'0','euro_today':'0','euro_fixture':'0','asian_today':'0','asian_fixture':'0','score_today':'0','score_fixture':'0'
        }
        self.threads={}
        self.init_all()
    '''��ʼ��'''
    def init_all(self):        
        for key in self.threads_status:
            self.start(key)
            if key in ['match_sc_today','match_sc_fixture']:
                time.sleep(60)
            else:
                time.sleep(1)
    '''�����߳�״̬'''
    def setStatus(self,params):
        if params!=None and params!='':
            t=JsonUtil.read(params)
            for k in t:
                if int(t[k])==1:
                    self.start(k)
                elif int(t[k])==0:
                    self.stop(k)
        return self._result({},[])
    
    '''��ȡ�߳�״̬'''
    def getStatus(self,key=''):
        if key=='':
            return self._result({},[self.threads_status]) 
        else:
            if self.threads_status.has_key(key):
                return self._result({},[{'status':self.threads_status[key]}])
            else:
                return self._result({},[{'status':0}])
    '''��ʼ'''
    def start(self,key):
        if self.threads_status[key]=='0':
            #����ģ��
            moudle=__import__('app.threads.%s'%key,False,locals(),'*')
            #�����̶߳���
            p=getattr(moudle,key)()
            #������������ͬ���˳�
            p.setDaemon(True)
            p.start()
            self.threads[key]=p
            self.threads_status[key]='1'
    '''ֹͣ'''
    def stop(self,key):
        if self.threads_status[key]=='1':
            self.threads[key].stop()
            self.threads[key]=None
            self.threads_status[key]='0'            
    
    '''��ȡƥ����������'''
    def getMatchData(self):
        if self.threads['match_sc']!=None:
            data=self.threads['match_sc'].on_getData()
        else:
            data=[]
        return self._result({},data) 
    
    '''��ȡ������Ϣ'''
    def getZrData(self):
        if self.threads['match_zr']!=None:
            data=self.threads['match_zr'].on_getData()
            for r in data:
                for k in r:
                    r[k]=str(r[k])
        else:
            data=[]
        return self._result({},data)
        
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''    
    p=info()
    return Eas.Function.get_method_dict(p, prefix+'/')