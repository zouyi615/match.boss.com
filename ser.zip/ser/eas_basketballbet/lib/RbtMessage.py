#coding=utf-8
import sys
import time
import logging
import traceback
import XmlConfig
import dispatcher_rbt

msg_queue = dispatcher_rbt.Dispatcher()

def init():
    try:
        global msg_queue
        arg1 = sys.argv[1]
        prex_ = '/service/'+arg1
        groupname = XmlConfig.get(prex_+'/groupname')
        servicename = XmlConfig.get(prex_+'/servicename')
        md_serv_url = XmlConfig.get(prex_+'/md_serv_url')
        logging.debug('from msg init groupname is %s  \
                                    servicename is %s \
                                    md_serv_url is %s', \
                                    groupname, servicename, md_serv_url)
        res = msg_queue.init( (groupname, servicename), 'None', md_serv_url, 'write')
    except:
        logging.error('from msg init %s',traceback.format_exc())

def send(remotename, data, timeout=0):
    logging.info( "send to %s, msg is %s"%(remotename, data) )
    return msg_queue.send(remotename, data, timeout)

def unregist():
    msg_queue.unregist()
