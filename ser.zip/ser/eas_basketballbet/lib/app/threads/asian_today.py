#coding:gbk
from app.core.Base import Base
from app.func import Odds
'''��������'''
class asian_today(Base):
    def __init__(self):
        super(asian_today,self).__init__('asian_today')
    
    def do(self):
        #��ȡ���������Ϣ
        list=Odds.getTodayXmlMatch()
        #����δƥ�乫˾��
        pipei_fail=[]
        for r in list:
            #��ȡ�ó���������˾����
            oddslist=Odds.getOddAsianFromUrl(r['bet007_matchid'],r['isreverse'])
            for odds in oddslist:
                tmp=self.callDb('db_odds','getAsianCompanyInfo',odds['companyname'])
                if tmp:
                    companyid=int(tmp['id'])
                    source_bet007_b=int(tmp['source_bet007_b'])
                else:
                    source_bet007_b=companyid=0
                    
                if companyid>0 and source_bet007_b==1:
                    if self.callDb('db_odds','saveAsianOdds',r['matchid'],companyid,odds['homemoneyline'],odds['handicapline'],odds['awaymoneyline'])==-1:
                        self.writelog('[thread:asian_today]���ݿ���������쳣;data:{%s,%s,%s,%s,%s}!'%(r['matchid'],companyid,odds['homemoneyline'],odds['handicapline'],odds['awaymoneyline']))
                        
                elif companyid<=0 and odds['companyname'] not in pipei_fail:
                    pipei_fail.append(odds['companyname'])
                    
        #��¼δƥ��Ĺ�˾����
        if len(pipei_fail)>0:
            Odds.writeAsianCompanyLog(pipei_fail)