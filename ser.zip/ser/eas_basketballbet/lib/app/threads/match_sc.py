#coding:gbk
import time
from app.core.Base import Base
from app.func import Match
'''����ƥ��'''
class match_sc(Base):
    def __init__(self):
        super(match_sc,self).__init__('match_sc')
        self.data=[]
    
    def on_getData(self):
        return self.data
    
    def do(self):   
        match_data=[]
        
        #��ȡ����������Ϣ
        today_list=Match.getBet007Data(self.getPath('nbatodayscurl'))
              
        #��ȡδ��������Ϣ
        fixture_url=self.getPath('nbascurl')
        timestamp=time.time()
        fixture_list=[]
        for i in range(1,3):
            url=fixture_url%time.strftime('%Y-%m-%d',time.localtime(timestamp+i*24*3600))
            fixture_list.extend(Match.getBet007Data(url,'fixture'))
        
        #�����ݿ��ȡ7���ڵĶ�������
        match_list=self.callDb('db_match','getMatchData')
        team_list={}
        for r in match_list:
            key=unicode('%s_%s'%(r['HomeName_Bet007'],r['AwayName_Bet007']),'gbk')
            if not team_list.has_key(key):
                team_list[key]=[]
            team_list[key].append(r)
        match_list=None
        
        #�˶�����Դ�����ݿ��е�����������
        xml_data=[]
        flag=False
        for r in today_list:
            key1=unicode('%s_%s'%(r['homename'],r['awayname']),'gbk')#���Ͷ�һ�µ����
            key2=unicode('%s_%s'%(r['awayname'],r['homename']),'gbk')#���Ͷ��෴�����
            if team_list.has_key(key1):
                tmp_arr=team_list[key1]
            else:
                tmp_arr=[]
            if team_list.has_key(key2):
                tmp_arr.extend(team_list[key2])
                
            ispipei=0
            matchid=0
            #�ж��Ƿ������ӵı���
            for t in tmp_arr:
                if Match.compare('%s 00:00:00'%str(t['VSDate']).split(' ')[0],'%s 00:00:00'%r['matchtime'].split(' ')[0]):
                    r['matchid']=int(t['FixtureID'])
                    r['isjclq']=t['isJCZQ']
                    if r['homename']==t['HomeName_Bet007']:
                        r['isreverse']=0
                    else:
                        r['isreverse']=1
                    team_gb_tmp=self.callDb('db_match','getGBName',r['matchid'])
                    if team_gb_tmp:
                        r['homehkname']=team_gb_tmp[0]['homehkname']
                        r['awayhkname']=team_gb_tmp[0]['awayhkname']
                    else:
                        r['homehkname']=''
                        r['awayhkname']=''
                    xml_data.append(r)
                    flag=True
                    ispipei=1
                    matchid=r['matchid']
                    break
            match_data.append({'homename':r['homename'],'awayname':r['awayname'],'matchtime':r['matchtime'],'matchid':str(matchid),'ispipei':str(ispipei),'bet007_matchid':str(r['bet007_matchid']),'istoday':'1'})
            time.sleep(0.1)
        today_list=None
        
        #���ɵ���xml
        if flag:
            Match.savetoxml(self.getPath('today_match_xml'),xml_data)
        
        #�˶�����Դ�����ݿ���δ��һ�ܶ��������    
        xml_data=[]
        fix_flag=False
        for r in fixture_list:
            key1=unicode('%s_%s'%(r['homename'],r['awayname']),'gbk')#���Ͷ�һ�µ����
            key2=unicode('%s_%s'%(r['awayname'],r['homename']),'gbk')#���Ͷ��෴�����
            if team_list.has_key(key1):
                tmp_arr=team_list[key1]
            else:
                tmp_arr=[]
            if team_list.has_key(key2):
                tmp_arr.extend(team_list[key2])
            ispipei=0
            matchid=0
            #�ж��Ƿ�����֧��ӵı���
            for t in tmp_arr:
                if Match.compare('%s 00:00:00'%str(t['VSDate']).split(' ')[0],'%s 00:00:00'%r['matchtime'].split(' ')[0]):
                    r['matchid']=int(t['FixtureID'])
                    r['isjclq']=t['isJCZQ']
                    if r['homename']==t['HomeName_Bet007']:
                        r['isreverse']=0
                    else:
                        r['isreverse']=1
                    team_gb_tmp=self.callDb('db_match','getGBName',r['matchid'])
                    if team_gb_tmp:
                        r['homehkname']=team_gb_tmp[0]['homehkname']
                        r['awayhkname']=team_gb_tmp[0]['awayhkname']
                    else:
                        r['homehkname']=''
                        r['awayhkname']=''
                    xml_data.append(r)
                    fix_flag=True
                    ispipei=1
                    matchid=r['matchid']
                    break
            match_data.append({'homename':r['homename'],'awayname':r['awayname'],'matchtime':r['matchtime'],'matchid':str(matchid),'ispipei':str(ispipei),'bet007_matchid':str(r['bet007_matchid']),'istoday':'0'})
            time.sleep(0.1)
        fixture_list=None
        
        #����δ��һ��xml
        if fix_flag:
            Match.savetoxml(self.getPath('fixture_match_xml'),xml_data)
        self.data=match_data
        team_list=None
        match_data=None