#coding:gbk
import re
from app.core.Base import Base
from app.func import Odds
'''����'''
class match_zr(Base):
    def __init__(self):
        super(match_zr,self).__init__('match_zr')
        self.data=[]
    
    def on_getData(self):
        return self.data
    
    def do(self):
        #��ȡ���������Ϣ
        list=Odds.getTodayXmlMatch()
        #��ȡδ��������Ϣ
        fixture_list=Odds.getFixtureXmlMatch()
        list.extend(fixture_list)
        
        #��ȡ����Դurl������
        play_url=self.getPath('fbfixtureplay_play_url')
        player_table_reg=self.getPath('fbfixtureplay_play_zr_regex')
        #��Ա������
        player_name_reg=self.getPath('fbfixtureplay_play_zrname_regex')
        #�˲�����
        player_ss_reg=self.getPath('fbfixtureplay_play_ss_regex')
        #��������
        player_pl_regex=self.getPath('fbfixtureplay_pl_regex')
        
        #����
        zc_arr=[]
        for r in list:
            try:
                #��ȡ������Ϣ
                tmp=self.curl(play_url%r['bet007_matchid'],{},20)
                tmp['CONTENT']=tmp['CONTENT'].decode('utf-8','ignore').encode('gbk','ignore') 
                ct_tmp=re.findall(r'%s'%player_table_reg,tmp['CONTENT'])
                if len(ct_tmp)==4:
                    #������ѡ
                    home_zx=''
                    sp=''
                    player_tmp=re.findall(r'%s'%player_name_reg,ct_tmp[0])
                    for t in player_tmp:
                        home_zx+=sp+t[0].strip()+','+t[2].strip()+','+t[1].strip()
                        sp='|'
                    
                    #���Ӻ�
                    home_hb=''
                    sp=''
                    player_tmp=re.findall(r'%s'%player_name_reg,ct_tmp[1])
                    for t in player_tmp:
                        home_hb+=sp+t[0].strip()+','+t[2].strip()+','+t[1].strip()
                        sp='|'
                    
                    #�Ͷ���ѡ
                    away_zx=''
                    sp=''
                    player_tmp=re.findall(r'%s'%player_name_reg,ct_tmp[2])
                    for t in player_tmp:
                        away_zx+=sp+t[0].strip()+','+t[2].strip()+','+t[1].strip()
                        sp='|'
                    
                    #�ͶӺ�
                    away_hb=''
                    sp=''
                    player_tmp=re.findall(r'%s'%player_name_reg,ct_tmp[3])
                    for t in player_tmp:
                        away_hb+=sp+t[0].strip()+','+t[2].strip()+','+t[1].strip()
                        sp='|'
                    player_tmp=t=None
                    
                    
                    #�˲�
                    ct_tmp=re.findall(r'%s'%player_ss_reg,tmp['CONTENT'])
                    home_ss_arr=[]
                    away_ss_arr=[]
                    for t in ct_tmp:
                        if t[0]==r['homehkname']:
                            home_ss_arr.append(',%s,%s'%(t[1],t[2]))
                        elif t[0]==r['awayhkname']:
                            away_ss_arr.append(',%s,%s'%(t[1],t[2]))
                    home_sb='|'.join(home_ss_arr)
                    away_sb='|'.join(away_ss_arr)
                    home_ss_arr=away_ss_arr=None
                    
                    #����
                    ct_tmp=re.findall(r'%s'%player_pl_regex,tmp['CONTENT'])
                    if ct_tmp:
                        notic=Odds.convtosimple(ct_tmp[0])
                        notic,num=re.subn(r'<[^>]*>','',notic)
                    else:
                        notic=''
                    zc_arr.append({'matchid':r['matchid'],'matchtime':r['matchtime'],'homename':r['homename'],'awayname':r['awayname'],'isreverse':r['isreverse'],'home_sf':home_zx,'home_tb':home_hb,'away_sf':away_zx,'away_tb':away_hb,'home_sb':home_sb,'away_sb':away_sb,'notic':notic})
            except Exception,e:
                self.writelog('[thread:match_zr]�������ݳ����쳣:%s'%e)
        for r in zc_arr:
            #������Ա��Ϣ
            self.callDb('db_odds','saveplayers',r)
            #��������
            self.callDb('db_odds','savepl',r)
        self.data=zc_arr
        zc_arr=None