#coding:gbk
from app.core.Base import Base
from app.func import Odds
'''�����ܷ�ץȡ'''
class score_today(Base):
    def __init__(self):
        super(score_today,self).__init__('score_today')
    
    def do(self):
        #��ȡ���������Ϣ
        list=Odds.getTodayXmlMatch()
        #����δƥ�乫˾��
        pipei_fail=[]
        for r in list:
            #��ȡ�ܷ�������Ϣ
            oddslist=Odds.getOddScoreFromUrl(r['bet007_matchid'],r['isreverse'])
            for odds in oddslist:
                tmp=self.callDb('db_odds','getBigCompanyInfo',odds['companyname'])
                if tmp:
                    companyid=int(tmp['id'])
                    source_bet007_b=int(tmp['source_bet007_b'])
                else:
                    source_bet007_b=companyid=0
                if companyid>0 and source_bet007_b==1:
                    if self.callDb('db_odds','saveBigOdds',r['matchid'],companyid,odds['bigmoneyline'],odds['handicapline'],odds['smallmoneyline'])==-1:
                        self.writelog('[thread:score_today]���ݿ���������쳣;data:{%s,%s,%s,%s,%s}!'%(r['matchid'],companyid,odds['bigmoneyline'],odds['handicapline'],odds['smallmoneyline']))
                elif  companyid<=0 and odds['companyname'] not in pipei_fail:
                    pipei_fail.append(odds['companyname'])
        #��¼δƥ��Ĺ�˾����
        if len(pipei_fail)>1:
            Odds.writeBigCompanyLog(pipei_fail)
            