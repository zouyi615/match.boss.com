#coding:gbk
import time
from app.core.Base import Base
from app.func import Match
import hashlib
'''ƥ��δ������'''
class match_sc_fixture(Base):
    def __init__(self):
        super(match_sc_fixture,self).__init__('match_sc_fixture')
    
    def do(self):
        match_data=[]
        #��ȡδ��������Ϣ
        fixture_url=self.getPath('nbascurl')
        timestamp=time.time()
        fixture_list=[]
        for i in range(1,3):
            url=fixture_url%time.strftime('%Y-%m-%d',time.localtime(timestamp+i*24*3600))
            fixture_list.extend(Match.getBet007Data(url,'fixture'))
            
        #�����ݿ��ȡδ��2��Ķ�������
        match_list=self.callDb('db_match','getMatchData',time.strftime('%Y-%m-%d 22:00:00',time.localtime(timestamp)),time.strftime('%Y-%m-%d 23:59:59',time.localtime(timestamp+86400*2)))
        team_list={}
        for r in match_list:
            key=hashlib.md5('h:%s-a:%s'%(r['HomeName_Bet007'],r['AwayName_Bet007'])).hexdigest()
            if not team_list.has_key(key):
                team_list[key]=[]
            team_list[key].append(r)
        
        #������Դ�����½���ƥ��
        xml_data=[]
        for r in fixture_list:
            #���Ͷ�һ�µ����
            key1=hashlib.md5('h:%s-a:%s'%(r['homename'],r['awayname'])).hexdigest()            
            #���Ͷ��෴�����
            key2=hashlib.md5('h:%s-a:%s'%(r['awayname'],r['homename'])).hexdigest()            
            if team_list.has_key(key1):
                tmp_arr=team_list[key1]
            else:
                tmp_arr=[]
            if team_list.has_key(key2):
                tmp_arr.extend(team_list[key2])
                                
            fixtureid=-1
            ispipei=0
            #�ж��Ƿ������ӵı���
            for t in tmp_arr:
                if Match.compare('%s 00:00:00'%str(t['VSDate']).split(' ')[0],'%s 00:00:00'%r['matchtime'].split(' ')[0]):
                    r['matchid']=int(t['FixtureID'])
                    r['isjclq']=t['isJCZQ']
                    if r['homename']==t['HomeName_Bet007']:
                        r['isreverse']=0
                    else:
                        r['isreverse']=1                    
                    r['homehkname']=t['HomeName_AM']
                    r['awayhkname']=t['AwayName_AM']
                    fixtureid=r['matchid']   
                    ispipei=1
                    xml_data.append(r)
                    break                
            match_data.append({'homename':r['homename'],'awayname':r['awayname'],'matchtime':r['matchtime'],'fixtureid':fixtureid,'ispipei':ispipei,'bet007_matchid':r['bet007_matchid']})     
        
        #���ɵ���xml
        if xml_data:
            Match.savetoxml(self.getPath('fixture_match_xml'),xml_data)
        
        #����bet007��������xml
        if match_data:
            Match.saveBet007Match(self.getPath('bet007_fixture_match_txt'),match_data)