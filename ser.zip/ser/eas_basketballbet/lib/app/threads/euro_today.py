#coding:gbk
from app.core.Base import Base
from app.func import Odds
'''����ŷ��'''
class euro_today(Base):
    def __init__(self):
        super(euro_today,self).__init__('euro_today')
    
    def do(self):
        #��ȡ���������Ϣ
        list=Odds.getTodayXmlMatch()    
        #����δƥ�乫˾��
        pipei_fail=[]
        for r in list:
            oddslist=Odds.getOddEuropeFromUrl(r['bet007_matchid'],r['isreverse'])
            for odds in oddslist:
                #���ݹ�˾����ȡ��˾��Ϣ
                tmp=self.callDb('db_odds','getCompanyInfo',odds['companyname'])
                if tmp:
                    companyid=int(tmp['id'])
                    source_bet007_b=int(tmp['source_bet007_b'])
                else:
                    source_bet007_b=companyid=0
                if companyid>0 and source_bet007_b==1:
                    if self.callDb('db_odds','saveEuroOdds',r['matchid'],companyid,odds['win'],odds['lost'])==-1:
                        self.writelog('[thread:euro_today]���ݿ���������쳣;data:{%s,%s,%s,%s}!'%(r['matchid'],companyid,odds['win'],odds['lost']))
                        
                elif companyid<=0 and odds['companyname'] not in pipei_fail:
                    pipei_fail.append(odds['companyname'])
        #��¼δƥ��Ĺ�˾
        if len(pipei_fail)>0:
            Odds.writeEuroCompanyLog(pipei_fail)