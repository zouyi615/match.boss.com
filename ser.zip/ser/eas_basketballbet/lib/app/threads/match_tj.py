#coding:gbk
import re
import codecs
from app.core.Base import Base
from app.func import Match
'''��������ͳ��'''
class match_tj(Base):
    def __init__(self):
        super(match_tj,self).__init__('match_tj')
    
    def do(self):
        #��ȡͳ��������Ϣ
        match_list=Match.getLeagueList()
        for classid in match_list:
            #��ȡ�����б�
            tmp=self.curl(self.getPath('nbamatch_season')%classid,{},20)
            ct_tmp=re.findall(r'%s'%self.getPath('nbamatch_regex'),tmp['CONTENT'])
            if not ct_tmp:
                continue
            #��ȡ�����µ�ǰ����
            season_list=re.findall(r'\[(.+?)\]',ct_tmp[0])
            if not season_list:
                continue
            tmp=season_list[0].split(',')
            current_season=tmp[0].strip("'")
            current_stage=int(tmp[1])
            
            #NBA,CBA
            if current_season.find('-')!=-1:
                season_str=current_season[2:4]+'-'+current_season[7:9]
            #WNBA
            elif len(current_season)>0:
                season_str=current_season[2:4]
            else:
                season_str=''
            #��ȡ����id
            leagueid=self.callDb('db_match','getLeagueId',current_season.replace('-','/'),match_list[classid]['name'])
            #�����¿�δ�ҵ���֮��Ӧ������
            if not leagueid:
                continue
            if current_stage==1:#������
                stage_list=[3,1]
            elif current_stage==2:#������
                stage_list=[3,1,2]
            elif current_stage==3:#��ǰ��
                stage_list=[3]
            else:
                stage_list=[] 
            #��ȡ�����Ϣ
            for i in stage_list:
                post_arr=[]
                url=self.getPath('nbamatch_detailurl')%(season_str,classid,i)
                #��ӱ�������
                team_tmp=self.curl(url,{},20)
                
                #�ж��ļ��Ƿ�Ϊutf-8+ Bom��ʽ;����ǣ����ȡbomͷ����ת����utf-8��ʽ
                if team_tmp['CONTENT']!='' and codecs.BOM_UTF8==team_tmp['CONTENT'][0:3]:
                    team_tmp['CONTENT']=team_tmp['CONTENT'][3:].decode('utf-8').encode('gbk')
                
                team_ct_tmp=re.findall(r'%s'%self.getPath('nbamatch_detailreg'),team_tmp['CONTENT'])
                
                #�ж��Ƿ������������Ϣ
                if team_ct_tmp:
                    #��ȡ����Դ�������id
                    team_name_tmp=re.findall(r'%s'%self.getPath('nbamatch_teamreg'),team_tmp['CONTENT'])
                    team_name_arr={}
                    if team_name_tmp:
                        for t in team_name_tmp[0].split('],['):
                            tt=t.replace('[','').replace(']','').replace("'",'').split(',')
                            team_name_arr[tt[0]]=tt[1]
                            
                    #���������Ϣ
                    for t in team_ct_tmp[0].split('],['):
                        tt=t.replace('[','').replace(']','').replace("'",'').split(',')
                        if not team_name_arr.has_key(tt[0]):
                            continue
                        #�����
                        teamname=team_name_arr[tt[0]]
                        #�����ݿ��ȡ500wan���id
                        team_id_tmp=self.callDb('db_match','getTeamId',teamname)
                        if team_id_tmp:
                            teamid=int(team_id_tmp['teamid'])
                        else:
                            teamid=''
                        #����
                        count=tt[1].strip()
                        #ƽ���÷�
                        avg_score=tt[2].strip()
                        #ƽ��ʧ��
                        avg_lost=tt[3].strip()
                        #Ͷ��������
                        hit_rate=tt[4].strip()
                        #����
                        three_point=tt[5].strip()
                        #����������
                        free_throw=tt[6].strip()
                        #ƽ������
                        rebound=tt[7].strip()
                        #ƽ������
                        avg_assists=tt[8].strip()
                        #ƽ����ñ
                        avg_block =tt[9].strip()     
                        #ƽ������
                        avg_steal=tt[10].strip()
                        #ƽ��ʧ��
                        avg_turnover=tt[11].strip()
                        #ƽ������
                        avg_foul=tt[12].strip()
                        post_arr.append({'teamname':teamname,'teamid':teamid,'count':count,'avg_score':avg_score,'avg_lost':avg_lost,'hit_rate':hit_rate,'three_point':three_point,
                            'free_throw':free_throw,'rebound':rebound,'avg_assists':avg_assists,'avg_block':avg_block,'avg_steal':avg_steal,'avg_turnover':avg_turnover,'avg_foul':avg_foul
                        })
                Match.saveTeamTjData(post_arr,leagueid,i%3)
                
        post_arr=team_ct_tmp=team_name_tmp=team_name_arr=None