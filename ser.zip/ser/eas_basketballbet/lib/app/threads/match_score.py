#coding:gbk
import time
import re
import codecs
from app.core.Base import Base
from app.func import Odds
'''�ȷ�ֱ��'''
class match_score(Base):
    def __init__(self):
        super(match_score,self).__init__('match_score')
    
    def do(self):
        #��ȡ���������Ϣ
        list=Odds.getTodayXmlMatch()
        #�ȷ�����Դ��ַ
        bf_path=self.getPath('bifenurl')
        reg=self.getPath('bifenregex')
        
        bf_arr=[]
        for r in list:
            if not r['is_exists_wzzb']:
                continue
            url=bf_path%(str(r['bet007_matchid'])[0],str(r['bet007_matchid'])[1:3],r['bet007_matchid'],time.time())
            tmp=self.curl(url,{},20)
            if len(tmp['CONTENT'])>3 and tmp['CONTENT'][:3]==codecs.BOM_UTF8:
                tmp['CONTENT']=tmp['CONTENT'][3:].decode('UTF8','ignore').encode('GBK','ignore')
            ct_tmp=tmp['CONTENT'].split('$') #���ڷָ���
            
            bf_txt_str=bf_txt_str2=''
            bf_new=bf_new_txt=bf_new_status=bf_new_time=''
            
            rows_count=len(ct_tmp) #���½���
            i=0 
            eventid=0
            bf_arr_tmp=[] #��¼�ȷ���Ϣ
            for content in ct_tmp:
                i+=1
                #���ڵ�����
                ct_list=content.strip('!').split('!')
                cols_count=len(ct_list) #���һ��
                j=0
                for t in ct_list:
                    eventid+=1
                    j+=1
                    bf_tmp=t.split('^')
                    if len(bf_tmp)==5:
                        #�ȷ���Ϣ               
                        bf_score_str='%s-%s'%(bf_tmp[3],bf_tmp[2])
                        #����ֱ����Ϣ
                        bf_detail=bf_tmp[4]
                        bf_team_name=''
                        #ʱ��
                        bf_time=bf_tmp[0]
                        bf_content='%s|%s|%s|%s|%s'%(eventid,bf_score_str,bf_team_name,bf_time,bf_detail)
                        
                        bf_arr_tmp.append(bf_content)
                        #��¼���µ�����
                        if i==rows_count and j==cols_count:
                            #��¼���±ȷ���Ϣ 
                            bf_new=bf_score_str
                            if i==1:
                                bf_new_status='��1��'
                            elif i==2:
                                bf_new_status='��2��'
                            elif i==3:
                                bf_new_status='��3��'
                            elif i==4:
                                bf_new_status='��4��'
                            elif i==5:
                                bf_new_status='��ʱ1'
                            elif i==6:
                                bf_new_status='��ʱ2'
                            elif i==7:
                                bf_new_status='��ʱ3'
                            bf_new_txt=bf_detail
                            bf_new_time=bf_time
#            bf_txt_str='$'.join(bf_arr_tmp)
            
            #ȡ����5������
            end=len(bf_arr_tmp)
            if end>5:
                start=end-5
            else:
                start=0
            bf_five_tmp=[]
            for k in range(start,end):
                bf_five_tmp.append(bf_arr_tmp[k])
            
            if bf_arr_tmp:
                bf_arr.append({
                    'bet007_matchid':r['bet007_matchid'],
                    'matchid':r['matchid'],
                    'bifen':bf_new,
                    'bifentxt':'$'.join(bf_arr_tmp),
                    'bifennewtxt':bf_new_txt,
                    'bifennewstatus':bf_new_status,
                    'bifennewtime':bf_new_time,
                    'bifentxt2':'$'.join(bf_five_tmp),
                    'bifeneventid':eventid
                })
        
        #����ֱ����Ϣ
        for r in bf_arr:
            self.callDb('db_odds','savebifentxt',r)