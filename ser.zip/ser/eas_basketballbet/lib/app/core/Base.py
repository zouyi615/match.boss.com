#coding:gbk
import time
import traceback
from threading import Thread
from app.func import Global
from app.db import basket
class Base(Thread):
    def __init__(self,threadname):
        Thread.__init__(self)
        self.threadname=threadname
        self.isRun=True
        self.getSleepTime()
        
    '''����'''
    def run(self):
        self.writelog('[-----%s thread start-----]'%self.threadname)
        while self.isRun:
            try:
                self.do()
            except Exception,e:
                self.writelog('[thread:%s]�̳߳����쳣:%s'%(self.threadname,traceback.format_exc()))
            time.sleep(self.sleeptime)
    def do(self):
        pass
    
    '''ֹͣ'''
    def stop(self):
        self.writelog('[-----%s thread stop-----]'%self.threadname)
        self.isRun=False
            
    '''д��־'''
    def writelog(self,msg):
        Global.writelog(msg)
    
    '''��ȡ�ӿ�url'''
    def getPath(self,path):
        return Global.getConfigPath(path)
    
    '''��ȡ�߳�˯��ʱ��'''
    def getSleepTime(self):
        self.sleeptime=Global.getSleepTime(self.threadname)
        
    '''��ҳ��'''
    def curl(self,path,data={},timeout=10):
        return Global.pcurl(path,data,'[threads:%s]'%self.threadname,timeout)
    
    '''����xml'''
    def parsexml(self,string):
        return Global.parseString(string)
    
    '''���ݿ����'''
    def callDb(self,class_name,func,*args):
        return basket.callDb(class_name,func,*args)    