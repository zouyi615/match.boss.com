#coding:gbk
import time
import Db.Mysql
class db_match:
    def __init__(self):
        pass
    def getMatchData(self,begin,end):
        sql='SELECT FixtureID,HomeName_AM,HomeName_Bet007,AwayName_AM,AwayName_Bet007,VSDate,isJCZQ FROM v_b_fixturemate where VSDate between %s and %s'
        args=[begin,end]
        return Db.Mysql.get('MatchSlave').query(sql,args)
    
    def getGBName(self,matchid):
        sql='''select b.teamname_gbk as homehkname,c.teamname_gbk as awayhkname from t_b_fixture as a 
              inner join t_b_teambyname as b on a.homeid=b.teamid 
              inner join t_b_teambyname as c on a.awayid=c.teamid
              where a.fixtureid=%s'''
        args=[matchid]
        return Db.Mysql.get('MatchSlave').query(sql,args)
    
    def getTeamId(self,teamname):
        sql='select teamid from t_b_teambyname where teamname_bet007=%s'
        args=[teamname]
        return Db.Mysql.get('MatchSlave').queryOne(sql,args)
    
    def getLeagueId(self,year,seansongbname):
        sql='''SELECT seasonid from t_b_season where seasonyear=%s and seasongbname LIKE %s'''
        args=[year,'%'+seansongbname+'%']
        ret=Db.Mysql.get('MatchSlave').queryOne(sql,args)
        if ret:
            return ret['seasonid']
        else:
            return 0
        