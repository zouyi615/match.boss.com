#coding:gbk
import time
import Db.Mysql
'''����DB����'''
class db_odds:
    def __init__(self):
        pass
    '''��ȡ��˾��Ϣ'''
    def getCompanyInfo(self,companyname):
        sql='select id,source_bet007 as source_bet007_b from t_odds_company where bet007=%s or bet007_asian=%s'
        args=[companyname,companyname]
        return Db.Mysql.get('MatchSlave').queryOne(sql,args)
    
    def saveEuroOdds(self,matchid,companyid,win,lost):
        db=Db.Mysql.get('MatchMaster')
        result=-1
        sql='set @bk_euro_rs=-1;call p_b_updateodds_europe(%s,%s,%s,%s,@bk_euro_rs);'
        args=[matchid,companyid,win,lost]
        db.query(sql,args)
        sql='select @bk_euro_rs as rs'
        rs=db.queryOne(sql)
        result=rs['rs']
        return result
    
    '''��ȡ���⹫˾��Ϣ'''
    def getAsianCompanyInfo(self,companyname):
        sql='select id,source_bet007_a as source_bet007_b from t_odds_company where bet007=%s or bet007_asian=%s'
        args=[companyname,companyname]
        return Db.Mysql.get('MatchSlave').queryOne(sql,args)
    
    '''������������'''
    def saveAsianOdds(self,matchid,companyid,homemoneyline,handicapline,awaymoneyline):
        db=Db.Mysql.get('MatchMaster')
        result=-1
        sql='set @bk_asian_rs=-1;call p_b_updateodds_asian(%s,%s,%s,%s,%s,@bk_asian_rs)'
        args=[matchid,companyid,homemoneyline,handicapline,awaymoneyline]
        db.query(sql,args)
        sql='select @bk_asian_rs as rs'
        rs=db.queryOne(sql)
        result=rs['rs']
        
        #���̿����⴦��
        self.add_secondary_asian(matchid,companyid, homemoneyline, handicapline, awaymoneyline);
        return result
    
    def add_secondary_asian(self,matchid,companyid, homemoneyline, handicapline, awaymoneyline,lastchangedtime=None):
        result=-1
        db=Db.Mysql.get('MatchMaster')
        sql='set @bk_secondary_asian_result=-1;call p_b_updateodds_secondary_asian(%s,%s,%s,%s,%s,%s,@bk_secondary_asian_result)'
        args=[matchid,companyid, homemoneyline, handicapline, awaymoneyline,lastchangedtime]
        db.query(sql,args)
        sql='select @bk_secondary_asian_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    '''��ȡ��С��˾��Ϣ'''
    def getBigCompanyInfo(self,companyname):
        sql='select id,source_bet007_a as source_bet007_b from t_odds_company where bet007=%s or bet007_asian=%s'
        args=[companyname,companyname]
        return Db.Mysql.get('MatchSlave').queryOne(sql,args)   
    
    '''�����С����'''
    def saveBigOdds(self,matchid,companyid,bigmoneyline,handicapline,smallmoneyline):
        db=Db.Mysql.get('MatchMaster')
        result=-1
        sql='set @bk_big_rs=-1;call p_b_updateodds_big(%s,%s,%s,%s,%s,@bk_big_rs)'
        args=[matchid,companyid,bigmoneyline,handicapline,smallmoneyline]
        db.query(sql,args)
        sql='select @bk_big_rs as rs'
        rs=db.queryOne(sql)
        result=rs['rs']
        
        self.add_secondary_bigsmall(matchid, companyid, bigmoneyline, handicapline, smallmoneyline);
        return result    
    
    def add_secondary_bigsmall(self,matchid,companyid,bigmoneyline,handicapline,smallmoneyline,lastchangedtime=None):
        result=-1
        db=Db.Mysql.get('MatchMaster')
        sql='set @bk_secondary_big_result=-1;call p_b_updateodds_secondary_big(%s,%s,%s,%s,%s,%s,@bk_secondary_big_result)'
        args=[matchid,companyid,bigmoneyline,handicapline,smallmoneyline,lastchangedtime]
        db.query(sql,args)
        sql='select @bk_secondary_big_result as rs'
        ret=db.queryOne(sql)
        if ret:
            result=ret['rs']
        return result
    
    '''���������Ա��Ϣ'''
    def saveplayers(self,r):
        db=Db.Mysql.get('MatchMaster')
        sql='select fixtureid,homezx,homehb,homets,homess,awayzx,awayhb,awayts,awayss from t_b_fixture_ext where fixtureid=%s'
        args=r['matchid']
        tmp=db.queryOne(sql,args)
        if tmp:
            home_sf=tmp['homezx']
            home_tb=tmp['homehb']
            home_sb=tmp['homess']
            away_sf=tmp['awayzx']
            away_tb=tmp['awayhb']
            away_sb=tmp['awayss']
            
            if r['isreverse']==1:
                flag=away_sf!=r['home_sf'] or away_tb!=r['home_tb'] or away_sb!=r['home_sb'] or home_sf!=r['away_sf'] or home_tb!=r['away_tb'] or home_sb!=r['away_sb']
            else:
                flag=home_sf!=r['home_sf'] or home_tb!=r['home_tb'] or home_sb!=r['home_sb'] or away_sf!=r['away_sf'] or away_tb!=r['away_tb'] or away_sb!=r['away_sb']
            
            if flag:
                sql='update t_b_fixture_ext set homezx=%s, homehb=%s, homess=%s, awayzx=%s, awayhb=%s, awayss=%s where fixtureid=%s'
                if r['isreverse']==1:
                    args=[r['away_sf'],r['away_tb'],r['away_sb'],r['home_sf'],r['home_tb'],r['home_sb'],r['matchid']]
                else:
                    args=[r['home_sf'],r['home_tb'],r['home_sb'],r['away_sf'],r['away_tb'],r['away_sb'],r['matchid']]
                db.execute(sql,args)
        else:
            sql='insert into t_b_fixture_ext(fixtureid,homezx,homehb,homets,homess,awayzx,awayhb,awayts,awayss)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)'
            if r['isreverse']==1:
                args=[r['matchid'],r['away_sf'],r['away_tb'],'',r['away_sb'],r['home_sf'],r['home_tb'],'',r['home_sb']]
            else:
                args=[r['matchid'],r['home_sf'],r['home_tb'],'',r['home_sb'],r['away_sf'],r['away_tb'],'',r['away_sb']]
            db.insert(sql,args)
            
    '''��������'''
    def savepl(self,r):
        db=Db.Mysql.get('SoccerMaster')
        sql='select title,content from t_news_news where fixtureid=%s and classid=21'
        args=r['matchid']
        tmp=db.queryOne(sql,args)
        if r['isreverse']==1:
            title='%sVS%s'%(r['homename'],r['awayname'])
        else:
            title='%sVS%s'%(r['awayname'],r['homename'])
        if tmp:
            if tmp['title']!=title or tmp['content']!=r['notic']:
                sql='update t_news_news set title=%s,content=%s where fixtureid=%s and classid=21'
                args=[title,r['notic'],r['matchid']]
                db.execute(sql,args)
        elif len(r['notic'])>0:
             sql='insert into t_news_news(title,content,fixtureid,classid)values(%s,%s,%s,%s)'
             args=[title,r['notic'],r['matchid'],21]
             db.insert(sql,args)   
    
    '''����ֱ����Ϣ'''
    def savebifentxt(self,r):
        db=Db.Mysql.get('MatchMaster')
        sql='select sourceeventid from t_live_basketballevent_qt where fixtureid=%s limit 1'
        args=[r['matchid']]
        tmp=db.queryOne(sql,args)
        time_tmp=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
        if tmp:
            eventid=int(tmp['sourceeventid'])
            if eventid!=r['bifeneventid']:
                sql='update t_live_basketballevent_qt set fixturestate=%s,bifen=%s,eventtxt=%s,times=%s,sourceeventid=%s,addtime=%s where fixtureid=%s'
                args=[r['bifennewstatus'],r['bifen'],r['bifennewtxt'],r['bifennewtime'],r['bifeneventid'],time_tmp,r['matchid']]
                db.execute(sql,args)
                
                sql='update t_live_basketballtxt_qt set bifentxt=%s,bifentxt2=%s,updatetime=%s where fixtureid=%s'
                args=[r['bifentxt'],r['bifentxt2'],time_tmp,r['matchid']]
                db.execute(sql,args)
                
        elif r['bifeneventid']>0:
            sql='insert into t_live_basketballevent_qt(fid,fixturestate,bifen,eventtxt,times,sourceeventid,fixtureid,addtime)values(%s,%s,%s,%s,%s,%s,%s,%s)'
            args=[r['bet007_matchid'],r['bifennewstatus'],r['bifen'],r['bifennewtxt'],r['bifennewtime'],r['bifeneventid'],r['matchid'],time_tmp]
            db.insert(sql,args)
            
            sql='insert into t_live_basketballtxt_qt(fixtureid,smatchid,bifentxt,bifentxt2)values(%s,%s,%s,%s)'
            args=[r['matchid'],r['bet007_matchid'],r['bifentxt'],r['bifentxt2']]
            db.insert(sql,args)        
    
    '''���漼��ͳ������'''
    def savestattxt(self,row):
        db=Db.Mysql.get('MatchMaster')
        sql="select srid from t_live_basketballstat_qt where srid=%s"%row['srid']
        ret=db.query(sql)
        if ret:
            sql="update t_live_basketballstat_qt set fixtureid=%s,homesf=%s,hometb=%s,homecount=%s,awaysf=%s,awaytb=%s,awaycount=%s where srid=%s"
            args=[row['fixtureid'],row['homesf'],row['hometb'],row['homecount'],row['awaysf'],row['awaytb'],row['awaycount'],row['srid']]
            db.execute(sql,args)
        else:
            sql="insert into t_live_basketballstat_qt(srid,fixtureid,homesf,hometb,homecount,awaysf,awaytb,awaycount)values(%s,%s,%s,%s,%s,%s,%s,%s)"
            args=[row['srid'],row['fixtureid'],row['homesf'],row['hometb'],row['homecount'],row['awaysf'],row['awaytb'],row['awaycount']]
            db.insert(sql,args)   