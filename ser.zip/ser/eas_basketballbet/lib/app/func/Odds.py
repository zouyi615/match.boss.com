#coding:gbk
'''���ʺ���'''
import re,time
from app.func import Global
'''��ȡƥ��xml�еĶ�������'''
def getXmlMatch(url,timeout=20):
    tmp=Global.pcurl(url,{},'[Func_Odds:getXmlMatch]',timeout)
    return_arr=[]
    if tmp['CODE']==1:
        xml=Global.parseString(tmp['CONTENT'])
        if xml:
            node_arr=xml.getElementsByTagName('m')
        else:
            node_arr=[]
        for node in node_arr:
            matchid=int(node.getAttribute('MatchID'))
            bet007_matchid=int(node.getAttribute('Bet007_MatchID'))
            isreverse=int(node.getAttribute('IsReverse'))
            HT=node.getAttribute('HomeName').encode('gbk').split(',')
            AT=node.getAttribute('AwayName').encode('gbk').split(',')               
            homehkname=HT[2]
            awayhkname=AT[2]            
            matchtime=node.getAttribute('MatchTime').encode('gbk')
            if isreverse==1:
                homename=AT[0]
                awayname=HT[0]
            else:
                homename=HT[0]
                awayname=AT[0] 
            #�Ƿ��������ֱ��
            is_exists_wzzb=int(node.getAttribute('Is_Exists_Wzzb'))
            return_arr.append({'matchid':matchid,'bet007_matchid':bet007_matchid,'homename':homename,'homehkname':homehkname,'awayname':awayname,'awayhkname':awayhkname,'isreverse':isreverse,'matchtime':matchtime,'is_exists_wzzb':is_exists_wzzb})
    return return_arr

'''��ȡ����xml����'''
def getTodayXmlMatch(t=1):
    return getXmlMatch(Global.getConfigPath('resources_url')+Global.getConfigPath('today_match_xml'))

'''��ȡδ��xml����'''
def getFixtureXmlMatch(t=1):
    return getXmlMatch(Global.getConfigPath('resources_url')+Global.getConfigPath('fixture_match_xml'),30)

'''��ȡ����Դŷ������'''
def getOddEuropeFromUrl(bet007_matchid,isreverse):
#     url=Global.getConfigPath('oddeuropeurl')%bet007_matchid
    id_str=str(bet007_matchid)
    url=Global.getConfigPath('oddeuropeurl')%(id_str[0],id_str[1:3],id_str)
    tmp=Global.pcurl(url,{},'[Func_Odds:getOddEuropeFromUrl]',60)
    time.sleep(1)
    return_arr=[]
    '''�������ʽ'''
    ct_tmp=re.findall(r'%s'%Global.getConfigPath('oddeuroperegex'),tmp['CONTENT'])
    
    if ct_tmp and len(ct_tmp)==1:
        data=ct_tmp[0].replace('("','').replace('")','').split('","')
        for t in data:
            r=t.split('|')
            if len(r)!=19:
                continue
            companyname=r[16].split('(')[0]
            win_tmp=r[3].strip()
            lost_tmp=r[4].strip()
            if r[8]!='':
                win_tmp=r[8].strip()
                lost_tmp=r[9]
            if isreverse==1:
                win=lost_tmp
                lost=win_tmp
            else:
                win=win_tmp
                lost=lost_tmp
            return_arr.append({'companyname':companyname,'win':win,'lost':lost})
    return return_arr

'''��ȡ����Դ��������'''
def getOddAsianFromUrl(bet007_matchid,isreverse):
    url=Global.getConfigPath('oddsasianurl')%bet007_matchid
    tmp=Global.pcurl(url,{},'[Func_Odds:getOddAsianFromUrl]',60)
    time.sleep(1)
    ct_tmp=re.findall(r'%s'%Global.getConfigPath('oddsasianregex'),tmp['CONTENT'].replace("\r\n",''))
    return_arr=[]
    for r in ct_tmp:
        companyname=r[0].strip()
        pattern=re.compile(r'<[^>]+>')
        homemoneyline_tmp,num=re.subn(pattern,'',r[1])
        homemoneyline_tmp=homemoneyline_tmp.replace('&nbsp;','').strip()
        
        handicapline_tmp,num=re.subn(pattern,'',r[2])
        handicapline_tmp=handicapline_tmp.replace('&nbsp;','').strip()
        
        awaymoneyline_tmp,num=re.subn(pattern,'',r[3])
        awaymoneyline_tmp=awaymoneyline_tmp.replace('&nbsp;','').strip()
        if len(homemoneyline_tmp)>0 and len(handicapline_tmp)>0 and len(awaymoneyline_tmp)>0:
            if isreverse==1:#�����෴�����
                homemoneyline=awaymoneyline_tmp
                handicapline=handicapline_tmp
                awaymoneyline=homemoneyline_tmp
            else:
                homemoneyline=homemoneyline_tmp
                handicapline='%.2f'%(float(handicapline_tmp)*-1)
                awaymoneyline=awaymoneyline_tmp
            return_arr.append({'companyname':companyname,'homemoneyline':homemoneyline,'handicapline':handicapline,'awaymoneyline':awaymoneyline})
    return return_arr

'''��ȡ����Դ�ܷ�����'''
def getOddScoreFromUrl(bet007_matchid,isreverse):   
    url=Global.getConfigPath('oddsbigurl')%bet007_matchid
    tmp=Global.pcurl(url,{},'[Func_Odds:getOddScoreFromUrl]',60)
    time.sleep(1)
    ct_tmp=re.findall(r'%s'%Global.getConfigPath('oddsbigregex'),tmp['CONTENT'].replace("\r\n",''))
    return_arr=[]
    for r in ct_tmp:
        companyname=r[0].strip()
        pattern=re.compile(r'<[^>]+>')
        bigmoneyline_tmp,num=re.subn(pattern,'',r[1])
        bigmoneyline_tmp=bigmoneyline_tmp.replace('&nbsp;','').strip()
        
        handicapline_tmp,num=re.subn(pattern,'',r[2])
        handicapline_tmp=handicapline_tmp.replace('&nbsp;','').strip()
        
        smallmoneyline_tmp,num=re.subn(pattern,'',r[3])
        smallmoneyline_tmp=smallmoneyline_tmp.replace('&nbsp;','').strip()
       
        if len(bigmoneyline_tmp)>0 and len(handicapline_tmp)>0 and len(smallmoneyline_tmp)>0:
            if isreverse==1:#�����෴�����
                bigmoneyline=smallmoneyline_tmp
                handicapline=handicapline_tmp
                smallmoneyline=bigmoneyline_tmp
            else:
                bigmoneyline=bigmoneyline_tmp
                handicapline=handicapline_tmp
                smallmoneyline=smallmoneyline_tmp
            return_arr.append({'companyname':companyname,'bigmoneyline':bigmoneyline,'handicapline':handicapline,'smallmoneyline':smallmoneyline})    
    return return_arr
    
'''��¼δƥ�乫˾������־'''
def writeCompanyLog(data,path):
    if not data:
        return
    url=Global.getConfigPath('resources_url')+path
    tmp=Global.pcurl(url,{},'[Func_Odds:writeCompanyLog]',20)
    content=tmp['CONTENT']
    if content.find('<html><head>')!=-1:
        content=''
    sp="\n"
    for company in data:
        content+='[��˾��δƥ��]company:%s;time:%s'%(company,time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))+sp
    Global.post_500wan_data(path,content,'[Func_Odds:writeCompanyLog]')
    
'''��¼ŷ���̹߳�˾δƥ����־'''
def writeEuroCompanyLog(data):
    writeCompanyLog(data,Global.getConfigPath('euro_log_txt')%time.strftime('%Y%m%d',time.localtime()))

'''��¼�����̹߳�˾δƥ����־'''
def writeAsianCompanyLog(data):
    writeCompanyLog(data,Global.getConfigPath('asian_log_txt')%time.strftime('%Y%m%d',time.localtime()))
    
'''��¼�ܷ��̹߳�˾δƥ����־'''
def writeBigCompanyLog(data):
    writeCompanyLog(data,Global.getConfigPath('big_log_txt')%time.strftime('%Y%m%d',time.localtime()))

'''ת��Ϊ����'''
def convtosimple(string):
    return Global.getSimplifiedChinese(string)