#coding:gbk
'''����ƥ�亯��'''
import time
import datetime
from app.func import Global
'''��ȡbet007����Դ����'''
def getBet007Data(url,type='today'):
    list=[]
    tmp=Global.pcurl(url,{},'Func_Match:getBet007Data',15)
    if tmp['CODE']==1 and len(tmp['CONTENT'])>1:
        xml=Global.parseString(tmp['CONTENT'].replace(' encoding="gb2312"',' encoding="gbk"'))
    else:
        xml=None
    if xml:
        node_arr=xml.getElementsByTagName('h')
    else:
        node_arr=[]
    for node in node_arr:
        #Ϊ�˽��ת��������ַ������ķָ�����,�Ƚ��зָ�,����ת��
        ct_tmp=node.firstChild.nodeValue.split('^')
        id=int(ct_tmp[0].strip())
        homename=ct_tmp[8].split(',')[0].strip().split('[')[0].encode('gbk')
        awayname=ct_tmp[10].split(',')[0].strip().split('[')[0].encode('gbk')
        tmpdate=ct_tmp[4].strip().encode('gbk').replace('��<br>',' ').replace('��','-')
        if ct_tmp[28]=='True':
            exists_wzzb=1
        else:
            exists_wzzb=0     
        if type=='today': #����xml
            year=int(ct_tmp[37])
        else:#δ��xml
            year=int(ct_tmp[42])            
        dt_tmp='%s-%s:00'%(year,tmpdate)
        if time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())<=dt_tmp and type=='fixture' or (type=='today' and int(ct_tmp[5])>=0):
            row={'bet007_matchid':id,'homename':homename,'awayname':awayname,'matchtime':dt_tmp,'is_exists_wzzb':exists_wzzb}
            list.append(row)
    return list

def saveBet007Match(url,data):
    txt_arr=[]
    for r in data:
        txt_arr.append('["%s","%s","%s","%s","%s","%s"]'%(r['bet007_matchid'],r['fixtureid'],r['homename'],r['awayname'],r['matchtime'],r['ispipei']))
    
    txt_content='''{"updatetime":"%s","data":[%s]}'''%(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()),','.join(txt_arr))
    Global.post_500wan_data(url,txt_content,'[Func_Match:saveBet007Match]')
    
'''��������ʱ���'''
def day_diff(datetime1,datetime2):
    timestamp1=time.mktime(time.strptime(datetime1,'%Y-%m-%d %H:%M:%S'))
    timestamp2=time.mktime(time.strptime(datetime2,'%Y-%m-%d %H:%M:%S'))
    return timestamp1-timestamp2

'''����Դ�����ݿ����ʱ����бȽ�'''
def compare(time1,time2):
    if abs(day_diff(time1,time2))<=12*3600:
        return True
    else:
        return False

def match_xml_format(data):
    string='<?xml version="1.0" encoding="utf-8"?><xml updatetime="%s"><matches>'%(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
    for r in data:
        string+='<m MatchID="%s" Bet007_MatchID="%s" IsJCLQ="%s" HomeName="%s" AwayName="%s" MatchTime="%s" IsReverse="%s" Is_Exists_Wzzb="%s" />'
        if r['isreverse']==0:
            home_str='%s,%s,%s'%(r['homename'],r['homename'],r['homehkname'])
            away_str='%s,%s,%s'%(r['awayname'],r['awayname'],r['awayhkname'])
        else:
            home_str='%s,%s,%s'%(r['awayname'],r['homename'],r['awayhkname'])
            away_str='%s,%s,%s'%(r['homename'],r['awayname'],r['homehkname'])
        string=string%(r['matchid'],r['bet007_matchid'],r['isjclq'],home_str,away_str,r['matchtime'],r['isreverse'],r['is_exists_wzzb'])           
    string+='</matches></xml>'
    return string
'''����xml'''
def savetoxml(path,data):
    data and Global.post_500wan_data(path,match_xml_format(data).decode('gbk').encode('utf-8'),'[Func_Match:savetoxml]')
    
'''��ȡ��������'''
def getLeagueList():
    return Global.getConfigParam('league')

'''�������ͳ����Ϣ'''
def saveTeamTjData(list,leagueid,typeid):
    if not list:
        return
    string='<?xml version="1.0" encoding="utf-8"?><xml><updatetime>%s</updatetime>'%time.strftime('%Y-%m-%d %H:%M:%S')
    for r in list:
        string+='<row teamid="%s" teamgbname="%s" count="%s" score="%s" lost="%s" fieldgoal="%s" threepoint="%s" freethrow="%s" rebound="%s" assist="%s" block="%s" steal="%s" turnover="%s" foul="%s"/>'
        string=string%(r['teamid'],r['teamname'],r['count'],r['avg_score'],r['avg_lost'],r['hit_rate'],r['three_point'],r['free_throw'],r['rebound'],r['avg_assists'],r['avg_block'],r['avg_steal'],r['avg_turnover'],r['avg_foul'])
    string+='</xml>'
    path=Global.getConfigPath('nbamatch_path')%(leagueid,typeid)
    Global.post_500wan_data(path,string.decode('gbk').encode('utf8'),'[Func_Match:saveTeamTjData]')