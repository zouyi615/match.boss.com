#coding=gbk
import sys, os
import time
#import json
import threading
import logging
import traceback
import signal

if not os.environ.has_key('_BASIC_PATH_'):
    _BASIC_PATH_ = os.path.abspath(__file__)
    _BASIC_PATH_ = _BASIC_PATH_[:_BASIC_PATH_.rfind('/test/')]
    os.environ['_BASIC_PATH_'] = _BASIC_PATH_
if sys.path.count(os.environ['_BASIC_PATH_'] + '/lib') == 0:
    sys.path.append(os.environ['_BASIC_PATH_'] + '/mod')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib/common')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs/pypi')

import XmlConfig
XmlConfig.setEncoding('gbk')
XmlConfig.loadFile(_BASIC_PATH_ + '/etc/service.xml')
XmlConfig.loadFile(_BASIC_PATH_ + '/etc/config.xml')
XmlConfig.loadFile(_BASIC_PATH_ + '/etc/db.xml')


#_APP_ID_ = sys.argv[1]
#print _BASIC_PATH_

import Ice
Ice.loadSlice(_BASIC_PATH_+'/etc/EAS.ice')

import EasClient
import JsonUtil
from app.threads.match_sc import match_sc
from app.threads.euro_today import euro_today
from app.threads.euro_fixture import euro_fixture
from app.threads.asian_today import asian_today
from app.threads.asian_fixture import asian_fixture
from app.threads.score_today import score_today
from app.threads.score_fixture import score_fixture
from app.threads.match_zr import match_zr
from app.threads.match_score import match_score
from app.threads.match_tj import match_tj

from service.info import info
if __name__ == '__main__':
#    match_sc().start()
#    euro_today().start()
#    euro_fixture().start()
#    asian_today().start()
#    asian_fixture().start()
#    score_today().start()
#    score_fixture().start()
#    match_zr().start()
#    match_score().start()
#    match_tj().start()
#    p=info()
#    p.setStatus(JsonUtil.write({'match_sc':'0'}))
#    print JsonUtil.read(JsonUtil.write({'test':1,'aa':2}))
#    eas_instance = EasClient.EasClient().getInstance('basketballbet')
#    tt=eas_instance.invoke("server/getZrData",{})
#    tt=eas_instance.invoke("server/setStatus",{'params':JsonUtil.write({'match_sc':'0'})})
#    print tt
    print