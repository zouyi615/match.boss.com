# coding: gbk
import EasClient
import Eas.Extend
import Eas.Function
import logging
import traceback
import threading
import XmlConfig
import checkscoretreading

class checkscore(Eas.Extend.Common):
    def __init__(self):
        self.s1 = '0'
        #�Զ�����һ�γ���
        self.checkall('1');
        pass
        
    def checkall(self, status):
        
        if self.s1 != '1' and status == '1':
            checkscoretreading.s1 = 1
            th1 = threading.Thread(target = checkscoretreading.checkall, args = (300, ))
            th1.start()
            logging.info('���±ȷ��Զ�����߳̿���')
            self.s1 = status
        else:
            if self.s1 == '1' and status == '0':
                checkscoretreading.s1 = 0
                logging.info('���±ȷ��Զ�����̹߳ر�')
                self.s1 = status
        
        return self._result({'status':self.s1}, [])
    
def reg_interface(prefix):
    '''ϵͳ�̶�ע��ӿں���'''    
    p =checkscore()
    return Eas.Function.get_method_dict(p, prefix+'/')    
