#coding=gbk
import sys, os
reload(sys)
sys.setdefaultencoding('gbk')
#print sys.getdefaultencoding()

import time
#import json
import threading
import logging
import traceback
import signal

if not os.environ.has_key('_BASIC_PATH_'):
    _BASIC_PATH_ = os.path.abspath(__file__)
    _BASIC_PATH_ = _BASIC_PATH_[:_BASIC_PATH_.rfind('/test/')]
    os.environ['_BASIC_PATH_'] = _BASIC_PATH_
if sys.path.count(os.environ['_BASIC_PATH_'] + '/lib') == 0:
    sys.path.append(os.environ['_BASIC_PATH_'] + '/mod')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/lib/common')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs')
    sys.path.append(os.environ['_BASIC_PATH_'] + '/libs/pypi')


import re
import XmlConfig, urllib, urllib2
import Db.Mysql
import datetime
import functions
import base64
from BeautifulSoup import BeautifulSoup

path = ''
lltype = 'bb'
XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/config.xml')
XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/db.xml')

import cslib
p = cslib.cslib()

t = "fb"
p.checkit(t)
exit()


if 1:
    if 1:
#����ʼ#
        
        
        define = XmlConfig.get('/config/define')
        conf = XmlConfig.get('/config/%s' % lltype)
        atnum = 0
        
        #ץȡHTML����
        #url = functions.getUrl(conf['url'])
        resp = functions.fopen(conf['url'])
        
        match = []
        
        WeekDay = ["", "��һ", "�ܶ�", "����", "����", "����", "����", "����"]
        
        if resp:
            if lltype == 'fb':
                datalist = re.findall('A\[\d+\]="([^"]+)"\.split\(\'\^\'\)', resp)
                for d in datalist:            
                    data = d.split('^')
                    jc = {}
                    
                    jc["Ordernum"] = WeekDay[int(data[51][0])]+data[51][1:4]
                    
                    jc['MatchID'] = int(data[0])
                    jc['LeagueName'] = data[2]
                    jc['HomeTeam'] = data[5]
                    jc['AwayTeam'] = data[8]
                    jc['MatchTime'] = "%s-%s %s" % (data[12][0:4], data[36], data[11])
                    jc['Status'] = int(data[13])
                    if len(data[14]) == 0:
                        jc['HomeScore'] = 0 
                    else:
                        jc['HomeScore'] = int(data[14])
                    if len(data[15]) == 0:
                        jc['AwayScore'] = 0 
                    else:
                        jc['AwayScore'] = int(data[15])
                    if len(data[16]) == 0:
                        jc['HomeHalfScore'] = 0 
                    else:
                        jc['HomeHalfScore'] = int(data[16])
                    if len(data[17]) == 0:
                        jc['AwayHalfScore'] = 0 
                    else:
                        jc['AwayHalfScore'] = int(data[17])
                    match.append(jc)
                
            else:
                soap = BeautifulSoup(resp)
                for t in soap.findAll("h"):
                    data = t.text.split('^')
                    jc = {}
                    
                    if data:
                        print data
                        jc["Ordernum"] = WeekDay[int(data[2][0])]+data[2][1:4]
                        print jc["Ordernum"]
                        
                        jc['MatchID'] = int(data[0])
                        jc['LeagueName'] = data[4]
                        jc['HomeTeam'] = data[8]
                        jc['AwayTeam'] = data[6]
                        jc['MatchTime'] = "%s %s" % (data[10], data[11])
                        jc['Status'] = int(data[28])
                        if len(data[13]) == 0:
                            jc['HomeScore'] = 0
                        else:
                            jc['HomeScore'] = data[13]
                        if len(data[12]) == 0:
                            jc['AwayScore'] = 0
                        else:
                            jc['AwayScore'] = data[12]
                        match.append(jc)
            
        exit()
        #�������,��Ҫ�����match����
        socdb = Db.Mysql.get(conf['db_write'])
        infodb = Db.Mysql.get('info_write')
        addtime = datetime.datetime.now()
        
        telId = []
        for m in match:
            
            sql = "select id from %s where jcmatchid=%d" % (conf['jtable'], int(m['MatchID']))
            res = infodb.queryOne(sql)
            
            if res:
                m['JCID'] = res['id']
            else:
                m['JCID'] = 0
            sql = "select fixtureid from %s where jcid=%d and source=3" % (conf['ctable'], int(m['JCID']))
            res = socdb.queryOne(sql)
            
            if res:
                m['FixturID'] = res['fixtureid']
            else:
                m['FixturID'] = 0
            
            if m['FixturID'] != 0 and m['Status'] == -1:
                source = 4
                sql = "select * from %s where source=%d and fixtureid=%d" % (conf['ctable'], source, int(m['FixturID']))
                res = socdb.queryOne(sql)

                if lltype == 'fb':
                    data = {'source':source, 'fixtureid':m['FixturID'], 'homescore':m['HomeScore'], 'awayscore':m['AwayScore'], 'homehscore':m['HomeHalfScore'], 'awayhscore':m['AwayHalfScore'], 'jcid':m['JCID'], 'addtime':addtime}
                else:
                    data = {'source':source, 'fixtureid':m['FixturID'], 'homescore':m['HomeScore'], 'awayscore':m['AwayScore'], 'jcid':m['JCID'], 'addtime':addtime}
                                
                if res:
                    isupdate = False
                    if lltype == 'fb':
                        if res["homescore"]!=m['HomeScore'] or res["awayscore"]!=m['AwayScore'] or res["homehscore"]!=m['HomeHalfScore'] or res["awayhscore"]!=m['AwayHalfScore']:
                            isupdate = True
                    else:
                        if res["homescore"]!=m['HomeScore'] or res["awayscore"]!=m['AwayScore']:
                            isupdate = True
                    
                    if isupdate:
                        where = "source=%d and fixtureid=%d" % (source, int(m['FixturID']))
                        res = functions.update(conf['ctable'], data, where, socdb)
                        if res["ischeck"]==1:
                            tmpStr = str(m['Ordernum'])
                            #if lltype == 'fb':
                            #    tmpStr += "{%s,%s,%s,%s:%s,%s,%s,%s}" % (res["homescore"],res["awayscore"],res["homehscore"],res["awayhscore"],m['HomeScore'],m['AwayScore'],m['HomeHalfScore'],m['AwayHalfScore'])
                            #else:
                            #    tmpStr += "{%s,%s:%s,%s}" % (res["homescore"],res["awayscore"],m['HomeScore'],m['AwayScore'])
                            telId.append(tmpStr)
                else:
                    res = functions.insert(conf['ctable'], data, socdb)
                
        #���Ͷ���
        if telId:
            for t in telId:
                phone = define["phone"]
                if lltype == 'fb':
                    content = "����"
                else:
                    content = "����"
                idStr = ",".join(telId)
                content += "%s�ȷ�����쳣" % (t)
                res = functions.UpLoadMonitor(define["monitorUrl"], "emerg", "eas_checkdata::match", content, 0, phone)
                functions.write_log("SENDTEL:%s-%s-%s" % (str(phone), content, res))
                time.sleep(2)
        
        #ȡ����Ҫ��˵�����
        sql = "select distinct(fixtureid) from %s where ischeck!=1 and addtime>'%s'" % (conf['ctable'], datetime.datetime.now() - datetime.timedelta(days=3))
        res = socdb.query(sql)
        ids = []
        
        if res:
            for r in res:
                
                sql = "select * from %s where fixtureid=%d order by source" % (conf['ctable'], int(r['fixtureid']))
                drlist = socdb.query(sql)
                
                modelist = []
                for dr in drlist:
                    mode = {}
                    mode['CheckId'] = dr['checkid']
                    mode['AwayHalfScore'] = dr['awayhscore']
                    mode['AwayScore'] = dr['awayscore']
                    mode['HomeHalfScore'] = dr['homehscore']
                    mode['HomeScore'] = dr['homescore']
                    mode['FixtureId'] = dr['fixtureid']
                    mode['IsCheck'] = dr['ischeck']
                    mode['Jcid'] = int(dr['jcid'])
                    mode['IsSend'] = dr['issend']
                    mode['AddTime'] = dr['addtime']
                    modelist.append(mode)
                
                if modelist:
                    if lltype == 'fb':
                        if len(modelist) == 3:
                            if modelist[0]['HomeScore'] == modelist[1]['HomeScore'] and modelist[0]['HomeScore'] == modelist[2]['HomeScore'] and modelist[0]['HomeHalfScore'] == modelist[1]['HomeHalfScore'] and modelist[0]['HomeHalfScore'] == modelist[2]['HomeHalfScore'] and modelist[0]['AwayScore'] == modelist[1]['AwayScore'] and modelist[0]['AwayScore'] == modelist[2]['AwayScore'] and modelist[0]['AwayHalfScore'] == modelist[1]['AwayHalfScore'] and modelist[0]['AwayHalfScore'] == modelist[2]['AwayHalfScore']:
                                ids.append(str(modelist[0]['FixtureId']))
                            else:
                                if modelist[0]['IsSend'] < define['send']:
                                    functions.upCheck(conf['ctable'], -1, int(r['fixtureid']), socdb)
                    else:
                        if len(modelist) == 4:
                            if modelist[0]['HomeScore'] == modelist[1]['HomeScore'] and modelist[0]['HomeScore'] == modelist[2]['HomeScore'] and modelist[0]['HomeScore'] == modelist[3]['HomeScore'] and modelist[0]['AwayScore'] == modelist[1]['AwayScore'] and modelist[0]['AwayScore'] == modelist[2]['AwayScore'] and modelist[0]['AwayScore'] == modelist[3]['AwayScore']:
                                ids.append(str(modelist[0]['FixtureId']))
                            else:
                                if modelist[0]['IsSend'] < define['send']:
                                    functions.upCheck(conf['ctable'], -1, int(r['fixtureid']), socdb)
        
        logging.info('��Ҫ��˵�ids��:%s' % ",".join(ids))
        
        if ids:
            sql = "select checkid,source,fixtureid,homescore,awayscore,homehscore,awayhscore,addtime,ischeck,checktime,jcid,issend from %s where source=4 and fixtureid in (%s)" % (conf['ctable'], ",".join(ids))
            res = socdb.query(sql)
            for s in res:
                if lltype == 'fb':            
                    score = "%s,%s,%s,%s,%s" % (s['jcid'], s['homescore'], s['awayscore'], s['homehscore'], s['awayhscore'])
                else:
                    score =  "%s,%s,%s" % (s['jcid'], s['homescore'], s['awayscore'])
                
                check = functions.sumstr("%s%s" % (define['salt'], score))
                url = conf['online'] % base64.b64encode("%s|%s" % (score, check))
                res = urllib2.urlopen(url).read()
                
                if res != "update_success" and res != "update_no":
                    ischeck = -3
                    logging.info('ʧ�ܵ�URL��:%s' % (url))
                else:
                    ischeck = 1
                atnum += int(functions.upCheck(conf['ctable'], ischeck, int(s['fixtureid']), socdb))
        
#�������#
print path, atnum
