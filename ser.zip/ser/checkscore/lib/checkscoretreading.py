#encoding=gbk
import time
import logging
import traceback
import datetime
import cslib

p = cslib.cslib()

def checkall(seconds):
    while s1:
        try:
            #p.checkit('fb')
            p.checkit('bb')
        except:
            logging.info(traceback.format_exc())
        logging.info('sleep %d seconds.' % (seconds))
        time.sleep(seconds)
