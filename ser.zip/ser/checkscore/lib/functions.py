#coding=gbk
from hashlib import md5
import XmlConfig
import random
import datetime
import urllib2,urllib
import logging

def fopen(path,post={},proxy=1):
    
    #����IP
    #path = "http://iframe.ip138.com/city.asp"
    #����headerͷ
    host = path.split("/")[2]
    heads = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Charset':'GB2312,utf-8;q=0.7,*;q=0.7',
    'Accept-Language':'zh-cn,zh;q=0.5',
    'Cache-Control':'max-age=0',
    'Connection':'keep-alive',
    'Host':host,
    'Keep-Alive':'115',
    'Referer':path,
    'User-Agent':'Mozilla/5.0 (X11; U; Linux x86_64; zh-CN; rv:1.9.2.14) Gecko/20110221 Ubuntu/10.10 (maverick) Firefox/3.6.14'}

    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor())
    urllib2.install_opener(opener)
    data = urllib.urlencode(post)
    req = urllib2.Request(path,data,headers=heads)
    if proxy:
        #���ô���
        daili = XmlConfig.get('/config/daili')
        if daili.get("ip"):
            ip = daili["ip"].split("|")
            ran = random.randint(0, len(ip)-1)
            req.set_proxy(ip[ran],daili["type"])
    #opener.addheaders = heads.items()

    while True:
        try:
            content = opener.open(req, timeout=30).read()
            if req.has_proxy():
                if not content:
                    #print '�ô���IP:%s���ʸ�ҳ��Ϊ��'%(ip[ran])
                    write_log('�ô���IP:%s���ʸ�ҳ��Ϊ��'%(ip[ran]))
            #print req.header_items()
            #sleep(randint(1,10))
            break
        except (urllib2.HTTPError,),e:
            write_log('����ҳ��%s�����쳣:%s!'%(path,e))
            return False
        except KeyboardInterrupt:
            write_log("Interrupt")
            return False
        except:
            write_log("Error,Retry��")
            return False
    return content

def write_log(msg):
    #print msg
    logging.info(msg)

def UpLoadMonitor(pu, level, job, content, jgtime, phone):
        values = {'LEVEL':level, 'TIME':datetime.datetime.now(),'TYPE':'infolocalserver', 'JOB':job, 'SERVICE':'CheckData', 'CONTENT':content.encode("gb2312"), 'NEXTTIME':jgtime, 'PHONELIST':phone}
        str = urllib.urlencode(values)
        url = "%s?%s" % (pu, str)
        #return '<?xml version="1.0" encoding="utf-8" ?><result>OK</result>'
        res = fopen(url)
        return res

def sumstr(str):  
  m = md5()  
  m.update(str)  
  return m.hexdigest()

def getWeekDay(num):
    num = int(num)
    if num == 1:
        return "��һ"
    if num == 2:
        return "�ܶ�"
    if num == 3:
        return "����"
    if num == 4:
        return "����"
    if num == 5:
        return "����"
    if num == 6:
        return "����"
    if num == 7:
        return "����"
    return ""

def upCheck(table, ischeck, fixtureid, socdb):
    sql = "update %s set issend=issend+1,ischeck=%d,checktime='%s' where fixtureid=%d" % (table, ischeck, datetime.datetime.now(), fixtureid)
    res = socdb.execute(sql)
    return res

def insert(table, data, db):
    if table and data and db:
        keylist = []
        vallist = []
        for key in data:
            keylist.append(key)
            vallist.append(data[key])
        sql = "INSERT INTO %s (%s) VALUES (%s)" % (table, ",".join(keylist), ",".join(['%s']*len(keylist)))
        ret = db.execute(sql, vallist)
        return ret
    return ''

def update(table, data, where, db):
    if table and data and where and db:
        list = []
        vallist = []
        for key in data:
            list.append(key+"=%s")
            vallist.append(data[key])
    
        sql = "update %s set %s where %s" % (table, ",".join(list), where)
        ret = db.execute(sql, vallist)
        return ret
    return ''

def getUrl(url):
    return url
    if url:
        num = random.randint(1, 3)
        conf = XmlConfig.get('/config/define')
        return conf['daili'] % (num, url)
    return ''
