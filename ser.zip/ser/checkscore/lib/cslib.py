#encoding=gbk
import sys
reload(sys)
sys.setdefaultencoding('gbk')

import os
import XmlConfig
import urllib2
import re
import datetime, time
from BeautifulSoup import BeautifulSoup
import functions
import Db.Mysql
import base64
import logging

class cslib:
    
    '''�������������'''
    def __init__(self):
        XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/config.xml')
        XmlConfig.loadFile(os.environ['_BASIC_PATH_'] + '/etc/db.xml')
        pass

    def checkit(self, lltype):
        
        #ֻ������
        lltype = 'bb'
        define = XmlConfig.get('/config/define')
        conf = XmlConfig.get('/config/%s' % lltype)
        atnum = 0
        
        #ץȡHTML����
        #url = functions.getUrl(conf['url'])
        resp = functions.fopen(conf['url'])
        
        match = []
        
        #ȡ����������ٷ�Դ
        if resp:
            if lltype == 'fb':
                datalist = re.findall('A\[\d+\]="([^"]+)"\.split\(\'\^\'\)', resp)
                for d in datalist:            
                    data = d.split('^')
                    jc = {}
                    
                    jc["Ordernum"] = "%s%s" % (functions.getWeekDay(data[51][0]), data[51][1:4])
                    
                    jc['MatchID'] = int(data[0])
                    jc['LeagueName'] = data[2]
                    jc['HomeTeam'] = data[5]
                    jc['AwayTeam'] = data[8]
                    jc['MatchTime'] = "%s-%s %s" % (data[12][0:4], data[36], data[11])
                    jc['Status'] = int(data[13])
                    if len(data[14]) == 0:
                        jc['HomeScore'] = 0 
                    else:
                        jc['HomeScore'] = int(data[14])
                    if len(data[15]) == 0:
                        jc['AwayScore'] = 0 
                    else:
                        jc['AwayScore'] = int(data[15])
                    if len(data[16]) == 0:
                        jc['HomeHalfScore'] = 0 
                    else:
                        jc['HomeHalfScore'] = int(data[16])
                    if len(data[17]) == 0:
                        jc['AwayHalfScore'] = 0 
                    else:
                        jc['AwayHalfScore'] = int(data[17])
                    match.append(jc)
        
        #�������,��Ҫ�����match����
        socdb = Db.Mysql.get(conf['db_write'])
        infodb = Db.Mysql.get('info_write')
        addtime = datetime.datetime.now()
        
        telId = []
        for m in match:
            
            sql = "select id from %s where jcmatchid=%d" % (conf['jtable'], int(m['MatchID']))
            jcArr = infodb.queryOne(sql)
            
            if jcArr:
                m['JCID'] = jcArr['id']
            else:
                m['JCID'] = 0
                
            sql = "select fixtureid from %s where jcid=%d and source=3" % (conf['ctable'], int(m['JCID']))
            fixArr = socdb.queryOne(sql)
            
            if fixArr:
                m['FixturID'] = fixArr['fixtureid']
            else:
                m['FixturID'] = 0
            
            if m['FixturID'] != 0 and m['Status'] == -1:
                source = 4
                sql = "select * from %s where source=%d and fixtureid=%d" % (conf['ctable'], source, int(m['FixturID']))
                row = socdb.queryOne(sql)

                if lltype == 'fb':
                    data = {'source':source, 'fixtureid':m['FixturID'], 'homescore':m['HomeScore'], 'awayscore':m['AwayScore'], 'homehscore':m['HomeHalfScore'], 'awayhscore':m['AwayHalfScore'], 'jcid':m['JCID'], 'addtime':addtime}
                else:
                    data = {'source':source, 'fixtureid':m['FixturID'], 'homescore':m['HomeScore'], 'awayscore':m['AwayScore'], 'jcid':m['JCID'], 'addtime':addtime}
                                
                if row:
                    isupdate = False
                    if lltype == 'fb':
                        if int(row["homescore"])!=int(m['HomeScore']) or int(row["awayscore"])!=int(m['AwayScore']) or int(row["homehscore"])!=int(m['HomeHalfScore']) or int(row["awayhscore"])!=int(m['AwayHalfScore']):
                            isupdate = True
                    else:
                        if int(row["homescore"])!=int(m['HomeScore']) or int(row["awayscore"])!=int(m['AwayScore']):
                            isupdate = True
                    
                    if isupdate:
                        where = "source=%d and fixtureid=%d" % (source, int(m['FixturID']))
                        upRes = functions.update(conf['ctable'], data, where, socdb)

                        inlog = "UPDATE:%s from(%s)to(%s)" % (conf['ctable'], str(row), str(data))
                        functions.write_log(inlog)

                        if row["ischeck"]==1:
                            tmpStr = m['Ordernum']
                            telId.append(tmpStr)
                else:
                    upRes = functions.insert(conf['ctable'], data, socdb)
                
        #���Ͷ���
        if telId:
            for t in telId:
                phone = define["phone"]
                if lltype == 'fb':
                    content = "����"
                else:
                    content = "����"
                idStr = ",".join(telId)
                content += "%s�ȷ�����쳣" % (t)
                res = functions.UpLoadMonitor(define["monitorUrl"], "emerg", "eas_checkdata::match", content, 0, phone)
                functions.write_log("SENDTEL:%s-%s-%s" % (str(phone), content, res))
                time.sleep(2)
        
        #ȡ����Ҫ��˵�����
        sql = "select distinct(fixtureid) from %s where ischeck!=1 and addtime>'%s'" % (conf['ctable'], datetime.datetime.now() - datetime.timedelta(days=3))
        res = socdb.query(sql)
        ids = []
        
        if res:
            for r in res:                
                sql = "select * from %s where fixtureid=%d order by source" % (conf['ctable'], int(r['fixtureid']))
                drlist = socdb.query(sql)

                #�����ظ�source
                modelist = {}
                for dr in drlist:
                    modelist[dr['source']] = dr
                
                #���ڵ���2����ͬԴ�������
                if modelist and len(modelist.keys()) >= 2:
                    score = ""
                    jg = {}
                    for s in modelist.keys():
                        r = modelist[s]
                        sk = "%s,%s,%s,%s" % (r['homescore'], r['awayscore'], r['homehscore'], r['awayhscore'])
                        if jg.get(sk) == None:
                            jg[sk] = {"count":0, "checkid":[]}
                        jg[sk]["count"] += 1
                        jg[sk]["checkid"].append(str(r["checkid"]))
                        #2����ͬ��ͨ����֤
                        if jg[sk]["count"]>=2:
                            score = sk

                    if score:
                        ids.append(str(r['fixtureid']))
                    else:
                        if modelist.values()[0]['issend'] < define['send']:
                            functions.upCheck(conf['ctable'], -1, int(r['fixtureid']), socdb)
        
        if ids:
            logging.info('��Ҫ��˵�ids��:%s' % ",".join(ids))
            
            sql = "select checkid,source,fixtureid,homescore,awayscore,homehscore,awayhscore,addtime,ischeck,checktime,jcid,issend from %s where source=3 and fixtureid in (%s)" % (conf['ctable'], ",".join(ids))
            res = socdb.query(sql)
            for s in res:
                if lltype == 'fb':            
                    score = "%s,%s,%s,%s,%s" % (s['jcid'], s['homescore'], s['awayscore'], s['homehscore'], s['awayhscore'])
                else:
                    score =  "%s,%s,%s" % (s['jcid'], s['homescore'], s['awayscore'])
                
                check = functions.sumstr("%s%s" % (define['salt'], score))
                url = conf['online'] % base64.b64encode("%s|%s" % (score, check))
                res = urllib2.urlopen(url).read()
                
                if res != "update_success" and res != "update_no":
                    ischeck = -3
                    logging.info('ʧ�ܵ�URL��:%s' % (url))
                else:
                    ischeck = 1

                atnum += int(functions.upCheck(conf['ctable'], ischeck, int(s['fixtureid']), socdb))
        
            logging.info('%s �������� %d ��' % (lltype, atnum))
        return atnum
